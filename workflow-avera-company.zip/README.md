# Sistema Avera Company — Gestão de Processos & Operações

Sistema web interno para a **Avera**, agência de marketing e serviços para artistas musicais (social media, tráfego pago, produção de conteúdo, lançamentos, registro autoral, playlists, videoclipe e branding).

O objetivo do sistema é transformar os processos de cada serviço do catálogo em tarefas organizadas por **pessoa**, **área** e **cliente**, permitindo que os sócios (Anelise e Matheus) e futuros colaboradores saibam em segundos **o que fazer, para quem e até quando**, com cálculo automático de prazos em dias úteis e fuso horário brasileiro.

---

##  Principais Funcionalidades

1. **Minhas Tarefas & Visão do Colaborador:**
   - Lista priorizada das tarefas sob responsabilidade do membro logado (Atrasadas, Para Hoje, Próximas).
   - Checklists operacionais e comentários por tarefa.
2. **Quadro Kanban Interativo:**
   - Visualização por colunas (`A Fazer`, `Em Andamento`, `Aguardando Cliente`, `Em Revisão`, `Concluído`).
   - Filtros instantâneos por Cliente, Responsável, Área e Ciclo Mensal.
3. **Painel de Carga por Pessoa:**
   - Visualização da distribuição de trabalho por colaborador com cálculo de sobrecarga.
4. **Visão por Área & Serviços:**
   - Organização visual pelas 7 áreas oficiais com suas cores temáticas.
5. **Clientes & Projetos com Motor Automático de Tarefas:**
   - Geração automática de toda a esteira de tarefas ao cadastrar um novo projeto.
   - Cálculo automático de prazos em dias úteis com feriados nacionais do Brasil.
   - Prazos com datas-âncora reversas (ex: 14 dias antes do lançamento) com trava de integridade para impedir tarefas com prazos invertidos.
   - Passos paralelos (ex: tráfego pago com passos 3, 4 e 5 contando do início do projeto e passo 6 após criativos).
   - Relatórios mensais fixados no 5º dia útil do mês subsequente.
   - Rollover automático para o ciclo do mês seguinte em serviços recorrentes.
6. **Segurança & Perfis de Acesso:**
   - **ADMIN (Anelise & Matheus):** Acesso irrestrito a valores financeiros, edição de modelos de processo, convite de membros e troca de papéis em massa.
   - **MEMBER:** Acesso restrito às suas próprias tarefas e comentários. Dados financeiros são mantidos em tabelas isoladas com políticas RLS no banco e sanitização no servidor.
7. **Biblioteca Oficial de Processos:**
   - Visualização de todos os serviços, escopos, o que não inclui, entregáveis esperados e passos. Edição de modelos sem alterar tarefas em andamento.
8. **Rituais de Agenda & Decisões Operacionais:**
   - Os 9 rituais semanais/recorrentes fixados na agenda.
   - As 10 decisões estratégicas com controle de status (`Pendente`, `Em Discussão`, `Resolvida`) e notas de resolução.
9. **Exportação de Backup Manual (.xlsx):**
   - Download em um clique de planilha Excel contendo todas as abas de Clientes, Projetos e Tarefas.

---

## 🛠️ Stack Tecnológica

- **Frontend & Fullstack:** Next.js 14 (App Router) + TypeScript + Tailwind CSS
- **Banco de Dados:** Supabase (PostgreSQL) com Prisma ORM
- **Autenticação:** Supabase Auth (E-mail e Senha) com sessões server-side (SSR)
- **Hospedagem Recomendada:** Netlify (Gratuito) + Supabase (Gratuito)

---

## 🚀 Guia de Implantação para Não-Técnicos (Passo a Passo)

Este guia foi elaborado para que qualquer pessoa consiga colocar o sistema no ar em minutos sem custo de hospedagem.

### Passo 1: Criar o Projeto no Supabase

1. Acesse [supabase.com](https://supabase.com) e crie uma conta gratuita.
2. Clique em **"New Project"**.
3. Dê um nome ao projeto (ex.: `sistema-avera`) e defina uma senha forte para o banco de dados (**guarde essa senha**).
4. Escolha a região mais próxima (ex.: `Sao Paulo (sa-east-1)`).
5. Clique em **"Create new project"** e aguarde 2 minutos até o banco ser provisionado.

### Passo 2: Copiar as Chaves e URLs de Conexão

No painel do Supabase:

1. **URLs do Banco de Dados:**
   - Acesse **Project Settings** (ícone de engrenagem) > **Database**.
   - Role até a seção **Connection string**:
     - Selecione a aba **Transaction mode** (porta `6543`) e copie a URL. Esta será a sua `DATABASE_URL` (com pooling para serverless). Lembre-se de substituir `[YOUR-PASSWORD]` pela senha que você criou. Adicione `?pgbouncer=true` ao final se não estiver presente.
     - Selecione a aba **Session mode** (porta `5432`) e copie a URL. Esta será a sua `DIRECT_URL` (usada pelo Prisma para criar as tabelas). Lembre-se de substituir `[YOUR-PASSWORD]`.
2. **Chaves de API & Autenticação:**
   - Acesse **Project Settings** > **API**.
   - Copie o **Project URL** (será `NEXT_PUBLIC_SUPABASE_URL`).
   - Copie a chave **anon public** (será `NEXT_PUBLIC_SUPABASE_ANON_KEY`).
   - Copie a chave **service_role secret** (será `SUPABASE_SERVICE_ROLE_KEY`). *Atenção: nunca compartilhe esta chave publicamente.*

### Passo 3: Criar as Tabelas e Importar os Dados Iniciais (Seed)

No computador onde o código está baixado:

1. Crie um arquivo chamado `.env` na raiz do projeto (copie o modelo de `.env.example`).
2. Preencha com as variáveis obtidas no Passo 2:
   ```env
   DATABASE_URL="postgresql://postgres:SUA_SENHA@db.SEU_PROJETO.supabase.co:6543/postgres?pgbouncer=true"
   DIRECT_URL="postgresql://postgres:SUA_SENHA@db.SEU_PROJETO.supabase.co:5432/postgres"
   NEXT_PUBLIC_SUPABASE_URL="https://SEU_PROJETO.supabase.co"
   NEXT_PUBLIC_SUPABASE_ANON_KEY="sua-chave-anon"
   SUPABASE_SERVICE_ROLE_KEY="sua-chave-service-role"
   ```
3. Abra o terminal na pasta do projeto e execute:
   ```bash
   # 1. Cria as tabelas no Supabase PostgreSQL
   npm run db:push

   # 2. Popula os dados oficiais (áreas, sócios, clientes, serviços, processos, rituais e feriados)
   npm run db:seed
   ```
4. No painel do Supabase, vá em **SQL Editor** e execute o script contido em `supabase/rls_policies.sql` para ativar as políticas de segurança Row Level Security.

### Passo 4: Publicar na Netlify (Grátis)

1. Suba o código do projeto para um repositório no seu GitHub (ex.: `github.com/seu-usuario/sistema-avera`).
2. Acesse [netlify.com](https://www.netlify.com) e crie uma conta gratuita com seu GitHub.
3. Clique em **"Add new site"** > **"Import an existing project"** > **GitHub**.
4. Selecione o repositório `sistema-avera`.
5. As configurações padrão já serão preenchidas:
   - **Build command:** `npm run build`
   - **Publish directory:** `.next`
6. Clique em **"Environment variables"** (ou configure logo após criar o site em Site configuration > Environment variables).
7. Adicione as 5 variáveis de ambiente configuradas no seu `.env`:
   - `DATABASE_URL`
   - `DIRECT_URL`
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
8. Clique em **"Deploy site"**.
9. Em instantes o site estará no ar com um link seguro HTTPS (ex.: `https://sistema-avera.netlify.app`), acessível do computador e celular!

---

## 👥 Como Convidar Membros e Criar Usuários

1. **Configuração de E-mail no Supabase (Auth):**
   - No painel do Supabase, acesse **Authentication** > **URL Configuration**.
   - Em **Site URL**, coloque o endereço publicado do seu site na Netlify (ex: `https://sistema-avera.netlify.app`).
   - Em **Redirect URLs**, adicione `https://sistema-avera.netlify.app/**` e `http://localhost:3000/**`.
2. **Convidar pela Interface da Avera:**
   - Faça login como Administrador (Anelise ou Matheus).
   - Acesse o menu **"Equipe & Papéis"**.
   - Clique em **"Convidar Novo Membro"**.
   - Digite o nome, e-mail e selecione o papel operacional (ex.: *Edição de Vídeo*, *Planejamento de Conteúdo*).
   - O Supabase enviará um e-mail de convite com link seguro para o novo membro definir sua senha de acesso.

---

## 🔄 Troca de Responsável em Massa

Quando um novo funcionário assumir uma função (ou quando houver remanejamento de equipe):
1. Acesse **"Equipe & Papéis"**.
2. Clique no botão **"Troca de Responsável em Massa"**.
3. Selecione o membro atual e o novo responsável.
4. O sistema exibirá uma prévia de todas as tarefas abertas vinculadas àquele papel.
5. Selecione as tarefas desejadas e confirme.
6. A transferência é executada instantaneamente e registrada no histórico de auditoria da página.

---

## 💾 Backup dos Dados

Como o plano gratuito do banco não inclui backups automáticos periódicos:
- Acesse a aba **"Rituais & Decisões"** no menu superior.
- Clique em **"Exportar Backup (.xlsx)"**.
- O sistema baixará um arquivo Excel contendo as planilhas completas de:
  - **Clientes** (com donos de WhatsApp e observações)
  - **Projetos** (status, ciclos, valores e datas)
  - **Tarefas** (ordem, prazos calculados, status e responsáveis)

---

## 💻 Desenvolvimento Local

Caso queira rodar localmente no seu computador:

```bash
# Instalar dependências
npm install

# Rodar servidor de desenvolvimento
npm run dev
```

Abra [http://localhost:3000](http://localhost:3000) no seu navegador.
