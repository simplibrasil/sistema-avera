import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  console.log("Iniciando seed atualizado com tabelas financeiras isoladas...");

  // 1. ÁREAS
  const areasData = [
    { name: "Comercial e Financeiro", slug: "comercial-financeiro", color: "#10B981", description: "Funil de vendas, propostas, contratos, cobranças e onboarding." },
    { name: "Redes Sociais e Conteúdo", slug: "redes-sociais-conteudo", color: "#EC4899", description: "Planejamento operacional, calendários, roteiros e gestão de postagens." },
    { name: "Tráfego Pago", slug: "trafego-pago", color: "#3B82F6", description: "Campanhas Meta Ads e YouTube, otimização e relatórios semanais/mensais." },
    { name: "Produção Audiovisual", slug: "producao-audiovisual", color: "#F59E0B", description: "Captação de reels, direção criativa e produção de videoclipes com terceiros." },
    { name: "Música", slug: "musica", color: "#8B5CF6", description: "Registro autoral, filiação à associação, distribuição e playlists Spotify/YouTube." },
    { name: "Branding", slug: "branding", color: "#6366F1", description: "Posicionamento de marca, direção de arte, paleta e narrativa de carreira artística." },
    { name: "Gestão Interna da Avera", slug: "gestao-interna", color: "#64748B", description: "Rituais de equipe, marca própria e decisões estratégicas." },
  ];

  const createdAreas: Record<string, string> = {};
  for (const a of areasData) {
    const area = await prisma.area.upsert({
      where: { slug: a.slug },
      update: a,
      create: a,
    });
    createdAreas[a.slug] = area.id;
  }

  // 2. MEMBROS INICIAIS
  const anelise = await prisma.member.upsert({
    where: { email: "anelise@averacompany.com" },
    update: { name: "Anelise", systemRole: "ADMIN" },
    create: { name: "Anelise", email: "anelise@averacompany.com", systemRole: "ADMIN" },
  });

  const matheus = await prisma.member.upsert({
    where: { email: "matheus@averacompany.com" },
    update: { name: "Matheus", systemRole: "ADMIN" },
    create: { name: "Matheus", email: "matheus@averacompany.com", systemRole: "ADMIN" },
  });

  // 3. PAPÉIS OPERACIONAIS
  const rolesData = [
    { name: "Comercial e Onboarding", slug: "comercial-onboarding", defaultMember: "matheus" },
    { name: "Planejamento de Conteúdo", slug: "planejamento-conteudo", defaultMember: "anelise" },
    { name: "Gestão de Redes Sociais", slug: "gestao-redes-sociais", defaultMember: "anelise" },
    { name: "Gestão de Tráfego", slug: "gestao-trafego", defaultMember: "matheus" },
    { name: "Direção Criativa", slug: "direcao-criativa", defaultMember: "matheus" },
    { name: "Edição de Vídeo", slug: "edicao-video", defaultMember: "matheus" },
    { name: "Produção Audiovisual (Coordenação)", slug: "producao-audiovisual-coord", defaultMember: "matheus" },
    { name: "Registro Autoral e Distribuição", slug: "registro-distribuicao", defaultMember: "anelise" },
    { name: "Filiação à Associação", slug: "filiacao-associacao", defaultMember: "anelise" },
    { name: "Playlists e Spotify", slug: "playlists-spotify", defaultMember: "matheus" },
    { name: "Planejamento de Lançamento", slug: "planejamento-lancamento", defaultMember: "ambos" },
    { name: "Estratégia de Branding", slug: "estrategia-branding", defaultMember: "ambos" },
    { name: "Relatórios e Métricas", slug: "relatorios-metricas", defaultMember: "anelise" },
    { name: "Fornecedor Externo / Terceiro", slug: "terceiro", defaultMember: "nenhum" },
  ];

  const createdRoles: Record<string, string> = {};
  for (const r of rolesData) {
    const role = await prisma.operationalRole.upsert({
      where: { slug: r.slug },
      update: { name: r.name },
      create: { name: r.name, slug: r.slug },
    });
    createdRoles[r.slug] = role.id;

    if (r.defaultMember === "anelise" || r.defaultMember === "ambos") {
      await prisma.memberRole.upsert({
        where: { memberId_operationalRoleId: { memberId: anelise.id, operationalRoleId: role.id } },
        update: {},
        create: { memberId: anelise.id, operationalRoleId: role.id },
      });
    }
    if (r.defaultMember === "matheus" || r.defaultMember === "ambos") {
      await prisma.memberRole.upsert({
        where: { memberId_operationalRoleId: { memberId: matheus.id, operationalRoleId: role.id } },
        update: {},
        create: { memberId: matheus.id, operationalRoleId: role.id },
      });
    }
  }

  // 4. CLIENTES INICIAIS
  const initialClients = [
    { name: "Santta", whatsappLeadId: anelise.id, notes: "Artista da casa / foco em lançamentos" },
    { name: "Teuz", whatsappLeadId: anelise.id },
    { name: "Igor", whatsappLeadId: anelise.id },
    { name: "Paula", whatsappLeadId: anelise.id },
    { name: "Drik Barbosa", whatsappLeadId: anelise.id },
    { name: "Theaga", whatsappLeadId: matheus.id },
    { name: "NLE Kira", whatsappLeadId: matheus.id },
    { name: "San Joe", whatsappLeadId: matheus.id },
    { name: "Outro Lado", whatsappLeadId: matheus.id },
  ];

  for (const c of initialClients) {
    await prisma.client.upsert({
      where: { name: c.name },
      update: { whatsappLeadId: c.whatsappLeadId, notes: c.notes },
      create: { name: c.name, whatsappLeadId: c.whatsappLeadId, notes: c.notes },
    });
  }

  // 5. FERIADOS NACIONAIS DO BRASIL (editáveis)
  const holidaysData = [
    { name: "Confraternização Universal", date: new Date("2026-01-01T00:00:00Z") },
    { name: "Carnaval", date: new Date("2026-02-17T00:00:00Z") },
    { name: "Sexta-feira Santa", date: new Date("2026-04-03T00:00:00Z") },
    { name: "Tiradentes", date: new Date("2026-04-21T00:00:00Z") },
    { name: "Dia do Trabalho", date: new Date("2026-05-01T00:00:00Z") },
    { name: "Corpus Christi", date: new Date("2026-06-04T00:00:00Z") },
    { name: "Independência do Brasil", date: new Date("2026-09-07T00:00:00Z") },
    { name: "Nossa Senhora Aparecida", date: new Date("2026-10-12T00:00:00Z") },
    { name: "Finados", date: new Date("2026-11-02T00:00:00Z") },
    { name: "Proclamação da República", date: new Date("2026-11-15T00:00:00Z") },
    { name: "Dia da Consciência Negra", date: new Date("2026-11-20T00:00:00Z") },
    { name: "Natal", date: new Date("2026-12-25T00:00:00Z") },
  ];

  for (const h of holidaysData) {
    await prisma.holiday.upsert({
      where: { date: h.date },
      update: { name: h.name },
      create: { name: h.name, date: h.date },
    });
  }

  // 6. SERVIÇOS E PROCESSOS COM AJUSTES
  // --- GESTÃO DE TRÁFEGO ---
  const srvTrafego = await prisma.service.upsert({
    where: { name: "Gestão de Tráfego" },
    update: { priceType: "MONTHLY" },
    create: {
      name: "Gestão de Tráfego",
      areaId: createdAreas["trafego-pago"],
      priceType: "MONTHLY",
      scope: "Planejamento de campanhas, configuração e segmentação, criação e gestão de anúncios, otimização contínua e relatório mensal com métricas e insights.",
      outOfScope: "Não inclui criação de artes e vídeos. A verba de anúncios é paga à parte direto para a plataforma.",
    },
  });

  await prisma.serviceFinancial.upsert({
    where: { serviceId: srvTrafego.id },
    update: { price: 1562.0 },
    create: { serviceId: srvTrafego.id, price: 1562.0 },
  });

  await prisma.processTemplate.deleteMany({ where: { serviceId: srvTrafego.id } });
  await prisma.processTemplate.create({
    data: {
      serviceId: srvTrafego.id,
      name: "Processo - Gestão de Tráfego",
      checklist: "campanha ativa durante o mês · acompanhamento registrado nos dias combinados · relatório enviado · próxima verba combinada.",
      attentionPoints: "Sem criativo, a campanha não sobe. A verba de anúncios é paga à parte pelo cliente. Avisar o cliente quando o saldo estiver acabando com 2 dias de saldo.",
      steps: {
        create: [
          {
            order: 1,
            title: "Alinhar objetivo, público e verba mensal total do cliente",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: 0,
            deadlineOrigin: "PROJECT_START",
            deliverable: "Objetivo e verba registrados",
            isClientStep: true,
          },
          {
            order: 2,
            title: "Assinar o termo de verba e combinar o aporte mínimo",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: 1,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Termo assinado",
            isClientStep: true,
          },
          {
            order: 3,
            title: "Receber acesso à conta de anúncios, página, Instagram e pixel",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: 2, // PARALELO: 2 dias úteis a partir do início
            deadlineOrigin: "PROJECT_START",
            deliverable: "Acessos validados",
            isClientStep: true,
          },
          {
            order: 4,
            title: "Preencher o campo 'estratégia de anúncio' no briefing do cliente (A insumo, M decide)",
            defaultAssigneeTag: "M+A",
            responsibleType: "BOTH_A_M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: 3, // PARALELO: 3 dias úteis a partir do início
            deadlineOrigin: "PROJECT_START",
            deliverable: "Estratégia de anúncio definida",
          },
          {
            order: 5,
            title: "Receber ou pedir os criativos (artes e vídeos); sem criativo, a campanha não sobe",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: 5, // PARALELO: 5 dias úteis a partir do início
            deadlineOrigin: "PROJECT_START",
            deliverable: "Criativos aprovados",
            isClientStep: true,
          },
          {
            order: 6,
            title: "Criar campanha, conjuntos e anúncios; segmentar; revisar textos e links",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: 2, // 2 dias úteis após o último paralelo
            deadlineOrigin: "PARALLEL_MAX",
            deliverable: "Campanha criada",
          },
          {
            order: 7,
            title: "Cliente deposita o primeiro aporte na plataforma e a campanha vai ao ar",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: 0,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Campanha no ar",
            isClientStep: true,
          },
          {
            order: 8,
            title: "Acompanhamento em dias fixos (ex.: terça e sexta). Conferir gasto, custo por resultado, reprovações e saldo",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: null,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Registro rápido por conta",
          },
          {
            order: 9,
            title: "Otimizar: pausar o que não rende, escalar o que rende, testar novos criativos",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: null,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Ajustes registrados",
          },
          {
            order: 10,
            title: "Avisar o cliente quando o saldo estiver acabando e pedir novo aporte",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: null,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Novo aporte confirmado",
            isClientStep: true,
          },
          {
            order: 11,
            title: "Toda sexta: Matheus exporta os números e Anelise monta o relatório",
            defaultAssigneeTag: "M+A",
            responsibleType: "BOTH_A_M",
            defaultRoleId: createdRoles["relatorios-metricas"],
            deadlineDays: null,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Relatório semanal ou mensal",
          },
          {
            order: 12,
            title: "Enviar o relatório mensal com métricas e insights",
            defaultAssigneeTag: "A",
            defaultRoleId: createdRoles["relatorios-metricas"],
            deadlineDays: 5,
            deadlineOrigin: "FIFTH_BUSINESS_DAY_NEXT_MONTH", // 5º dia útil do mês seguinte
            deliverable: "Relatório enviado",
          },
          {
            order: 13,
            title: "Reunião mensal de resultados e definição do próximo ciclo",
            defaultAssigneeTag: "A ou M",
            defaultRoleId: createdRoles["gestao-trafego"],
            deadlineDays: 2, // 2 dias úteis após o relatório
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Ata e plano do mês seguinte",
            isClientStep: true,
          },
        ],
      },
    },
  });

  // --- PLANEJAMENTO DE LANÇAMENTOS ---
  const srvPlanLancamento = await prisma.service.upsert({
    where: { name: "Planejamento de Lançamentos" },
    update: { priceType: "ONE_OFF" },
    create: {
      name: "Planejamento de Lançamentos",
      areaId: createdAreas["musica"],
      priceType: "ONE_OFF",
      scope: "Estratégia de lançamento, conceito, narrativa e ações, curadoria e organização do catálogo, gestão e acompanhamento contínuo, reuniões mensais.",
      outOfScope: "Custos de distribuição e anúncios não inclusos.",
    },
  });

  await prisma.serviceFinancial.upsert({
    where: { serviceId: srvPlanLancamento.id },
    update: { price: 450.0 },
    create: { serviceId: srvPlanLancamento.id, price: 450.0 },
  });

  await prisma.processTemplate.deleteMany({ where: { serviceId: srvPlanLancamento.id } });
  await prisma.processTemplate.create({
    data: {
      serviceId: srvPlanLancamento.id,
      name: "Processo - Planejamento de Lançamentos",
      checklist: "conceito aprovado · cronograma e datas confirmadas · catálogo conferido · presskit pronto · pitch enviado · lançamento confirmado.",
      attentionPoints: "Vender só com processo e dono definidos. Escrita de nomes e títulos: grafar exatamente como o artista definir.",
      steps: {
        create: [
          {
            order: 1,
            title: "Reunião inicial: entender o projeto (single, EP ou álbum), as músicas prontas, o público e a data desejada",
            defaultAssigneeTag: "A+M",
            responsibleType: "BOTH_A_M",
            defaultRoleId: createdRoles["planejamento-lancamento"],
            deadlineDays: 5,
            deadlineOrigin: "PROJECT_START",
            deliverable: "Resumo do projeto",
            isClientStep: true,
          },
          {
            order: 2,
            title: "Receber ideias e materiais do artista (músicas, referências, conceito que ele já tem)",
            defaultAssigneeTag: "A",
            defaultRoleId: createdRoles["planejamento-lancamento"],
            deadlineDays: 5,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Pasta do projeto organizada",
            isClientStep: true,
          },
          {
            order: 3,
            title: "Definir conceito, narrativa e ações do lançamento (identidade, ideia central, formatos de conteúdo)",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["direcao-criativa"],
            deadlineDays: 5,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Documento de conceito",
          },
          {
            order: 4,
            title: "Definir data de lançamento e quantas músicas sairão",
            defaultAssigneeTag: "M+A",
            defaultRoleId: createdRoles["planejamento-lancamento"],
            deadlineDays: 0,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Data e formato definidos",
          },
          {
            order: 5,
            title: "Montar o checklist e cronograma reverso a partir da data",
            defaultAssigneeTag: "A",
            defaultRoleId: createdRoles["planejamento-lancamento"],
            deadlineDays: 3,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Cronograma compartilhado com o artista",
          },
          {
            order: 6,
            title: "Curadoria e organização do catálogo: conferir nomes, créditos, ISRC, autores e versões",
            defaultAssigneeTag: "A",
            defaultRoleId: createdRoles["registro-distribuicao"],
            deadlineDays: 5,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Catálogo conferido",
          },
          {
            order: 7,
            title: "Criar o presskit (texto, fotos, links, ficha técnica)",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["direcao-criativa"],
            deadlineDays: 7,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Presskit pronto",
          },
          {
            order: 8,
            title: "Registro autoral e distribuição das faixas (padrão a definir: -10 dias úteis da data de lançamento)",
            defaultAssigneeTag: "A",
            defaultRoleId: createdRoles["registro-distribuicao"],
            deadlineDays: 10,
            deadlineOrigin: "ANCHOR_DATE",
            anchorField: "RELEASE_DATE",
            anchorOffsetDays: -10,
            isProvisionalAnchor: true, // Padrão a definir
            deliverable: "Faixas na distribuidora",
          },
          {
            order: 9,
            title: "Enviar o pitch às plataformas (padrão a definir: -7 dias úteis da data de lançamento)",
            defaultAssigneeTag: "M",
            defaultRoleId: createdRoles["playlists-spotify"],
            deadlineDays: 7,
            deadlineOrigin: "ANCHOR_DATE",
            anchorField: "RELEASE_DATE",
            anchorOffsetDays: -7,
            isProvisionalAnchor: true, // Padrão a definir
            deliverable: "Pitch enviado",
          },
          {
            order: 10,
            title: "Aprovar o plano de conteúdo de lançamento (até 14 dias antes do lançamento)",
            defaultAssigneeTag: "A",
            defaultRoleId: createdRoles["planejamento-conteudo"],
            deadlineDays: 14,
            deadlineOrigin: "ANCHOR_DATE",
            anchorField: "RELEASE_DATE",
            anchorOffsetDays: -14,
            deliverable: "Plano de conteúdo",
            isClientStep: true,
          },
          {
            order: 11,
            title: "Acompanhar o cronograma toda semana e alertar o artista sobre atrasos",
            defaultAssigneeTag: "A",
            defaultRoleId: createdRoles["planejamento-lancamento"],
            deadlineDays: null,
            deadlineOrigin: "PREVIOUS_STEP",
            deliverable: "Checklist atualizado",
          },
          {
            order: 12,
            title: "Lançamento: conferir a música no ar nas plataformas, links e primeiras métricas",
            defaultAssigneeTag: "A+M",
            responsibleType: "BOTH_A_M",
            defaultRoleId: createdRoles["planejamento-lancamento"],
            deadlineDays: 0,
            deadlineOrigin: "ANCHOR_DATE",
            anchorField: "RELEASE_DATE",
            anchorOffsetDays: 0,
            deliverable: "Lançamento confirmado",
          },
          {
            order: 13,
            title: "Reunião de fechamento: resultados, aprendizados e próximos passos",
            defaultAssigneeTag: "A ou M",
            defaultRoleId: createdRoles["planejamento-lancamento"],
            deadlineDays: 15,
            deadlineOrigin: "ANCHOR_DATE",
            anchorField: "RELEASE_DATE",
            anchorOffsetDays: 15,
            deliverable: "Ata e relatório curto",
            isClientStep: true,
          },
        ],
      },
    },
  });

  // 7. Rituais Recorrentes
  console.log("Seeding Rituais Recorrentes...");
  await prisma.recurringRitual.deleteMany({});
  await prisma.recurringRitual.createMany({
    data: [
      {
        title: "Acompanhamento de tráfego",
        frequency: "2x por semana (ex.: terça e sexta)",
        dayOfWeek: "Terça e Sexta",
        assigneeDescription: "M",
        defaultMemberName: "Matheus",
        objective: "Gasto, saldo, reprovações e ajustes de todas as campanhas",
      },
      {
        title: "Relatório de tráfego",
        frequency: "Sexta",
        dayOfWeek: "Sexta",
        assigneeDescription: "M exporta, A monta",
        defaultMemberName: "Matheus / Anelise",
        objective: "Relatório pronto para a reunião mensal",
      },
      {
        title: "Bloco do Instagram da Avera Records",
        frequency: "1x por semana",
        dayOfWeek: "Semanal",
        assigneeDescription: "M",
        defaultMemberName: "Matheus",
        objective: "Postar e planejar a marca própria",
      },
      {
        title: "Bloco do Instagram da Avera Company",
        frequency: "1x por semana",
        dayOfWeek: "Semanal",
        assigneeDescription: "A",
        defaultMemberName: "Anelise",
        objective: "Postar e planejar a marca própria",
      },
      {
        title: "Playlists e Spotify",
        frequency: "Semanal (junto ao tráfego)",
        dayOfWeek: "Semanal",
        assigneeDescription: "M",
        defaultMemberName: "Matheus",
        objective: "Conferir posição e números dos clientes de playlist",
      },
      {
        title: "Reunião de projeto",
        frequency: "Quinzenal, alternando A e M",
        dayOfWeek: "Quinzenal",
        assigneeDescription: "A ou M",
        defaultMemberName: "Anelise ou Matheus",
        objective: "Entender o projeto e o que será feito",
      },
      {
        title: "Reunião de resultados",
        frequency: "Quinzenal",
        dayOfWeek: "Quinzenal",
        assigneeDescription: "A ou M",
        defaultMemberName: "Anelise ou Matheus",
        objective: "O que foi feito, o que ajustar e melhorar",
      },
      {
        title: "Resumo automático das reuniões",
        frequency: "Após cada reunião",
        dayOfWeek: "Por evento",
        assigneeDescription: "A",
        defaultMemberName: "Anelise",
        objective: "Decisões e pendências em tópicos",
      },
      {
        title: "Registro de horas para medir",
        frequency: "2 a 4 semanas, para medir",
        dayOfWeek: "Mensal",
        assigneeDescription: "A+M",
        defaultMemberName: "Ambos",
        objective: "Horas por cliente e por serviço",
      },
    ],
  });

  // 8. Decisões em Aberto
  console.log("Seeding Decisões em Aberto...");
  await prisma.openDecision.deleteMany({});
  await prisma.openDecision.createMany({
    data: [
      {
        title: "Frequência das Reuniões com Clientes",
        description: "O catálogo diz 'reuniões mensais', e a transcrição fala em duas por mês (quinzenais). Qual vale para cada serviço, e o catálogo será atualizado?",
        status: "OPEN",
        assignee: "A+M",
      },
      {
        title: "Escopo e Revisões em Produção de Conteúdo (R$ 900)",
        description: "O valor é por sessão de 3 h com 6 vídeos? Quantas rodadas de revisão estão incluídas?",
        status: "OPEN",
        assignee: "A+M",
      },
      {
        title: "Verba de Anúncio no Combo Spotify + YouTube",
        description: "A verba de anúncio do YouTube está incluída nos R$ 599 ou é paga à parte pelo artista?",
        status: "OPEN",
        assignee: "M",
      },
      {
        title: "Responsabilidade pela Matéria no Site (Essentials e Combo)",
        description: "Quem escreve e publica o artigo no site oficial da Avera? (Sugestão do documento: Anelise)",
        status: "OPEN",
        assignee: "A",
      },
      {
        title: "Precificação do Planejamento de Lançamentos (R$ 450)",
        description: "O valor de R$ 450 cobre todo o trabalho de 13 passos descrito? Revisar a precificação antes de ofertar para novos artistas.",
        status: "OPEN",
        assignee: "A+M",
      },
      {
        title: "Definição de Escopo e Preço para Branding",
        description: "Definir o escopo detalhado de entregáveis, tabela de preços e incluir oficialmente no catálogo de serviços.",
        status: "OPEN",
        assignee: "M",
      },
      {
        title: "Parceiro e Margem em Produção Audiovisual",
        description: "Definir o fornecedor/terceiro homologado, os prazos de cada etapa e a margem de lucro da Avera.",
        status: "OPEN",
        assignee: "M",
      },
      {
        title: "Termo de Verba de Tráfego e Aporte Mínimo",
        description: "Escrever o texto padrão do termo e definir a política formal de verba mínima obrigatória para Meta Ads.",
        status: "OPEN",
        assignee: "M",
      },
      {
        title: "Regra Financeira: Execução antes do Pagamento",
        description: "Vale a regra estrita de iniciar a execução somente após a confirmação do pagamento para todos os serviços?",
        status: "OPEN",
        assignee: "A",
      },
      {
        title: "Limite de Clientes por Serviço (Capacidade Máxima)",
        description: "Estabelecer teto de clientes simultâneos por serviço (principalmente Redes Sociais e Planejamento) antes de abrir novas vagas comerciais.",
        status: "OPEN",
        assignee: "A+M",
      },
    ],
  });

  console.log(" Seed finalizado com sucesso!");
}

main()
  .catch((e) => {
    console.error("Erro no seed:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
