-- =========================================================================
-- POLÍTICAS DE ROW LEVEL SECURITY (RLS) - SUPABASE POSTGRESQL
-- SISTEMA AVERA COMPANY (ISOLAMENTO FINANCEIRO E PERMISSÕES POR PAPEL)
-- =========================================================================

-- 1. Habilita RLS em todas as tabelas sensíveis
ALTER TABLE "Member" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Project" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ProjectFinancial" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ServiceFinancial" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "Task" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ProcessTemplate" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "ProcessStep" ENABLE ROW LEVEL SECURITY;
ALTER TABLE "RoleTransferLog" ENABLE ROW LEVEL SECURITY;

-- 2. Função de segurança para checar se o usuário atual é ADMIN
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM "Member"
    WHERE id = auth.uid()::text AND "systemRole" = 'ADMIN'
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- -------------------------------------------------------------------------
-- TABELA PROJECTFINANCIAL (VALORES DE CONTRATO - RESTRITO EXCLUSIVAMENTE A ADMIN)
-- -------------------------------------------------------------------------
-- Membros comuns NÃO conseguem ler valores financeiros nem via API do Supabase no navegador.
CREATE POLICY "project_financial_admin_select" ON "ProjectFinancial"
FOR SELECT
USING (is_admin());

CREATE POLICY "project_financial_admin_all" ON "ProjectFinancial"
FOR ALL
USING (is_admin());

-- -------------------------------------------------------------------------
-- TABELA SERVICEFINANCIAL (PREÇOS BASE DO CATÁLOGO - RESTRITO A ADMIN)
-- -------------------------------------------------------------------------
CREATE POLICY "service_financial_admin_select" ON "ServiceFinancial"
FOR SELECT
USING (is_admin());

CREATE POLICY "service_financial_admin_all" ON "ServiceFinancial"
FOR ALL
USING (is_admin());

-- -------------------------------------------------------------------------
-- TABELA PROJECT (METADADOS DE PROJETO - CLIENTE, STATUS, DATAS)
-- -------------------------------------------------------------------------
-- Todos os membros autenticados podem consultar os projetos em andamento
CREATE POLICY "project_select_policy" ON "Project"
FOR SELECT
USING (auth.role() = 'authenticated');

-- Apenas ADMIN cria, edita ou exclui projetos
CREATE POLICY "project_admin_modify_policy" ON "Project"
FOR ALL
USING (is_admin());

-- -------------------------------------------------------------------------
-- TABELA TASK (TAREFAS OPERACIONAIS)
-- -------------------------------------------------------------------------
-- Leitura de Tarefas: Admins veem todas; Membros veem suas tarefas e tarefas públicas do projeto
CREATE POLICY "task_select_policy" ON "Task"
FOR SELECT
USING (
  is_admin() OR "assigneeId" = auth.uid()::text OR "assigneeId" IS NULL
);

-- Edição de Tarefas: O membro só pode atualizar as tarefas atribuídas a ele (assigneeId)
CREATE POLICY "task_update_policy" ON "Task"
FOR UPDATE
USING (
  is_admin() OR "assigneeId" = auth.uid()::text
)
WITH CHECK (
  is_admin() OR "assigneeId" = auth.uid()::text
);

-- Criação e Exclusão de Tarefas: Apenas ADMIN
CREATE POLICY "task_admin_all_policy" ON "Task"
FOR INSERT
WITH CHECK (is_admin());

CREATE POLICY "task_delete_policy" ON "Task"
FOR DELETE
USING (is_admin());

-- -------------------------------------------------------------------------
-- TABELA ROLETRANSFERLOG (AUDITORIA DE TRANSFERÊNCIAS)
-- -------------------------------------------------------------------------
CREATE POLICY "audit_admin_only" ON "RoleTransferLog"
FOR ALL
USING (is_admin());
