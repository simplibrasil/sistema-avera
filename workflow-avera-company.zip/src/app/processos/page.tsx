import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { sanitizeServicesFinancials } from "@/lib/security";
import { ProcessLibraryView } from "@/components/processes/process-library-view";

export const dynamic = "force-dynamic";

export default async function ProcessosPage() {
  const currentUser = await getCurrentUser();
  const isAdmin = currentUser?.systemRole === "ADMIN";

  let services: any[] = [];
  let commonProcess: any = null;
  let operationalRoles: any[] = [];

  try {
    const rawServices = await prisma.service.findMany({
      include: {
        financial: true,
        area: {
          select: { id: true, name: true, color: true },
        },
        templates: {
          include: {
            steps: {
              include: {
                defaultRole: {
                  select: { id: true, name: true },
                },
              },
              orderBy: { order: "asc" },
            },
          },
        },
      },
      orderBy: { name: "asc" },
    });

    services = sanitizeServicesFinancials(rawServices, currentUser);

    commonProcess = await prisma.processTemplate.findFirst({
      where: { serviceId: null },
      include: {
        steps: {
          include: {
            defaultRole: {
              select: { id: true, name: true },
            },
          },
          orderBy: { order: "asc" },
        },
      },
    });

    operationalRoles = await prisma.operationalRole.findMany({
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    });
  } catch (error) {
    console.error("Erro ao carregar processos:", error);
  }

  return (
    <ProcessLibraryView
      services={services}
      commonProcess={commonProcess}
      operationalRoles={operationalRoles}
      isAdmin={isAdmin}
    />
  );
}
