import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { TeamClientView } from "@/components/team/team-client-view";
import { getTransferAuditLogs } from "@/app/actions/team-actions";

export const dynamic = "force-dynamic";

export default async function EquipePage() {
  const currentUser = await getCurrentUser();
  const isAdmin = currentUser?.systemRole === "ADMIN";

  let members: any[] = [];
  let operationalRoles: any[] = [];
  let auditLogs: any[] = [];

  try {
    members = await prisma.member.findMany({
      where: { active: true },
      include: {
        memberRoles: {
          include: {
            operationalRole: true,
          },
        },
        _count: {
          select: {
            assignedTasks: {
              where: { status: { not: "DONE" } },
            },
          },
        },
      },
      orderBy: { name: "asc" },
    });

    operationalRoles = await prisma.operationalRole.findMany({
      include: {
        memberRoles: {
          include: {
            member: {
              select: { id: true, name: true },
            },
          },
        },
      },
      orderBy: { name: "asc" },
    });

    if (isAdmin) {
      auditLogs = await getTransferAuditLogs();
    }
  } catch (error) {
    console.error("Erro ao carregar equipe:", error);
  }

  return (
    <TeamClientView
      members={members}
      operationalRoles={operationalRoles}
      auditLogs={auditLogs}
      isAdmin={isAdmin}
    />
  );
}
