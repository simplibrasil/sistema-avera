import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { MyTasksView } from "@/components/tasks/my-tasks-view";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const currentUser = await getCurrentUser();
  const isAdmin = currentUser?.systemRole === "ADMIN";

  let tasks: any[] = [];

  try {
    tasks = await prisma.task.findMany({
      include: {
        assignee: {
          select: { id: true, name: true },
        },
        project: {
          include: {
            client: {
              select: { id: true, name: true },
            },
            service: {
              include: {
                area: {
                  select: { id: true, name: true, color: true },
                },
              },
            },
          },
        },
      },
      orderBy: [{ dueDate: "asc" }, { order: "asc" }],
    });
  } catch (error) {
    console.error("Erro ao carregar tarefas:", error);
  }

  return (
    <MyTasksView
      tasks={tasks}
      currentUserId={currentUser?.id || ""}
      currentUserName={currentUser?.name || "Colaborador"}
      isAdmin={isAdmin}
    />
  );
}
