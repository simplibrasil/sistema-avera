import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { WorkloadView } from "@/components/workload/workload-view";

export const dynamic = "force-dynamic";

export default async function CargaPage() {
  await getCurrentUser();

  const now = new Date();
  const todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const endOfWeek = new Date(todayMidnight);
  endOfWeek.setDate(todayMidnight.getDate() + (7 - todayMidnight.getDay()));

  let workloads: any[] = [];
  let areas: any[] = [];

  try {
    const members = await prisma.member.findMany({
      where: { active: true },
      include: {
        memberRoles: {
          include: {
            operationalRole: true,
          },
        },
        assignedTasks: {
          where: { status: { not: "DONE" } },
          include: {
            project: {
              include: {
                client: { select: { name: true } },
                service: {
                  include: {
                    area: { select: { id: true, name: true, color: true } },
                  },
                },
              },
            },
          },
          orderBy: { dueDate: "asc" },
        },
      },
      orderBy: { name: "asc" },
    });

    areas = await prisma.area.findMany({
      select: { id: true, name: true, color: true },
      orderBy: { name: "asc" },
    });

    workloads = members.map((m) => {
      const openTasks = m.assignedTasks;
      const overdueTasks = openTasks.filter(
        (t) => t.dueDate && new Date(t.dueDate) < todayMidnight
      ).length;

      const todayTasks = openTasks.filter((t) => {
        if (!t.dueDate) return false;
        const d = new Date(t.dueDate);
        return (
          d.getFullYear() === todayMidnight.getFullYear() &&
          d.getMonth() === todayMidnight.getMonth() &&
          d.getDate() === todayMidnight.getDate()
        );
      }).length;

      const thisWeekTasks = openTasks.filter((t) => {
        if (!t.dueDate) return false;
        const d = new Date(t.dueDate);
        return d > todayMidnight && d <= endOfWeek;
      }).length;

      const nextWeeksTasks = openTasks.filter((t) => {
        if (!t.dueDate) return false;
        const d = new Date(t.dueDate);
        return d > endOfWeek;
      }).length;

      // Agrupamento por Área
      const areaMap: Record<string, { areaId: string; areaName: string; areaColor: string; count: number }> = {};
      for (const t of openTasks) {
        const a = t.project.service.area;
        if (!areaMap[a.id]) {
          areaMap[a.id] = { areaId: a.id, areaName: a.name, areaColor: a.color, count: 0 };
        }
        areaMap[a.id].count++;
      }

      // Regra de Sobrecarga
      let isOverloaded = false;
      let overloadReason = "";
      if (overdueTasks >= 2) {
        isOverloaded = true;
        overloadReason = `${overdueTasks} tarefas com prazo vencido`;
      } else if (thisWeekTasks >= 8) {
        isOverloaded = true;
        overloadReason = `${thisWeekTasks} tarefas concentradas nesta semana`;
      } else if (openTasks.length >= 15) {
        isOverloaded = true;
        overloadReason = `Volume alto: ${openTasks.length} tarefas ativas simultâneas`;
      }

      return {
        member: {
          id: m.id,
          name: m.name,
          email: m.email,
          systemRole: m.systemRole,
          roles: m.memberRoles.map((mr) => mr.operationalRole.name),
        },
        totalOpenTasks: openTasks.length,
        overdueTasks,
        todayTasks,
        thisWeekTasks,
        nextWeeksTasks,
        isOverloaded,
        overloadReason,
        tasksByArea: Object.values(areaMap),
        recentTasks: openTasks.map((t) => ({
          id: t.id,
          title: t.title,
          clientName: t.project.client.name,
          serviceName: t.project.service.name,
          dueDate: t.dueDate,
          status: t.status,
          isOverdue: !!(t.dueDate && new Date(t.dueDate) < todayMidnight),
        })),
      };
    });
  } catch (error) {
    console.error("Erro ao calcular carga da equipe:", error);
  }

  return <WorkloadView workloads={workloads} areas={areas} />;
}
