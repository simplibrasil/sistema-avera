import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { ProjectsView } from "@/components/projects/projects-view";
import { sanitizeProjectsFinancials } from "@/lib/security";

export const dynamic = "force-dynamic";

export default async function ProjetosPage() {
  const currentUser = await getCurrentUser();
  const isAdmin = currentUser?.systemRole === "ADMIN";

  let projects: any[] = [];
  let clients: any[] = [];
  let services: any[] = [];
  let members: any[] = [];

  try {
    const rawProjects = await prisma.project.findMany({
      include: {
        financial: true,
        client: {
          include: {
            whatsappLead: {
              select: { id: true, name: true },
            },
          },
        },
        service: {
          include: {
            financial: true,
            area: {
              select: { id: true, name: true, color: true },
            },
          },
        },
        tasks: {
          include: {
            assignee: {
              select: { id: true, name: true },
            },
          },
          orderBy: { order: "asc" },
        },
      },
      orderBy: { createdAt: "desc" },
    });

    projects = sanitizeProjectsFinancials(rawProjects, currentUser);

    clients = await prisma.client.findMany({
      where: { active: true },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    });

    services = await prisma.service.findMany({
      where: { active: true },
      include: {
        financial: true,
        area: {
          select: { name: true, color: true },
        },
      },
      orderBy: { name: "asc" },
    });

    members = await prisma.member.findMany({
      where: { active: true },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    });
  } catch (error) {
    console.error("Erro ao carregar projetos:", error);
  }

  return (
    <ProjectsView
      projects={projects}
      clients={clients}
      services={services}
      members={members}
      isAdmin={isAdmin}
    />
  );
}
