import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { RitualsDecisionsView } from "@/components/rituals/rituals-decisions-view";

export const dynamic = "force-dynamic";

type RitualItem = {
  id: string;
  title: string;
  frequency: string;
  dayOfWeek: string | null;
  assigneeDescription: string;
  defaultMemberName: string | null;
  objective: string;
};

const DEFAULT_RITUALS: RitualItem[] = [
  {
    id: "r1",
    title: "Acompanhamento de tráfego",
    frequency: "2x por semana (ex.: terça e sexta)",
    dayOfWeek: "Terça e Sexta",
    assigneeDescription: "M",
    defaultMemberName: "Matheus",
    objective: "Gasto, saldo, reprovações e ajustes de todas as campanhas",
  },
  {
    id: "r2",
    title: "Relatório de tráfego",
    frequency: "Sexta",
    dayOfWeek: "Sexta",
    assigneeDescription: "M exporta, A monta",
    defaultMemberName: "Matheus / Anelise",
    objective: "Relatório pronto para a reunião mensal",
  },
  {
    id: "r3",
    title: "Bloco do Instagram da Avera Records",
    frequency: "1x por semana",
    dayOfWeek: "Semanal",
    assigneeDescription: "M",
    defaultMemberName: "Matheus",
    objective: "Postar e planejar a marca própria",
  },
  {
    id: "r4",
    title: "Bloco do Instagram da Avera Company",
    frequency: "1x por semana",
    dayOfWeek: "Semanal",
    assigneeDescription: "A",
    defaultMemberName: "Anelise",
    objective: "Postar e planejar a marca própria",
  },
  {
    id: "r5",
    title: "Playlists e Spotify",
    frequency: "Semanal (junto ao tráfego)",
    dayOfWeek: "Semanal",
    assigneeDescription: "M",
    defaultMemberName: "Matheus",
    objective: "Conferir posição e números dos clientes de playlist",
  },
  {
    id: "r6",
    title: "Reunião de projeto",
    frequency: "Quinzenal, alternando A e M",
    dayOfWeek: "Quinzenal",
    assigneeDescription: "A ou M",
    defaultMemberName: "Anelise ou Matheus",
    objective: "Entender o projeto e o que será feito",
  },
  {
    id: "r7",
    title: "Reunião de resultados",
    frequency: "Quinzenal",
    dayOfWeek: "Quinzenal",
    assigneeDescription: "A ou M",
    defaultMemberName: "Anelise ou Matheus",
    objective: "O que foi feito, o que ajustar e melhorar",
  },
  {
    id: "r8",
    title: "Resumo automático das reuniões",
    frequency: "Após cada reunião",
    dayOfWeek: "Por evento",
    assigneeDescription: "A",
    defaultMemberName: "Anelise",
    objective: "Decisões e pendências em tópicos",
  },
  {
    id: "r9",
    title: "Registro de horas para medir",
    frequency: "2 a 4 semanas, para medir",
    dayOfWeek: "Mensal",
    assigneeDescription: "A+M",
    defaultMemberName: "Ambos",
    objective: "Horas por cliente e por serviço",
  },
];

const DEFAULT_DECISIONS = [
  {
    id: "d1",
    title: "Frequência das Reuniões com Clientes",
    description: "O catálogo diz 'reuniões mensais', e a transcrição fala em duas por mês (quinzenais). Qual vale para cada serviço, e o catálogo será atualizado?",
    assignee: "A+M",
    status: "OPEN" as const,
    resolutionNotes: null,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "d2",
    title: "Escopo e Revisões em Produção de Conteúdo (R$ 900)",
    description: "O valor é por sessão de 3 h com 6 vídeos? Quantas rodadas de revisão estão incluídas?",
    assignee: "A+M",
    status: "OPEN" as const,
    resolutionNotes: null,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "d3",
    title: "Verba de Anúncio no Combo Spotify + YouTube",
    description: "A verba de anúncio do YouTube está incluída nos R$ 599 ou é paga à parte pelo artista?",
    assignee: "M",
    status: "OPEN" as const,
    resolutionNotes: null,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "d4",
    title: "Responsabilidade pela Matéria no Site (Essentials e Combo)",
    description: "Quem escreve e publica o artigo no site oficial da Avera? (Sugestão do documento: Anelise)",
    assignee: "A",
    status: "OPEN" as const,
    resolutionNotes: null,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "d5",
    title: "Precificação do Planejamento de Lançamentos (R$ 450)",
    description: "O valor de R$ 450 cobre todo o trabalho de 13 passos descrito? Revisar a precificação antes de ofertar para novos artistas.",
    assignee: "A+M",
    status: "OPEN" as const,
    resolutionNotes: null,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "d6",
    title: "Definição de Escopo e Preço para Branding",
    description: "Definir o escopo detalhado de entregáveis, tabela de preços e incluir oficialmente no catálogo de serviços.",
    assignee: "M",
    status: "OPEN" as const,
    resolutionNotes: null,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "d7",
    title: "Parceiro e Margem em Produção Audiovisual",
    description: "Definir o fornecedor/terceiro homologado, os prazos de cada etapa e a margem de lucro da Avera.",
    assignee: "M",
    status: "OPEN" as const,
    resolutionNotes: null,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "d8",
    title: "Termo de Verba de Tráfego e Aporte Mínimo",
    description: "Escrever o texto padrão do termo e definir a política formal de verba mínima obrigatória para Meta Ads.",
    assignee: "M",
    status: "OPEN" as const,
    resolutionNotes: null,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "d9",
    title: "Regra Financeira: Execução antes do Pagamento",
    description: "Vale a regra estrita de iniciar a execução somente após a confirmação do pagamento para todos os serviços?",
    assignee: "A",
    status: "OPEN" as const,
    resolutionNotes: null,
    updatedAt: new Date().toISOString(),
  },
  {
    id: "d10",
    title: "Limite de Clientes por Serviço (Capacidade Máxima)",
    description: "Estabelecer teto de clientes simultâneos por serviço (principalmente Redes Sociais e Planejamento) antes de abrir novas vagas comerciais.",
    assignee: "A+M",
    status: "OPEN" as const,
    resolutionNotes: null,
    updatedAt: new Date().toISOString(),
  },
];

export default async function RituaisPage() {
  const currentUser = await getCurrentUser();
  const isAdmin = currentUser?.systemRole === "ADMIN";

  let rituals = DEFAULT_RITUALS;
  let decisions = DEFAULT_DECISIONS;

  try {
    const dbRituals = await prisma.recurringRitual.findMany({
      orderBy: { createdAt: "asc" },
    });
    if (dbRituals && dbRituals.length > 0) {
      rituals = dbRituals;
    }

    const dbDecisions = await prisma.openDecision.findMany({
      orderBy: { createdAt: "asc" },
    });
    if (dbDecisions && dbDecisions.length > 0) {
      decisions = dbDecisions as any;
    }
  } catch (error) {
    console.error("Erro ao carregar rituais do banco, exibindo valores oficiais:", error);
  }

  return (
    <RitualsDecisionsView
      rituals={rituals}
      decisions={decisions}
      isAdmin={isAdmin}
    />
  );
}
