import type { Metadata } from "next";
import "./globals.css";
import { ThemeProvider } from "@/components/theme-provider";
import { AppShell } from "@/components/layout/app-shell";
import { getCurrentUser } from "@/lib/auth";
import prisma from "@/lib/prisma";

export const metadata: Metadata = {
  title: "Workflow Avera Company",
  description: "Sistema interno de operações e processos da Avera Company",
};

export default async function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  const currentUser = await getCurrentUser();
  const isDev = process.env.NODE_ENV === "development";
  let allMembers: { id: string; name: string; systemRole: string }[] = [];

  if (isDev) {
    try {
      allMembers = await prisma.member.findMany({
        where: { active: true },
        select: { id: true, name: true, systemRole: true },
        orderBy: { name: "asc" },
      });
    } catch {
      // Banco ainda inicializando
    }

    if (allMembers.length === 0) {
      allMembers = [
        { id: "dev-matheus", name: "Matheus", systemRole: "ADMIN" },
        { id: "dev-anelise", name: "Anelise", systemRole: "ADMIN" },
      ];
    }
  }

  return (
    <html lang="pt-BR" suppressHydrationWarning className="dark">
      <body className="bg-[#0d0e14] text-slate-100 min-h-screen antialiased">
        <ThemeProvider attribute="class" defaultTheme="dark" enableSystem={false}>
          <AppShell currentUser={currentUser} allMembers={allMembers} isDev={isDev}>
            {children}
          </AppShell>
        </ThemeProvider>
      </body>
    </html>
  );
}
