import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { KanbanBoard } from "@/components/kanban/kanban-board";

export const dynamic = "force-dynamic";

export default async function KanbanPage() {
  await getCurrentUser();

  let tasks: any[] = [];
  let members: any[] = [];
  let areas: any[] = [];
  let clients: any[] = [];
  let services: any[] = [];

  try {
    tasks = await prisma.task.findMany({
      include: {
        assignee: { select: { id: true, name: true } },
        project: {
          include: {
            client: { select: { id: true, name: true } },
            service: {
              include: {
                area: { select: { id: true, name: true, color: true } },
              },
            },
          },
        },
      },
      orderBy: [{ dueDate: "asc" }, { order: "asc" }],
    });

    members = await prisma.member.findMany({
      where: { active: true },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    });

    areas = await prisma.area.findMany({
      select: { id: true, name: true, color: true },
      orderBy: { name: "asc" },
    });

    clients = await prisma.client.findMany({
      where: { active: true },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    });

    services = await prisma.service.findMany({
      where: { active: true },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    });
  } catch (error) {
    console.error("Erro ao carregar Kanban:", error);
  }

  return (
    <KanbanBoard
      tasks={tasks}
      members={members}
      areas={areas}
      clients={clients}
      services={services}
    />
  );
}
