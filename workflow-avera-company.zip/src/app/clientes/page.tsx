import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { ClientsDatabaseView } from "@/components/clients/clients-database-view";

export const dynamic = "force-dynamic";

// Clientes padrão oficiais da Avera Records do documento
const DEFAULT_CLIENTS = [
  {
    id: "c-santta",
    name: "Santta",
    contactPerson: "Santta",
    whatsapp: "11 98888-0001",
    whatsappLeadId: "lead-a",
    driveFolderUrl: null,
    notes: "Gestão de Tráfego e Redes Sociais ativas.",
    active: true,
    createdAt: new Date().toISOString(),
    whatsappLead: { id: "lead-a", name: "Anelise" },
    projects: [
      { id: "p1", name: "Tráfego Pago", status: "IN_PROGRESS", service: { id: "s1", name: "Gestão de Tráfego", area: { name: "Tráfego Pago", color: "#3B82F6" } } },
      { id: "p2", name: "Redes Sociais", status: "IN_PROGRESS", service: { id: "s2", name: "Gestão de Redes Sociais", area: { name: "Redes Sociais e Conteúdo", color: "#EC4899" } } },
    ],
  },
  {
    id: "c-theaga",
    name: "Theaga",
    contactPerson: "Theaga",
    whatsapp: "11 98888-0002",
    whatsappLeadId: "lead-m",
    driveFolderUrl: null,
    notes: "Lançamento de Single e Curadoria de Playlists.",
    active: true,
    createdAt: new Date().toISOString(),
    whatsappLead: { id: "lead-m", name: "Matheus" },
    projects: [
      { id: "p3", name: "Lançamento Single", status: "IN_PROGRESS", service: { id: "s3", name: "Planejamento de Lançamentos", area: { name: "Música", color: "#8B5CF6" } } },
    ],
  },
  {
    id: "c-teuz",
    name: "Teuz",
    contactPerson: "Teuz",
    whatsapp: "11 98888-0003",
    whatsappLeadId: "lead-a",
    driveFolderUrl: null,
    notes: "Produção de Conteúdo mensal com captação de reels.",
    active: true,
    createdAt: new Date().toISOString(),
    whatsappLead: { id: "lead-a", name: "Anelise" },
    projects: [
      { id: "p4", name: "Conteúdo Mensal", status: "IN_PROGRESS", service: { id: "s4", name: "Produção de Conteúdo", area: { name: "Produção Audiovisual", color: "#F59E0B" } } },
    ],
  },
  {
    id: "c-nle",
    name: "NLE Kira",
    contactPerson: "NLE Kira",
    whatsapp: "11 98888-0004",
    whatsappLeadId: "lead-m",
    driveFolderUrl: null,
    notes: "Campanhas de tráfego Meta Ads.",
    active: true,
    createdAt: new Date().toISOString(),
    whatsappLead: { id: "lead-m", name: "Matheus" },
    projects: [
      { id: "p5", name: "Tráfego Pago", status: "IN_PROGRESS", service: { id: "s1", name: "Gestão de Tráfego", area: { name: "Tráfego Pago", color: "#3B82F6" } } },
    ],
  },
  {
    id: "c-drik",
    name: "Drik Barbosa",
    contactPerson: "Drik Barbosa",
    whatsapp: "11 98888-0005",
    whatsappLeadId: "lead-a",
    driveFolderUrl: null,
    notes: "Registro autoral e distribuição digital.",
    active: true,
    createdAt: new Date().toISOString(),
    whatsappLead: { id: "lead-a", name: "Anelise" },
    projects: [
      { id: "p6", name: "Registro e Distribuição", status: "IN_PROGRESS", service: { id: "s5", name: "Registro Autoral e Distribuição", area: { name: "Música", color: "#8B5CF6" } } },
    ],
  },
  {
    id: "c-igor",
    name: "Igor",
    contactPerson: "Igor",
    whatsapp: "11 98888-0006",
    whatsappLeadId: "lead-a",
    driveFolderUrl: null,
    notes: "Planejamento de conteúdo e posicionamento.",
    active: true,
    createdAt: new Date().toISOString(),
    whatsappLead: { id: "lead-a", name: "Anelise" },
    projects: [],
  },
  {
    id: "c-paula",
    name: "Paula",
    contactPerson: "Paula",
    whatsapp: "11 98888-0007",
    whatsappLeadId: "lead-a",
    driveFolderUrl: null,
    notes: "Redes sociais e lançamentos.",
    active: true,
    createdAt: new Date().toISOString(),
    whatsappLead: { id: "lead-a", name: "Anelise" },
    projects: [],
  },
  {
    id: "c-sanjoe",
    name: "San Joe",
    contactPerson: "San Joe",
    whatsapp: "11 98888-0008",
    whatsappLeadId: "lead-m",
    driveFolderUrl: null,
    notes: "Tráfego pago e playlists Spotify.",
    active: true,
    createdAt: new Date().toISOString(),
    whatsappLead: { id: "lead-m", name: "Matheus" },
    projects: [],
  },
  {
    id: "c-outrolado",
    name: "Outro Lado",
    contactPerson: "Outro Lado",
    whatsapp: "11 98888-0009",
    whatsappLeadId: "lead-m",
    driveFolderUrl: null,
    notes: "Combo Spotify + YouTube e direção criativa.",
    active: true,
    createdAt: new Date().toISOString(),
    whatsappLead: { id: "lead-m", name: "Matheus" },
    projects: [],
  },
];

export default async function ClientesPage() {
  const currentUser = await getCurrentUser();
  const isAdmin = currentUser?.systemRole === "ADMIN";

  let clients: any[] = DEFAULT_CLIENTS;
  let members: any[] = [
    { id: "lead-a", name: "Anelise" },
    { id: "lead-m", name: "Matheus" },
  ];

  try {
    const dbClients = await prisma.client.findMany({
      include: {
        whatsappLead: { select: { id: true, name: true } },
        projects: {
          include: {
            service: {
              include: {
                area: { select: { name: true, color: true } },
              },
            },
          },
          orderBy: { createdAt: "desc" },
        },
      },
      orderBy: { name: "asc" },
    });

    if (dbClients && dbClients.length > 0) {
      clients = dbClients;
    }

    const dbMembers = await prisma.member.findMany({
      where: { active: true },
      select: { id: true, name: true },
      orderBy: { name: "asc" },
    });

    if (dbMembers && dbMembers.length > 0) {
      members = dbMembers;
    }
  } catch (error) {
    console.error("Erro ao carregar clientes do banco:", error);
  }

  return (
    <ClientsDatabaseView
      clients={clients}
      members={members}
      isAdmin={isAdmin}
    />
  );
}
