import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { formatDateBR } from "@/lib/date-utils";
import { Layers, Calendar, User, CheckCircle2, Clock } from "lucide-react";

export const dynamic = "force-dynamic";

export default async function AreasPage() {
  await getCurrentUser();

  let areas: any[] = [];

  try {
    areas = await prisma.area.findMany({
      include: {
        services: {
          include: {
            projects: {
              where: { status: "IN_PROGRESS" },
              include: {
                client: { select: { name: true } },
                tasks: {
                  where: { status: { not: "DONE" } },
                  include: {
                    assignee: { select: { name: true } },
                  },
                  orderBy: { dueDate: "asc" },
                },
              },
            },
          },
        },
      },
      orderBy: { name: "asc" },
    });
  } catch (error) {
    console.error("Erro ao carregar áreas:", error);
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-[#232738]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md">
              <Layers className="w-4 h-4" />
            </div>
            Visão Operacional por Área
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Acompanhe o fluxo de entrega de cada um dos setores e departamentos da Avera.
          </p>
        </div>
      </div>

      <div className="space-y-6">
        {areas.map((area) => {
          // Coleta todas as tarefas abertas desta área
          const allAreaTasks: any[] = [];
          for (const s of area.services) {
            for (const p of s.projects) {
              for (const t of p.tasks) {
                allAreaTasks.push({
                  ...t,
                  clientName: p.client.name,
                  serviceName: s.name,
                });
              }
            }
          }

          return (
            <div
              key={area.id}
              className="p-5 rounded-2xl bg-[#151722] border border-[#232738] shadow-sm space-y-4 hover:border-[#38415d] transition"
            >
              {/* Header da Área */}
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2.5">
                  <span
                    className="w-3.5 h-3.5 rounded-full shadow-md"
                    style={{ backgroundColor: area.color }}
                  />
                  <h2 className="text-base font-bold text-white">
                    {area.name}
                  </h2>
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#111218] border border-[#232738] text-slate-300 font-semibold">
                    {allAreaTasks.length} {allAreaTasks.length === 1 ? "tarefa aberta" : "tarefas abertas"}
                  </span>
                </div>
                <p className="text-xs text-slate-400 hidden sm:block">{area.description}</p>
              </div>

              {/* Lista de Tarefas da Área */}
              {allAreaTasks.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-500 bg-[#111218] border border-dashed border-[#232738] rounded-xl italic">
                  Nenhuma tarefa pendente nesta área no momento.
                </div>
              ) : (
                <div className="divide-y divide-[#1f2333] bg-[#111218] border border-[#232738] rounded-xl p-2">
                  {allAreaTasks.slice(0, 8).map((task) => (
                    <div
                      key={task.id}
                      className="py-2.5 px-3 flex items-center justify-between text-xs hover:bg-[#191c2a] rounded-lg transition"
                    >
                      <div className="flex items-center gap-2.5 max-w-[65%]">
                        <Clock className="w-3.5 h-3.5 text-indigo-400 shrink-0" />
                        <div>
                          <p className="font-semibold text-white line-clamp-1">
                            {task.title}
                          </p>
                          <p className="text-[11px] text-slate-400">
                            {task.clientName} • {task.serviceName}
                          </p>
                        </div>
                      </div>

                      <div className="text-right flex items-center gap-4">
                        <span className="text-[11px] text-slate-400 font-medium hidden sm:inline">
                          Resp: {task.assignee?.name || "Sem responsável"}
                        </span>
                        <span className="text-xs font-semibold text-slate-300 flex items-center gap-1.5 bg-[#151722] px-2 py-1 rounded-lg border border-[#232738]">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          {formatDateBR(task.dueDate)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
