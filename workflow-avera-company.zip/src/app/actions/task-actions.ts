"use server";

import prisma from "@/lib/prisma";
import { requireAuth } from "@/lib/auth";
import { authorizeTaskModification } from "@/lib/security";
import { revalidatePath } from "next/cache";

export async function toggleTaskStatus(taskId: string, newStatus: "TODO" | "IN_PROGRESS" | "WAITING_CLIENT" | "IN_REVIEW" | "DONE") {
  const user = await requireAuth();

  // Validação estrita de segurança no servidor
  await authorizeTaskModification(taskId, user);

  try {
    const updated = await prisma.task.update({
      where: { id: taskId },
      data: {
        status: newStatus,
        completedAt: newStatus === "DONE" ? new Date() : null,
      },
    });

    revalidatePath("/");
    revalidatePath("/kanban");
    revalidatePath("/carga");
    revalidatePath("/clientes");
    return { success: true, task: updated };
  } catch (error: any) {
    return { error: error.message || "Erro ao atualizar status da tarefa." };
  }
}

export async function updateTaskAssignee(taskId: string, assigneeId: string | null) {
  const user = await requireAuth();
  if (user.systemRole !== "ADMIN") {
    throw new Error("Apenas administradores podem reatribuir tarefas individualmente.");
  }

  try {
    const updated = await prisma.task.update({
      where: { id: taskId },
      data: {
        assigneeId: assigneeId || null,
      },
    });

    revalidatePath("/");
    revalidatePath("/kanban");
    revalidatePath("/carga");
    return { success: true, task: updated };
  } catch (error: any) {
    return { error: error.message || "Erro ao reatribuir responsável." };
  }
}
