"use server";

import { createClient } from "@/lib/supabase/server";
import prisma from "@/lib/prisma";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";

const IS_DEVELOPMENT = process.env.NODE_ENV === "development";

export async function loginWithEmail(formData: FormData) {
  const email = formData.get("email") as string;
  const password = formData.get("password") as string;

  if (!email || !password) {
    return { error: "Informe e-mail e senha." };
  }

  try {
    const supabase = await createClient();
    const { data, error } = await supabase.auth.signInWithPassword({
      email,
      password,
    });

    if (error) {
      // TRAVA DE SEGURANÇA: Login local alternativo SOMENTE em desenvolvimento
      if (IS_DEVELOPMENT) {
        const localMember = await prisma.member.findUnique({
          where: { email },
        });

        if (localMember) {
          const cookieStore = await cookies();
          cookieStore.set("avera_dev_member_id", localMember.id, {
            path: "/",
            httpOnly: true,
            sameSite: "lax",
          });
          redirect("/");
        }
      }

      return { error: error.message || "Credenciais inválidas no Supabase Auth." };
    }

    if (data.user) {
      redirect("/");
    }
  } catch (err: any) {
    if (err?.message === "NEXT_REDIRECT") throw err;
    return { error: "Erro ao processar login. Tente novamente." };
  }

  redirect("/");
}

export async function switchDevUser(memberId: string) {
  // TRAVA DE SEGURANÇA: Bloqueado categoricamente em ambiente de produção
  if (!IS_DEVELOPMENT) {
    throw new Error("Ação não permitida em ambiente de produção.");
  }

  const cookieStore = await cookies();
  cookieStore.set("avera_dev_member_id", memberId, {
    path: "/",
    httpOnly: true,
    sameSite: "lax",
  });
  return { success: true };
}

export async function logoutUser() {
  try {
    const supabase = await createClient();
    await supabase.auth.signOut();
  } catch {}

  const cookieStore = await cookies();
  cookieStore.delete("avera_dev_member_id");
  redirect("/login");
}
