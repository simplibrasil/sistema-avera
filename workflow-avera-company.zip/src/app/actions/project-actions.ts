"use server";

import prisma from "@/lib/prisma";
import { requireAuth, requireAdmin } from "@/lib/auth";
import { createProjectAndGenerateTasks, generateNextMonthlyCycle } from "@/lib/task-engine";
import { revalidatePath } from "next/cache";

export async function createClientAction(formData: FormData) {
  await requireAuth();

  const name = formData.get("name") as string;
  const whatsapp = formData.get("whatsapp") as string;
  const whatsappLeadId = formData.get("whatsappLeadId") as string;
  const notes = formData.get("notes") as string;

  if (!name) {
    return { error: "Nome do cliente é obrigatório." };
  }

  try {
    const client = await prisma.client.create({
      data: {
        name: name.trim(),
        whatsapp: whatsapp ? whatsapp.trim() : null,
        whatsappLeadId: whatsappLeadId || null,
        notes: notes ? notes.trim() : null,
      },
    });

    revalidatePath("/clientes");
    return { success: true, clientId: client.id };
  } catch (error: any) {
    return { error: error.message || "Erro ao cadastrar cliente." };
  }
}

export async function createProjectAction(data: {
  clientId: string;
  serviceId: string;
  name?: string;
  value?: number | null;
  startDate?: string;
  recordingDate?: string | null;
  releaseDate?: string | null;
  cycleStartDate?: string | null;
}) {
  const user = await requireAuth();

  // Se o usuário não for ADMIN, ele não pode definir valores financeiros customizados
  let sanitizedValue = data.value;
  if (user.systemRole !== "ADMIN") {
    sanitizedValue = null;
  }

  try {
    const result = await createProjectAndGenerateTasks({
      clientId: data.clientId,
      serviceId: data.serviceId,
      name: data.name,
      value: sanitizedValue,
      startDate: data.startDate,
      recordingDate: data.recordingDate,
      releaseDate: data.releaseDate,
      cycleStartDate: data.cycleStartDate,
    });

    revalidatePath("/clientes");
    revalidatePath("/");
    revalidatePath("/kanban");
    revalidatePath("/carga");
    return { success: true, project: result.project, tasksCount: result.tasksCount };
  } catch (error: any) {
    return { error: error.message || "Erro ao criar projeto e gerar tarefas." };
  }
}

export async function updateProjectStatusAction(projectId: string, status: any) {
  await requireAdmin();

  try {
    await prisma.project.update({
      where: { id: projectId },
      data: { status },
    });

    revalidatePath("/clientes");
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Erro ao atualizar status do projeto." };
  }
}

export async function triggerNextCycleAction(projectId: string) {
  await requireAdmin();

  try {
    const res = await generateNextMonthlyCycle(projectId);
    revalidatePath("/clientes");
    revalidatePath("/");
    revalidatePath("/kanban");
    return { success: true, newCycle: res.newCycleNumber, tasksCount: res.tasksCount };
  } catch (error: any) {
    return { error: error.message || "Erro ao avançar ciclo do projeto." };
  }
}
