"use server";

import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { revalidatePath } from "next/cache";

export async function updateOpenDecisionAction(data: {
  id: string;
  status: "OPEN" | "IN_DISCUSSION" | "RESOLVED";
  resolutionNotes?: string;
  assignee?: string;
}) {
  const user = await getCurrentUser();
  if (!user) {
    return { error: "Não autenticado." };
  }

  try {
    const updated = await prisma.openDecision.update({
      where: { id: data.id },
      data: {
        status: data.status,
        resolutionNotes: data.resolutionNotes !== undefined ? data.resolutionNotes.trim() : undefined,
        assignee: data.assignee !== undefined ? data.assignee.trim() : undefined,
      },
    });

    revalidatePath("/rituais");
    return { success: true, decision: updated };
  } catch (error: any) {
    return { error: error.message || "Erro ao atualizar status da decisão." };
  }
}
