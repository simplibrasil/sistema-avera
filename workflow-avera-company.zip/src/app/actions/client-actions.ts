"use server";

import prisma from "@/lib/prisma";
import { requireAuth, requireAdmin } from "@/lib/auth";
import { revalidatePath } from "next/cache";

export async function createClientAction(formData: FormData) {
  await requireAuth();

  const name = formData.get("name") as string;
  const whatsapp = formData.get("whatsapp") as string;
  const whatsappLeadId = formData.get("whatsappLeadId") as string;
  const driveFolderUrl = formData.get("driveFolderUrl") as string;
  const notes = formData.get("notes") as string;

  if (!name || !name.trim()) {
    return { error: "O nome do cliente ou artista é obrigatório." };
  }

  try {
    const client = await prisma.client.create({
      data: {
        name: name.trim(),
        whatsapp: whatsapp ? whatsapp.trim() : null,
        whatsappLeadId: whatsappLeadId && whatsappLeadId !== "none" ? whatsappLeadId : null,
        driveFolderUrl: driveFolderUrl ? driveFolderUrl.trim() : null,
        notes: notes ? notes.trim() : null,
      },
    });

    revalidatePath("/clientes");
    revalidatePath("/projetos");
    return { success: true, client };
  } catch (error: any) {
    if (error.code === "P2002") {
      return { error: "Já existe um cliente cadastrado com este nome." };
    }
    return { error: error.message || "Erro ao cadastrar cliente." };
  }
}

export async function updateClientAction(data: {
  id: string;
  name: string;
  whatsapp?: string | null;
  whatsappLeadId?: string | null;
  driveFolderUrl?: string | null;
  notes?: string | null;
  active?: boolean;
}) {
  await requireAuth();

  if (!data.name || !data.name.trim()) {
    return { error: "O nome do cliente é obrigatório." };
  }

  try {
    const updated = await prisma.client.update({
      where: { id: data.id },
      data: {
        name: data.name.trim(),
        whatsapp: data.whatsapp !== undefined ? (data.whatsapp ? data.whatsapp.trim() : null) : undefined,
        whatsappLeadId: data.whatsappLeadId !== undefined ? (data.whatsappLeadId === "none" ? null : data.whatsappLeadId) : undefined,
        driveFolderUrl: data.driveFolderUrl !== undefined ? (data.driveFolderUrl ? data.driveFolderUrl.trim() : null) : undefined,
        notes: data.notes !== undefined ? (data.notes ? data.notes.trim() : null) : undefined,
        active: data.active !== undefined ? data.active : undefined,
      },
    });

    revalidatePath("/clientes");
    revalidatePath("/projetos");
    return { success: true, client: updated };
  } catch (error: any) {
    return { error: error.message || "Erro ao atualizar cliente." };
  }
}

export async function deleteClientAction(clientId: string) {
  await requireAdmin();

  try {
    // Soft delete desativando o cliente
    await prisma.client.update({
      where: { id: clientId },
      data: { active: false },
    });

    revalidatePath("/clientes");
    revalidatePath("/projetos");
    return { success: true };
  } catch (error: any) {
    return { error: error.message || "Erro ao desativar cliente." };
  }
}
