"use server";

import prisma from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { revalidatePath } from "next/cache";

export async function updateProcessStepAction(data: {
  stepId: string;
  title: string;
  deadlineDays: number | null;
  anchorOffsetDays?: number | null;
  deliverable: string;
  isClientStep: boolean;
  defaultRoleId?: string;
}) {
  await requireAdmin();

  try {
    const updated = await prisma.processStep.update({
      where: { id: data.stepId },
      data: {
        title: data.title.trim(),
        deadlineDays: data.deadlineDays,
        anchorOffsetDays: data.anchorOffsetDays !== undefined ? data.anchorOffsetDays : null,
        deliverable: data.deliverable.trim(),
        isClientStep: data.isClientStep,
        defaultRoleId: data.defaultRoleId || undefined,
      },
    });

    revalidatePath("/processos");
    return { success: true, step: updated };
  } catch (error: any) {
    return { error: error.message || "Erro ao atualizar passo do processo." };
  }
}

export async function updateProcessTemplateDetailsAction(data: {
  templateId: string;
  checklist?: string;
  attentionPoints?: string;
}) {
  await requireAdmin();

  try {
    const updated = await prisma.processTemplate.update({
      where: { id: data.templateId },
      data: {
        checklist: data.checklist ? data.checklist.trim() : null,
        attentionPoints: data.attentionPoints ? data.attentionPoints.trim() : null,
      },
    });

    revalidatePath("/processos");
    return { success: true, template: updated };
  } catch (error: any) {
    return { error: error.message || "Erro ao atualizar modelo de processo." };
  }
}
