"use server";

import prisma from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { supabaseAdmin } from "@/lib/supabase/admin";
import { revalidatePath } from "next/cache";

export async function inviteMember(data: {
  email: string;
  name: string;
  systemRole: "ADMIN" | "MEMBER";
  operationalRoleIds: string[];
}) {
  const admin = await requireAdmin();

  if (!data.email || !data.name) {
    return { error: "Nome e e-mail são obrigatórios." };
  }

  try {
    // 1. Cadastra ou atualiza o membro no banco
    const member = await prisma.member.upsert({
      where: { email: data.email.toLowerCase().trim() },
      update: {
        name: data.name,
        systemRole: data.systemRole,
        active: true,
      },
      create: {
        email: data.email.toLowerCase().trim(),
        name: data.name,
        systemRole: data.systemRole,
        active: true,
      },
    });

    // 2. Vincula os papéis operacionais selecionados
    if (data.operationalRoleIds.length > 0) {
      for (const roleId of data.operationalRoleIds) {
        await prisma.memberRole.upsert({
          where: {
            memberId_operationalRoleId: {
              memberId: member.id,
              operationalRoleId: roleId,
            },
          },
          update: {},
          create: {
            memberId: member.id,
            operationalRoleId: roleId,
          },
        });
      }
    }

    // 3. Tenta disparar o convite pelo Supabase Auth (se chaves configuradas)
    try {
      if (process.env.SUPABASE_SERVICE_ROLE_KEY && process.env.NEXT_PUBLIC_SUPABASE_URL) {
        await supabaseAdmin.auth.admin.inviteUserByEmail(data.email.toLowerCase().trim(), {
          data: {
            name: data.name,
            systemRole: data.systemRole,
          },
        });
      }
    } catch (inviteErr) {
      console.warn("Convite Supabase Auth não enviado diretamente (em modo dev):", inviteErr);
    }

    revalidatePath("/equipe");
    return { success: true, memberId: member.id };
  } catch (error: any) {
    console.error("Erro ao convidar membro:", error);
    return { error: error.message || "Erro ao convidar membro." };
  }
}

/**
 * Retorna uma prévia das tarefas abertas que serão transferidas antes de confirmar
 */
export async function previewRoleTransfer(data: {
  operationalRoleId: string;
  fromMemberId?: string | null;
}) {
  await requireAdmin();

  const whereClause: any = {
    status: { not: "DONE" },
    OR: [
      { roleId: data.operationalRoleId },
      { step: { defaultRoleId: data.operationalRoleId } },
    ],
  };

  if (data.fromMemberId) {
    whereClause.assigneeId = data.fromMemberId;
  }

  const tasks = await prisma.task.findMany({
    where: whereClause,
    include: {
      project: {
        include: {
          client: true,
          service: true,
        },
      },
      assignee: true,
      role: true,
    },
    orderBy: { dueDate: "asc" },
  });

  return {
    tasks: tasks.map((t) => ({
      id: t.id,
      title: t.title,
      clientName: t.project.client.name,
      serviceName: t.project.service.name,
      status: t.status,
      dueDate: t.dueDate,
      priority: t.priority,
      currentAssignee: t.assignee?.name || "Sem responsável",
    })),
  };
}

/**
 * Executa a transferência de tarefas em massa com registro de auditoria
 */
export async function executeRoleTransfer(data: {
  operationalRoleId: string;
  fromMemberId?: string | null;
  toMemberId: string;
  taskIds: string[];
  notes?: string;
}) {
  const currentAdmin = await requireAdmin();

  if (!data.toMemberId) {
    return { error: "Selecione o novo responsável." };
  }

  if (!data.taskIds || data.taskIds.length === 0) {
    return { error: "Nenhuma tarefa selecionada para transferência." };
  }

  try {
    // 1. Atualiza o responsável de todas as tarefas selecionadas
    await prisma.task.updateMany({
      where: {
        id: { in: data.taskIds },
      },
      data: {
        assigneeId: data.toMemberId,
        roleId: data.operationalRoleId,
      },
    });

    // 2. Garante que o novo membro possui o papel operacional atribuído
    await prisma.memberRole.upsert({
      where: {
        memberId_operationalRoleId: {
          memberId: data.toMemberId,
          operationalRoleId: data.operationalRoleId,
        },
      },
      update: {},
      create: {
        memberId: data.toMemberId,
        operationalRoleId: data.operationalRoleId,
        isPrimary: true,
      },
    });

    // 3. Registra auditoria da transferência
    const log = await prisma.roleTransferLog.create({
      data: {
        performedById: currentAdmin.id,
        fromMemberId: data.fromMemberId || null,
        toMemberId: data.toMemberId,
        operationalRoleId: data.operationalRoleId,
        affectedTaskCount: data.taskIds.length,
        notes: data.notes || "Transferência de papel em lote.",
      },
      include: {
        performedBy: true,
        fromMember: true,
        toMember: true,
        operationalRole: true,
      },
    });

    revalidatePath("/equipe");
    revalidatePath("/");
    revalidatePath("/tarefas");
    return { success: true, logId: log.id, count: data.taskIds.length };
  } catch (error: any) {
    console.error("Erro ao transferir tarefas:", error);
    return { error: error.message || "Falha ao transferir tarefas." };
  }
}

/**
 * Lista o histórico recente de transferências para auditoria
 */
export async function getTransferAuditLogs() {
  await requireAdmin();

  const logs = await prisma.roleTransferLog.findMany({
    take: 20,
    orderBy: { createdAt: "desc" },
    include: {
      performedBy: { select: { id: true, name: true, email: true } },
      fromMember: { select: { id: true, name: true } },
      toMember: { select: { id: true, name: true } },
      operationalRole: { select: { id: true, name: true } },
    },
  });

  return logs;
}
