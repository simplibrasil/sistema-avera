"use client";

import { useState } from "react";
import { loginWithEmail } from "@/app/actions/auth-actions";
import { useRouter } from "next/navigation";
import { ArrowRight, Lock, Mail, Users, Sparkles } from "lucide-react";
import Image from "next/image";

const IS_DEVELOPMENT = process.env.NODE_ENV === "development";

export default function LoginPage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setErrorMsg("");
    const formData = new FormData(e.currentTarget);
    const res = await loginWithEmail(formData);
    if (res?.error) {
      setErrorMsg(res.error);
      setLoading(false);
    } else {
      router.push("/");
      router.refresh();
    }
  };

  const handleDevLogin = async (email: string) => {
    if (!IS_DEVELOPMENT) return;
    setLoading(true);
    const formData = new FormData();
    formData.append("email", email);
    formData.append("password", "avera123");
    const res = await loginWithEmail(formData);
    if (res?.error) {
      setErrorMsg(res.error);
      setLoading(false);
    } else {
      router.push("/");
      router.refresh();
    }
  };

  return (
    <div className="min-h-screen flex flex-col justify-center items-center px-4 bg-[#0d0e14]">
      {/* Card de Login */}
      <div className="w-full max-w-md space-y-8 bg-[#161822] p-8 rounded-2xl border border-[#232738] shadow-2xl">

        {/* Logo + Nome do Sistema */}
        <div className="text-center space-y-3">
          <div className="mx-auto w-16 h-16 rounded-2xl bg-white flex items-center justify-center shadow-xl shadow-black/40">
            <Image
              src="/avera-logo.png"
              alt="Avera Logo"
              width={44}
              height={44}
              className="object-contain"
            />
          </div>
          <div>
            <h1 className="text-2xl font-black tracking-tight text-white">
              Workflow
            </h1>
            <h2 className="text-2xl font-black tracking-tight text-red-500 -mt-1">
              Avera Company
            </h2>
          </div>
          <p className="text-sm text-slate-400">
            Entre com sua conta para acessar o sistema interno
          </p>
        </div>

        {/* Mensagem de Erro */}
        {errorMsg && (
          <div className="p-3 text-sm rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center gap-2">
            <span>⚠</span> {errorMsg}
          </div>
        )}

        {/* Formulário */}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              E-mail
            </label>
            <div className="relative">
              <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="email"
                name="email"
                required
                placeholder="seu.email@averacompany.com"
                className="w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border border-[#2a2f42] bg-[#181a24] text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Senha
            </label>
            <div className="relative">
              <Lock className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="password"
                name="password"
                required
                placeholder="••••••••"
                className="w-full pl-10 pr-4 py-2.5 text-sm rounded-xl border border-[#2a2f42] bg-[#181a24] text-white placeholder-slate-500 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full py-3 px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-semibold text-sm transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-600/30 disabled:opacity-50"
          >
            {loading ? "Entrando..." : "Entrar no Sistema"}
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        {/* Atalhos de desenvolvimento: SOMENTE em NODE_ENV=development */}
        {IS_DEVELOPMENT && (
          <div className="pt-5 border-t border-[#232738]">
            <p className="text-xs font-semibold text-amber-400 uppercase tracking-wider text-center mb-3 flex items-center justify-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Ambiente de Desenvolvimento
            </p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => handleDevLogin("anelise@averacompany.com")}
                className="px-3 py-2 text-xs font-semibold rounded-xl border border-[#2a2f42] bg-[#181a24] hover:bg-[#1e2233] transition text-slate-200 flex items-center justify-center gap-1.5"
              >
                <Users className="w-3.5 h-3.5 text-pink-400" />
                Anelise (Admin)
              </button>
              <button
                onClick={() => handleDevLogin("matheus@averacompany.com")}
                className="px-3 py-2 text-xs font-semibold rounded-xl border border-[#2a2f42] bg-[#181a24] hover:bg-[#1e2233] transition text-slate-200 flex items-center justify-center gap-1.5"
              >
                <Users className="w-3.5 h-3.5 text-blue-400" />
                Matheus (Admin)
              </button>
            </div>
          </div>
        )}

        {/* Rodapé */}
        <p className="text-center text-[11px] text-slate-600 pt-2">
          Workflow Avera Company · Sistema Interno · {new Date().getFullYear()}
        </p>
      </div>
    </div>
  );
}
