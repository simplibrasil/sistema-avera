import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import * as XLSX from "xlsx";
import { formatDateBR } from "@/lib/date-utils";

export async function GET(req: NextRequest) {
  const user = await getCurrentUser();
  if (!user || user.systemRole !== "ADMIN") {
    return new NextResponse("Acesso não autorizado.", { status: 403 });
  }

  try {
    // 1. Busca Clientes
    const clients = await prisma.client.findMany({
      include: {
        whatsappLead: { select: { name: true } },
      },
      orderBy: { name: "asc" },
    });

    const clientsData = clients.map((c) => ({
      Nome: c.name,
      WhatsApp: c.whatsapp || "-",
      "Dono no WhatsApp": c.whatsappLead?.name || "Não atribuído",
      Observações: c.notes || "-",
      "Criado em": formatDateBR(c.createdAt),
    }));

    // 2. Busca Projetos
    const projects = await prisma.project.findMany({
      include: {
        client: { select: { name: true } },
        service: { select: { name: true } },
        financial: { select: { value: true } },
      },
      orderBy: { createdAt: "desc" },
    });

    const projectsData = projects.map((p) => ({
      Cliente: p.client.name,
      Serviço: p.service.name,
      Status: p.status,
      Recorrência: p.recurrence,
      "Ciclo Atual": p.currentCycle,
      "Data de Início": formatDateBR(p.startDate),
      "Data da Gravação": p.recordingDate ? formatDateBR(p.recordingDate) : "-",
      "Data do Lançamento": p.releaseDate ? formatDateBR(p.releaseDate) : "-",
      "Valor (R$)": p.financial ? Number(p.financial.value) : 0,
    }));

    // 3. Busca Tarefas
    const tasks = await prisma.task.findMany({
      include: {
        project: {
          include: {
            client: { select: { name: true } },
            service: { select: { name: true } },
          },
        },
        assignee: { select: { name: true } },
      },
      orderBy: [{ dueDate: "asc" }, { order: "asc" }],
    });

    const tasksData = tasks.map((t) => ({
      Ordem: t.order,
      Título: t.title,
      Cliente: t.project.client.name,
      Serviço: t.project.service.name,
      Responsável: t.assignee?.name || (t.isThirdParty ? "Terceirizado" : "Sem responsável"),
      Prazo: t.dueDate ? formatDateBR(t.dueDate) : "Sem prazo fixo",
      Status: t.status,
      "Entregável Esperado": t.deliverable || "-",
      "Com Cliente": t.isClientStep ? "Sim" : "Não",
      "Ciclo Mensal": t.cycleNumber || "-",
    }));

    // Criação da Pasta de Trabalho Excel
    const wb = XLSX.utils.book_new();

    const wsClients = XLSX.utils.json_to_sheet(clientsData);
    const wsProjects = XLSX.utils.json_to_sheet(projectsData);
    const wsTasks = XLSX.utils.json_to_sheet(tasksData);

    XLSX.utils.book_append_sheet(wb, wsClients, "Clientes");
    XLSX.utils.book_append_sheet(wb, wsProjects, "Projetos");
    XLSX.utils.book_append_sheet(wb, wsTasks, "Tarefas");

    const buf = XLSX.write(wb, { type: "buffer", bookType: "xlsx" });

    const nowStr = new Date().toISOString().split("T")[0];
    const filename = `backup_avera_company_${nowStr}.xlsx`;

    return new NextResponse(buf, {
      status: 200,
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${filename}"`,
      },
    });
  } catch (error: any) {
    console.error("Erro ao exportar dados:", error);
    return new NextResponse("Falha ao gerar planilha de backup.", { status: 500 });
  }
}
