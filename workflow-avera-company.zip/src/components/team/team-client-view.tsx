"use client";

import { useState } from "react";
import { UserPlus, ArrowRightLeft, Shield, UserCheck, Briefcase, Users, Mail } from "lucide-react";
import { InviteMemberModal } from "./invite-modal";
import { MassTransferModal } from "./mass-transfer-modal";
import { TransferHistoryTable } from "./transfer-history-table";

type Member = {
  id: string;
  name: string;
  email: string;
  systemRole: "ADMIN" | "MEMBER";
  active: boolean;
  memberRoles: {
    operationalRole: {
      id: string;
      name: string;
      slug: string;
    };
  }[];
  _count?: {
    assignedTasks: number;
  };
};

type Role = {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  memberRoles: {
    member: {
      id: string;
      name: string;
    };
  }[];
};

type TeamClientViewProps = {
  members: Member[];
  operationalRoles: Role[];
  auditLogs: any[];
  isAdmin: boolean;
};

export function TeamClientView({
  members,
  operationalRoles,
  auditLogs,
  isAdmin,
}: TeamClientViewProps) {
  const [inviteModalOpen, setInviteModalOpen] = useState(false);
  const [massTransferModalOpen, setMassTransferModalOpen] = useState(false);
  const [selectedTransferRoleId, setSelectedTransferRoleId] = useState<string | undefined>();

  const handleOpenTransferForRole = (roleId: string) => {
    setSelectedTransferRoleId(roleId);
    setMassTransferModalOpen(true);
  };

  return (
    <div className="space-y-8">
      {/* Header com ações principais */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-[#232738]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md">
              <Users className="w-4 h-4" />
            </div>
            Equipe e Papéis Operacionais
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Gerencie os membros da Avera, seus papéis de execução e transfira tarefas abertas em massa.
          </p>
        </div>

        {isAdmin && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setSelectedTransferRoleId(operationalRoles[0]?.id);
                setMassTransferModalOpen(true);
              }}
              className="px-3.5 py-2 text-xs font-semibold rounded-xl border border-[#232738] bg-[#111218] hover:bg-[#191c2a] hover:border-[#38415d] text-slate-200 transition flex items-center gap-1.5 shadow-sm"
            >
              <ArrowRightLeft className="w-3.5 h-3.5 text-indigo-400" />
              Troca em Massa
            </button>
            <button
              onClick={() => setInviteModalOpen(true)}
              className="px-3.5 py-2 text-xs font-semibold rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white transition flex items-center gap-1.5 shadow-md shadow-indigo-950/40"
            >
              <UserPlus className="w-3.5 h-3.5" />
              Convidar Membro
            </button>
          </div>
        )}
      </div>

      {/* 1. Grade de Membros Atuais */}
      <div>
        <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider mb-4 flex items-center gap-2">
          <span>Membros da Empresa</span>
          <span className="text-xs px-2 py-0.5 rounded-full bg-[#151722] border border-[#232738] text-slate-400 font-semibold">
            {members.length}
          </span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {members.map((member) => (
            <div
              key={member.id}
              className="p-5 rounded-2xl bg-[#151722] border border-[#232738] hover:border-[#38415d] hover:bg-[#191c2a] shadow-sm hover:shadow-md transition flex flex-col justify-between group"
            >
              <div>
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-600 text-white font-bold text-base flex items-center justify-center shadow-md">
                      {member.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-white group-hover:text-indigo-300 transition-colors">
                        {member.name}
                      </h3>
                      <p className="text-xs text-slate-400 flex items-center gap-1">
                        <Mail className="w-3 h-3 text-slate-500" />
                        {member.email}
                      </p>
                    </div>
                  </div>

                  <span
                    className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold flex items-center gap-1 ${
                      member.systemRole === "ADMIN"
                        ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                        : "bg-[#111218] text-slate-400 border border-[#232738]"
                    }`}
                  >
                    {member.systemRole === "ADMIN" ? (
                      <Shield className="w-3 h-3 text-emerald-400" />
                    ) : (
                      <UserCheck className="w-3 h-3 text-slate-400" />
                    )}
                    {member.systemRole === "ADMIN" ? "Admin" : "Membro"}
                  </span>
                </div>

                {/* Papéis exercidos */}
                <div className="mt-4">
                  <p className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider mb-2">
                    Papéis Atribuídos ({member.memberRoles.length})
                  </p>
                  <div className="flex flex-wrap gap-1.5">
                    {member.memberRoles.length === 0 ? (
                      <span className="text-xs text-slate-500 italic">Sem papéis vinculados</span>
                    ) : (
                      member.memberRoles.map((mr) => (
                        <span
                          key={mr.operationalRole.id}
                          className="px-2 py-0.5 rounded-md text-[11px] font-medium bg-[#111218] text-slate-300 border border-[#232738]"
                        >
                          {mr.operationalRole.name}
                        </span>
                      ))
                    )}
                  </div>
                </div>
              </div>

              {/* Rodapé do card */}
              <div className="mt-5 pt-3 border-t border-[#1f2333] flex items-center justify-between text-[11px] text-slate-400">
                <span>Status: <strong className="text-emerald-400 font-semibold">Ativo</strong></span>
                {member._count && (
                  <span>
                    <strong className="text-white">{member._count.assignedTasks}</strong> tarefas ativas
                  </span>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Catálogo de Papéis Operacionais e Quem Exerce */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-sm font-bold text-slate-200 uppercase tracking-wider flex items-center gap-2">
            <Briefcase className="w-4 h-4 text-indigo-400" />
            <span>Papéis Operacionais do Catálogo</span>
          </h2>
          <span className="text-xs text-slate-400 hidden sm:inline">
            Cada passo dos processos usa um papel padrão para delegar tarefas.
          </span>
        </div>

        <div className="bg-[#151722] border border-[#232738] rounded-2xl overflow-hidden shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#111218] border-b border-[#232738] text-slate-400 font-semibold">
                <tr>
                  <th className="py-3.5 px-4">Papel Operacional</th>
                  <th className="py-3.5 px-4">Quem Exerce Hoje</th>
                  {isAdmin && <th className="py-3.5 px-4 text-right">Ação Rápida</th>}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#1f2333] text-slate-300">
                {operationalRoles.map((role) => {
                  const assignees = role.memberRoles.map((mr) => mr.member.name);
                  return (
                    <tr key={role.id} className="hover:bg-[#191c2a] transition">
                      <td className="py-3 px-4 font-semibold text-white">
                        {role.name}
                      </td>
                      <td className="py-3 px-4">
                        {assignees.length > 0 ? (
                          <div className="flex flex-wrap gap-1.5">
                            {assignees.map((name, i) => (
                              <span
                                key={i}
                                className="px-2 py-0.5 rounded-full text-[11px] font-medium bg-[#1c2235] text-indigo-300 border border-indigo-500/20"
                              >
                                {name}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <span className="text-slate-500 italic">Fornecedor Terceiro / Não atribuído</span>
                        )}
                      </td>
                      {isAdmin && (
                        <td className="py-3 px-4 text-right">
                          <button
                            onClick={() => handleOpenTransferForRole(role.id)}
                            className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 hover:underline inline-flex items-center gap-1"
                          >
                            <ArrowRightLeft className="w-3 h-3" />
                            Transferir tarefas
                          </button>
                        </td>
                      )}
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* 3. Tabela de Auditoria de Transferências */}
      {isAdmin && <TransferHistoryTable logs={auditLogs} />}

      {/* Modais */}
      <InviteMemberModal
        isOpen={inviteModalOpen}
        onClose={() => setInviteModalOpen(false)}
        operationalRoles={operationalRoles}
      />

      <MassTransferModal
        isOpen={massTransferModalOpen}
        onClose={() => setMassTransferModalOpen(false)}
        members={members}
        operationalRoles={operationalRoles}
        initialRoleId={selectedTransferRoleId}
      />
    </div>
  );
}
