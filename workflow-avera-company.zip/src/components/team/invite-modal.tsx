"use client";

import { useState } from "react";
import { inviteMember } from "@/app/actions/team-actions";
import { UserPlus, X, Mail, User, Shield, Check } from "lucide-react";
import { useRouter } from "next/navigation";

type InviteModalProps = {
  isOpen: boolean;
  onClose: () => void;
  operationalRoles: { id: string; name: string }[];
};

export function InviteMemberModal({ isOpen, onClose, operationalRoles }: InviteModalProps) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [systemRole, setSystemRole] = useState<"ADMIN" | "MEMBER">("MEMBER");
  const [selectedRoleIds, setSelectedRoleIds] = useState<string[]>([]);

  if (!isOpen) return null;

  const toggleRole = (roleId: string) => {
    setSelectedRoleIds((prev) =>
      prev.includes(roleId) ? prev.filter((id) => id !== roleId) : [...prev, roleId]
    );
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const res = await inviteMember({
      name,
      email,
      systemRole,
      operationalRoleIds: selectedRoleIds,
    });

    if (res?.error) {
      setError(res.error);
      setLoading(false);
    } else {
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
        router.refresh();
      }, 1000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-lg bg-[#151722] rounded-2xl border border-[#232738] shadow-2xl p-6 relative">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-600 text-white flex items-center justify-center shadow-md">
            <UserPlus className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Convidar Novo Membro</h2>
            <p className="text-xs text-slate-400">
              Cadastre o e-mail, perfil e os papéis operacionais do novo colaborador.
            </p>
          </div>
        </div>

        {error && (
          <div className="p-3 mb-4 text-xs rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400">
            {error}
          </div>
        )}

        {success ? (
          <div className="p-6 text-center text-emerald-400 font-semibold flex flex-col items-center gap-2">
            <Check className="w-8 h-8 rounded-full bg-emerald-500/20 border border-emerald-500/30 p-1.5 text-emerald-400" />
            Convite enviado com sucesso!
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
                Nome Completo
              </label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="text"
                  required
                  placeholder="Ex: Clara Ribeiro"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full pl-10 pr-3 py-2 text-sm rounded-xl border border-[#232738] bg-[#111218] text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
                E-mail de Acesso
              </label>
              <div className="relative">
                <Mail className="w-4 h-4 text-slate-500 absolute left-3.5 top-3" />
                <input
                  type="email"
                  required
                  placeholder="colaborador@averacompany.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-3 py-2 text-sm rounded-xl border border-[#232738] bg-[#111218] text-white focus:outline-none focus:border-indigo-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
                Permissão no Sistema
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setSystemRole("MEMBER")}
                  className={`p-3 rounded-xl border text-left transition ${
                    systemRole === "MEMBER"
                      ? "border-indigo-500 bg-[#1c2235] text-white"
                      : "border-[#232738] bg-[#111218] text-slate-400 hover:border-[#38415d]"
                  }`}
                >
                  <p className="text-xs font-bold text-white">Membro da Equipe</p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Vê e edita só as próprias tarefas. Não vê valores financeiros.
                  </p>
                </button>
                <button
                  type="button"
                  onClick={() => setSystemRole("ADMIN")}
                  className={`p-3 rounded-xl border text-left transition ${
                    systemRole === "ADMIN"
                      ? "border-emerald-500 bg-[#12241c] text-white"
                      : "border-[#232738] bg-[#111218] text-slate-400 hover:border-[#38415d]"
                  }`}
                >
                  <p className="text-xs font-bold flex items-center gap-1 text-white">
                    <Shield className="w-3 h-3 text-emerald-400" />
                    Administrador
                  </p>
                  <p className="text-[11px] text-slate-400 mt-0.5">
                    Acesso completo a valores, finanças e edição de modelos de processo.
                  </p>
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Papéis Operacionais Iniciais
              </label>
              <div className="grid grid-cols-2 gap-2 max-h-44 overflow-y-auto pr-1">
                {operationalRoles.map((role) => {
                  const isChecked = selectedRoleIds.includes(role.id);
                  return (
                    <button
                      type="button"
                      key={role.id}
                      onClick={() => toggleRole(role.id)}
                      className={`px-2.5 py-1.5 rounded-xl text-xs font-medium border text-left flex items-center justify-between transition ${
                        isChecked
                          ? "border-indigo-500 bg-[#1c2235] text-indigo-300 font-semibold"
                          : "border-[#232738] bg-[#111218] text-slate-400 hover:text-white hover:border-[#38415d]"
                      }`}
                    >
                      <span className="truncate">{role.name}</span>
                      {isChecked && <Check className="w-3.5 h-3.5 text-indigo-400 shrink-0" />}
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="pt-4 border-t border-[#232738] flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium rounded-xl text-slate-400 hover:text-white transition"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 text-xs font-semibold rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white transition disabled:opacity-50 shadow-md shadow-indigo-950/40"
              >
                {loading ? "Enviando..." : "Cadastrar e Enviar Convite"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
