import { formatDateBR } from "@/lib/date-utils";
import { ArrowRight, History, Shield, User } from "lucide-react";

type TransferLog = {
  id: string;
  affectedTaskCount: number;
  notes: string | null;
  createdAt: Date;
  performedBy: { id: string; name: string; email: string };
  fromMember: { id: string; name: string } | null;
  toMember: { id: string; name: string };
  operationalRole: { id: string; name: string };
};

export function TransferHistoryTable({ logs }: { logs: TransferLog[] }) {
  if (logs.length === 0) {
    return (
      <div className="p-8 text-center rounded-2xl border border-dashed border-[#232738] bg-[#151722]/50 text-slate-500 text-xs">
        <History className="w-8 h-8 mx-auto mb-2 opacity-40 text-slate-400" />
        Nenhuma transferência em massa registrada até o momento.
      </div>
    );
  }

  return (
    <div className="border border-[#232738] rounded-2xl overflow-hidden bg-[#151722] shadow-sm">
      <div className="px-5 py-3.5 border-b border-[#232738] bg-[#111218] flex items-center justify-between">
        <div className="flex items-center gap-2">
          <History className="w-4 h-4 text-indigo-400" />
          <h3 className="text-xs font-bold text-white uppercase tracking-wider">
            Auditoria: Histórico de Transferências em Massa
          </h3>
        </div>
        <span className="text-[11px] text-slate-400">{logs.length} registros</span>
      </div>

      <div className="divide-y divide-[#1f2333] text-xs">
        {logs.map((log) => (
          <div key={log.id} className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-2 hover:bg-[#191c2a] transition">
            <div>
              <div className="flex items-center gap-2 mb-1">
                <span className="font-semibold text-white">
                  {log.operationalRole.name}
                </span>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-[#1c2235] text-indigo-300 border border-indigo-500/30">
                  {log.affectedTaskCount} {log.affectedTaskCount === 1 ? "tarefa" : "tarefas"}
                </span>
              </div>
              <div className="flex items-center gap-1.5 text-[11px] text-slate-400">
                <span className="font-medium text-slate-300">
                  {log.fromMember ? log.fromMember.name : "Qualquer responsável"}
                </span>
                <ArrowRight className="w-3 h-3 text-slate-500" />
                <span className="font-semibold text-teal-400">
                  {log.toMember.name}
                </span>
                {log.notes && <span className="text-slate-500 italic">({log.notes})</span>}
              </div>
            </div>

            <div className="text-right sm:self-center text-[11px] text-slate-400 shrink-0">
              <p className="font-medium text-slate-300">
                Por: {log.performedBy.name}
              </p>
              <p className="text-slate-500">{formatDateBR(log.createdAt)}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
