"use client";

import { useState } from "react";
import { previewRoleTransfer, executeRoleTransfer } from "@/app/actions/team-actions";
import { ArrowRightLeft, X, AlertCircle, CheckCircle2, Calendar, User, Check } from "lucide-react";
import { formatDateBR } from "@/lib/date-utils";
import { useRouter } from "next/navigation";

type Member = { id: string; name: string };
type Role = { id: string; name: string; slug: string };

type MassTransferModalProps = {
  isOpen: boolean;
  onClose: () => void;
  members: Member[];
  operationalRoles: Role[];
  initialRoleId?: string;
};

export function MassTransferModal({
  isOpen,
  onClose,
  members,
  operationalRoles,
  initialRoleId,
}: MassTransferModalProps) {
  const router = useRouter();
  const [selectedRoleId, setSelectedRoleId] = useState<string>(initialRoleId || operationalRoles[0]?.id || "");
  const [fromMemberId, setFromMemberId] = useState<string>("");
  const [toMemberId, setToMemberId] = useState<string>("");
  const [notes, setNotes] = useState<string>("");

  const [loadingPreview, setLoadingPreview] = useState(false);
  const [previewTasks, setPreviewTasks] = useState<any[] | null>(null);
  const [selectedTaskIds, setSelectedTaskIds] = useState<string[]>([]);

  const [executing, setExecuting] = useState(false);
  const [error, setError] = useState<string>("");
  const [successCount, setSuccessCount] = useState<number | null>(null);

  if (!isOpen) return null;

  const handleFetchPreview = async () => {
    if (!selectedRoleId) return;
    setLoadingPreview(true);
    setError("");
    setPreviewTasks(null);

    const res = await previewRoleTransfer({
      operationalRoleId: selectedRoleId,
      fromMemberId: fromMemberId ? fromMemberId : null,
    });

    setPreviewTasks(res.tasks);
    setSelectedTaskIds(res.tasks.map((t) => t.id));
    setLoadingPreview(false);
  };

  const handleToggleTask = (taskId: string) => {
    setSelectedTaskIds((prev) =>
      prev.includes(taskId) ? prev.filter((id) => id !== taskId) : [...prev, taskId]
    );
  };

  const handleToggleAll = () => {
    if (!previewTasks) return;
    if (selectedTaskIds.length === previewTasks.length) {
      setSelectedTaskIds([]);
    } else {
      setSelectedTaskIds(previewTasks.map((t) => t.id));
    }
  };

  const handleConfirmTransfer = async () => {
    if (!toMemberId) {
      setError("Selecione o novo colaborador que assumirá o papel.");
      return;
    }
    if (selectedTaskIds.length === 0) {
      setError("Nenhuma tarefa selecionada para transferência.");
      return;
    }

    setExecuting(true);
    setError("");

    const res = await executeRoleTransfer({
      operationalRoleId: selectedRoleId,
      fromMemberId: fromMemberId || null,
      toMemberId,
      taskIds: selectedTaskIds,
      notes: notes || undefined,
    });

    if (res?.error) {
      setError(res.error);
      setExecuting(false);
    } else {
      setSuccessCount(res.count || 0);
      setTimeout(() => {
        setSuccessCount(null);
        setPreviewTasks(null);
        onClose();
        router.refresh();
      }, 1500);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="w-full max-w-2xl bg-[#151722] rounded-2xl border border-[#232738] shadow-2xl p-6 relative max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-4">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-600 text-white flex items-center justify-center shadow-md">
            <ArrowRightLeft className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">
              Troca de Responsável em Massa
            </h2>
            <p className="text-xs text-slate-400">
              Transfira todas as tarefas abertas de uma função para outra pessoa de uma vez só.
            </p>
          </div>
        </div>

        {error && (
          <div className="p-3 mb-3 text-xs rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        {successCount !== null ? (
          <div className="py-12 text-center flex flex-col items-center gap-3">
            <CheckCircle2 className="w-12 h-12 text-emerald-400" />
            <h3 className="text-lg font-bold text-white">
              {successCount} tarefas transferidas com sucesso!
            </h3>
            <p className="text-xs text-slate-400">
              O novo responsável foi vinculado e o registro de auditoria foi salvo.
            </p>
          </div>
        ) : (
          <div className="flex-1 overflow-y-auto space-y-4 pr-1">
            {/* 1. Seleção de Papel e Membros */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 rounded-xl bg-[#111218] border border-[#232738]">
              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  1. Papel a transferir
                </label>
                <select
                  value={selectedRoleId}
                  onChange={(e) => {
                    setSelectedRoleId(e.target.value);
                    setPreviewTasks(null);
                  }}
                  className="w-full text-xs rounded-xl border border-[#232738] bg-[#151722] p-2.5 text-white focus:outline-none focus:border-indigo-500 font-medium"
                >
                  {operationalRoles.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  2. Responsável atual
                </label>
                <select
                  value={fromMemberId}
                  onChange={(e) => {
                    setFromMemberId(e.target.value);
                    setPreviewTasks(null);
                  }}
                  className="w-full text-xs rounded-xl border border-[#232738] bg-[#151722] p-2.5 text-white focus:outline-none focus:border-indigo-500 font-medium"
                >
                  <option value="">Qualquer responsável (Todos)</option>
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold text-slate-400 mb-1">
                  3. Novo responsável
                </label>
                <select
                  value={toMemberId}
                  onChange={(e) => setToMemberId(e.target.value)}
                  className="w-full text-xs rounded-xl border border-[#232738] bg-[#151722] p-2.5 text-white focus:outline-none focus:border-indigo-500 font-semibold"
                >
                  <option value="">Selecione quem assume...</option>
                  {members.map((m) => (
                    <option key={m.id} value={m.id}>
                      {m.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {/* Botão de Ver Prévia */}
            <div className="flex items-center justify-between">
              <p className="text-xs font-bold text-slate-300">
                Prévia das Tarefas Afetadas
              </p>
              <button
                type="button"
                onClick={handleFetchPreview}
                disabled={loadingPreview}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[#1c2235] text-indigo-300 border border-indigo-500/30 hover:bg-[#252c42] transition"
              >
                {loadingPreview ? "Carregando tarefas..." : "Buscar Tarefas Abertas"}
              </button>
            </div>

            {/* Lista com Prévia das Tarefas */}
            {previewTasks !== null && (
              <div className="border border-[#232738] rounded-xl overflow-hidden bg-[#111218]">
                <div className="bg-[#151722] border-b border-[#232738] px-4 py-2 flex items-center justify-between text-xs font-medium text-slate-400">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={previewTasks.length > 0 && selectedTaskIds.length === previewTasks.length}
                      onChange={handleToggleAll}
                      className="rounded text-indigo-600 focus:ring-indigo-500 bg-[#111218] border-[#232738]"
                    />
                    <span>
                      {selectedTaskIds.length} de {previewTasks.length} tarefas selecionadas
                    </span>
                  </div>
                  <span>Prazo / Cliente</span>
                </div>

                <div className="max-h-56 overflow-y-auto divide-y divide-[#1f2333] bg-[#111218]">
                  {previewTasks.length === 0 ? (
                    <p className="p-4 text-xs text-center text-slate-500">
                      Nenhuma tarefa aberta encontrada para este papel e responsável.
                    </p>
                  ) : (
                    previewTasks.map((t) => {
                      const isSelected = selectedTaskIds.includes(t.id);
                      return (
                        <div
                          key={t.id}
                          onClick={() => handleToggleTask(t.id)}
                          className={`p-3 flex items-start justify-between text-xs cursor-pointer hover:bg-[#191c2a] transition ${
                            isSelected ? "bg-[#1c2235]/60" : ""
                          }`}
                        >
                          <div className="flex items-start gap-2.5 max-w-[70%]">
                            <input
                              type="checkbox"
                              checked={isSelected}
                              onChange={() => handleToggleTask(t.id)}
                              className="mt-0.5 rounded text-indigo-600 focus:ring-indigo-500 bg-[#111218] border-[#232738]"
                            />
                            <div>
                              <p className="font-semibold text-white line-clamp-1">
                                {t.title}
                              </p>
                              <p className="text-[11px] text-slate-400 mt-0.5">
                                <span className="font-medium text-slate-300">
                                  {t.clientName}
                                </span>{" "}
                                • {t.serviceName}
                              </p>
                            </div>
                          </div>
                          <div className="text-right">
                            <span className="inline-flex items-center gap-1 text-[11px] text-slate-400">
                              <Calendar className="w-3 h-3 text-slate-500" />
                              {formatDateBR(t.dueDate)}
                            </span>
                            <p className="text-[10px] text-slate-500 mt-0.5">
                              Atual: {t.currentAssignee}
                            </p>
                          </div>
                        </div>
                      );
                    })
                  )}
                </div>
              </div>
            )}

            {/* Motivo / Notas da auditoria */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 mb-1">
                Motivo / Observações para o histórico (opcional)
              </label>
              <input
                type="text"
                placeholder="Ex: Novo colaborador contratado para assumir edição de vídeos"
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                className="w-full text-xs rounded-xl border border-[#232738] bg-[#111218] p-2.5 text-white focus:outline-none focus:border-indigo-500"
              />
            </div>
          </div>
        )}

        <div className="pt-4 border-t border-[#232738] flex items-center justify-between mt-auto">
          <p className="text-[11px] text-slate-500">
            A transferência atualiza o responsável e salva log com data e autor.
          </p>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium rounded-xl text-slate-400 hover:text-white transition"
            >
              Cancelar
            </button>
            <button
              type="button"
              onClick={handleConfirmTransfer}
              disabled={executing || !toMemberId || selectedTaskIds.length === 0}
              className="px-4 py-2 text-xs font-semibold rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white transition disabled:opacity-50 flex items-center gap-1.5 shadow-md shadow-indigo-950/40"
            >
              <Check className="w-3.5 h-3.5" />
              {executing ? "Transferindo..." : `Confirmar Transferência (${selectedTaskIds.length})`}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
