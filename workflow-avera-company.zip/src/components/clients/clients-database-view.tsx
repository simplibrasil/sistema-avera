"use client";

import { useState } from "react";
import {
  Users,
  UserPlus,
  Phone,
  Folder,
  ExternalLink,
  Edit2,
  Search,
  CheckCircle2,
  Clock,
  Sparkles,
  MessageCircle,
  X,
  Check,
  Briefcase,
  AlertCircle,
  MoreVertical,
  Shield,
  Layers,
} from "lucide-react";
import { createClientAction, updateClientAction, deleteClientAction } from "@/app/actions/client-actions";
import { useRouter } from "next/navigation";
import Link from "next/link";

type ClientItem = {
  id: string;
  name: string;
  contactPerson?: string | null;
  whatsapp?: string | null;
  whatsappLeadId?: string | null;
  driveFolderUrl?: string | null;
  notes?: string | null;
  active: boolean;
  createdAt: Date | string;
  whatsappLead?: { id: string; name: string } | null;
  projects?: {
    id: string;
    name: string;
    status: string;
    service: { id: string; name: string; area: { name: string; color: string } };
  }[];
};

type Member = { id: string; name: string };

type ClientsDatabaseViewProps = {
  clients: ClientItem[];
  members: Member[];
  isAdmin: boolean;
};

export function ClientsDatabaseView({
  clients,
  members,
  isAdmin,
}: ClientsDatabaseViewProps) {
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [leadFilter, setLeadFilter] = useState<string>("ALL");
  const [statusFilter, setStatusFilter] = useState<"ACTIVE" | "INACTIVE" | "ALL">("ACTIVE");

  // Modal de Criação / Edição
  const [modalOpen, setModalOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<ClientItem | null>(null);

  // Campos do formulário
  const [formName, setFormName] = useState("");
  const [formWhatsapp, setFormWhatsapp] = useState("");
  const [formLeadId, setFormLeadId] = useState("");
  const [formDrive, setFormDrive] = useState("");
  const [formNotes, setFormNotes] = useState("");
  const [formActive, setFormActive] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [formError, setFormError] = useState("");

  const filteredClients = clients.filter((c) => {
    // Filtro de status
    if (statusFilter === "ACTIVE" && !c.active) return false;
    if (statusFilter === "INACTIVE" && c.active) return false;

    // Filtro de Responsável no WhatsApp
    if (leadFilter !== "ALL") {
      const leadName = c.whatsappLead?.name || "";
      if (!leadName.toLowerCase().includes(leadFilter.toLowerCase())) {
        return false;
      }
    }

    // Busca textual
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchName = c.name.toLowerCase().includes(q);
      const matchPhone = (c.whatsapp || "").toLowerCase().includes(q);
      const matchNotes = (c.notes || "").toLowerCase().includes(q);
      return matchName || matchPhone || matchNotes;
    }

    return true;
  });

  // Métricas
  const totalClients = clients.length;
  const aneliseClients = clients.filter((c) =>
    (c.whatsappLead?.name || "").toLowerCase().includes("anelise")
  ).length;
  const matheusClients = clients.filter((c) =>
    (c.whatsappLead?.name || "").toLowerCase().includes("matheus")
  ).length;
  const activeClients = clients.filter((c) => c.active).length;

  const handleOpenCreate = () => {
    setEditingClient(null);
    setFormName("");
    setFormWhatsapp("");
    setFormLeadId(members[0]?.id || "none");
    setFormDrive("");
    setFormNotes("");
    setFormActive(true);
    setFormError("");
    setModalOpen(true);
  };

  const handleOpenEdit = (c: ClientItem) => {
    setEditingClient(c);
    setFormName(c.name);
    setFormWhatsapp(c.whatsapp || "");
    setFormLeadId(c.whatsappLeadId || "none");
    setFormDrive(c.driveFolderUrl || "");
    setFormNotes(c.notes || "");
    setFormActive(c.active);
    setFormError("");
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formName.trim()) {
      setFormError("Informe o nome do artista ou cliente.");
      return;
    }

    setIsSubmitting(true);
    setFormError("");

    if (editingClient) {
      const res = await updateClientAction({
        id: editingClient.id,
        name: formName,
        whatsapp: formWhatsapp,
        whatsappLeadId: formLeadId === "none" ? null : formLeadId,
        driveFolderUrl: formDrive,
        notes: formNotes,
        active: formActive,
      });

      if (res.error) {
        setFormError(res.error);
        setIsSubmitting(false);
        return;
      }
    } else {
      const formData = new FormData();
      formData.append("name", formName);
      formData.append("whatsapp", formWhatsapp);
      formData.append("whatsappLeadId", formLeadId);
      formData.append("driveFolderUrl", formDrive);
      formData.append("notes", formNotes);

      const res = await createClientAction(formData);
      if (res.error) {
        setFormError(res.error);
        setIsSubmitting(false);
        return;
      }
    }

    setIsSubmitting(false);
    setModalOpen(false);
    router.refresh();
  };

  const getInitials = (name: string) => {
    const parts = name.trim().split(" ");
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header Principal */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-[#1f2334]">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
            <Users className="w-6 h-6 text-indigo-400" />
            <span>Base de Dados de Clientes</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Diretório oficial de artistas, contatos de WhatsApp e histórico de projetos contratados.
          </p>
        </div>

        <button
          onClick={handleOpenCreate}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-indigo-600/30 transition-all self-start sm:self-auto"
        >
          <UserPlus className="w-4 h-4" />
          <span>+ Cadastrar Cliente</span>
        </button>
      </div>

      {/* Cards de Métricas no Topo (estilo cards da foto) */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#161822] border border-[#232738] shadow-lg space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Total de Clientes
          </span>
          <p className="text-2xl font-black text-white">{totalClients}</p>
          <span className="text-[10px] text-emerald-400 font-medium">
            {activeClients} clientes ativos
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-[#201828] to-[#14121d] border border-[#3b294e] shadow-lg space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-pink-400">
            Atendimento: Anelise
          </span>
          <p className="text-2xl font-black text-pink-300">{aneliseClients}</p>
          <span className="text-[10px] text-pink-400/80 font-medium">
            Líder no WhatsApp
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-[#161f30] to-[#12141d] border border-[#243350] shadow-lg space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-blue-400">
            Atendimento: Matheus
          </span>
          <p className="text-2xl font-black text-blue-300">{matheusClients}</p>
          <span className="text-[10px] text-blue-400/80 font-medium">
            Líder no WhatsApp
          </span>
        </div>

        <div className="p-4 rounded-2xl bg-[#161822] border border-[#232738] shadow-lg space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-teal-400">
            Projetos Ativos
          </span>
          <p className="text-2xl font-black text-teal-300">
            {clients.reduce((acc, c) => acc + (c.projects?.length || 0), 0)}
          </p>
          <span className="text-[10px] text-slate-400">Em execução na Avera</span>
        </div>
      </div>

      {/* Barra de Filtros e Busca */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-4 rounded-2xl bg-[#141620] border border-[#232738]">
        {/* Campo de Busca */}
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Pesquisar por nome do artista, telefone ou notas..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-[#181a24] border border-[#2a2f42] rounded-xl pl-10 pr-4 py-2 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        {/* Filtros por Líder no WhatsApp */}
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setLeadFilter("ALL")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              leadFilter === "ALL"
                ? "bg-indigo-600 text-white"
                : "bg-[#181a24] text-slate-400 hover:text-white border border-[#2a2f42]"
            }`}
          >
            Todos
          </button>
          <button
            onClick={() => setLeadFilter("anelise")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              leadFilter === "anelise"
                ? "bg-pink-600 text-white"
                : "bg-pink-500/10 text-pink-400 hover:bg-pink-500/20 border border-pink-500/30"
            }`}
          >
            Anelise ({aneliseClients})
          </button>
          <button
            onClick={() => setLeadFilter("matheus")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              leadFilter === "matheus"
                ? "bg-blue-600 text-white"
                : "bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 border border-blue-500/30"
            }`}
          >
            Matheus ({matheusClients})
          </button>
        </div>
      </div>

      {/* Grid de Cards de Clientes */}
      {filteredClients.length === 0 ? (
        <div className="p-12 text-center rounded-2xl border border-dashed border-[#232738] bg-[#141620]">
          <Users className="w-8 h-8 text-slate-600 mx-auto mb-2" />
          <h3 className="text-base font-bold text-white">Nenhum cliente encontrado</h3>
          <p className="text-xs text-slate-400 mt-1">
            Tente alterar o filtro de busca ou cadastre um novo cliente.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {filteredClients.map((client) => {
            const hasDrive = !!client.driveFolderUrl;
            const hasWhatsapp = !!client.whatsapp;
            const cleanPhone = client.whatsapp?.replace(/\D/g, "");
            const leadName = client.whatsappLead?.name || "Não atribuído";
            const isAnelise = leadName.toLowerCase().includes("anelise");
            const isMatheus = leadName.toLowerCase().includes("matheus");

            return (
              <div
                key={client.id}
                className="p-5 rounded-2xl bg-[#161822] border border-[#232738] hover:border-[#38415d] transition-all flex flex-col justify-between shadow-xl space-y-4 group"
              >
                <div className="space-y-3">
                  {/* Cabeçalho do Card */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-600 to-purple-600 flex items-center justify-center text-white font-black text-sm shadow-md">
                        {getInitials(client.name)}
                      </div>
                      <div>
                        <h3 className="text-base font-bold text-white leading-tight">
                          {client.name}
                        </h3>
                        <span className="text-[11px] text-slate-400">
                          {client.contactPerson || "Artista Principal"}
                        </span>
                      </div>
                    </div>

                    <button
                      onClick={() => handleOpenEdit(client)}
                      className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-[#202434] transition-colors"
                      title="Editar dados do cliente"
                    >
                      <Edit2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* WhatsApp e Responsável */}
                  <div className="p-3 rounded-xl bg-[#1a1d29] border border-white/5 space-y-2">
                    <div className="flex items-center justify-between text-xs">
                      <span className="text-slate-400 flex items-center gap-1.5">
                        <MessageCircle className="w-3.5 h-3.5 text-emerald-400" />
                        WhatsApp:
                      </span>
                      {hasWhatsapp ? (
                        <a
                          href={`https://wa.me/55${cleanPhone}`}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="font-mono text-emerald-400 hover:underline flex items-center gap-1"
                        >
                          {client.whatsapp}
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      ) : (
                        <span className="text-slate-500">Não informado</span>
                      )}
                    </div>

                    <div className="flex items-center justify-between text-xs pt-1.5 border-t border-white/5">
                      <span className="text-slate-400">Dono do Atendimento:</span>
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          isAnelise
                            ? "bg-pink-500/15 text-pink-300 border border-pink-500/30"
                            : isMatheus
                            ? "bg-blue-500/15 text-blue-300 border border-blue-500/30"
                            : "bg-slate-800 text-slate-300"
                        }`}
                      >
                        {leadName}
                      </span>
                    </div>
                  </div>

                  {/* Observações / Notas */}
                  {client.notes && (
                    <p className="text-xs text-slate-300 bg-[#12131b] p-2.5 rounded-xl border border-white/5 line-clamp-2">
                      <span className="text-slate-500 font-semibold block mb-0.5">Notas:</span>
                      {client.notes}
                    </p>
                  )}

                  {/* Projetos Vinculados */}
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-1.5">
                      Serviços Contratados
                    </span>
                    {client.projects && client.projects.length > 0 ? (
                      <div className="flex flex-wrap gap-1.5">
                        {client.projects.map((p) => (
                          <span
                            key={p.id}
                            className="inline-flex items-center gap-1 text-[10px] font-medium px-2 py-0.5 rounded-lg bg-[#202434] text-slate-200 border border-white/5"
                          >
                            <span
                              className="w-1.5 h-1.5 rounded-full"
                              style={{ backgroundColor: p.service.area.color }}
                            />
                            {p.service.name}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-xs text-slate-500">
                        Nenhum projeto ativo no momento.
                      </span>
                    )}
                  </div>
                </div>

                {/* Rodapé do Card com Ação de Iniciar Projeto */}
                <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-2">
                  {hasDrive ? (
                    <a
                      href={client.driveFolderUrl!}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
                    >
                      <Folder className="w-3.5 h-3.5" />
                      <span>Drive</span>
                    </a>
                  ) : (
                    <span className="text-xs text-slate-600">Sem pasta Drive</span>
                  )}

                  <Link
                    href={`/projetos?novo=true&clientId=${client.id}`}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-indigo-600/20 hover:bg-indigo-600 text-indigo-300 hover:text-white text-xs font-semibold border border-indigo-500/30 transition-all"
                  >
                    <Briefcase className="w-3 h-3" />
                    <span>Novo Projeto</span>
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal de Cadastrar / Editar Cliente */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-150">
          <div className="w-full max-w-lg rounded-2xl bg-[#161822] border border-[#272d40] shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#232738]">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <Users className="w-5 h-5 text-indigo-400" />
                <span>{editingClient ? "Editar Cliente" : "Cadastrar Novo Cliente"}</span>
              </h2>
              <button
                onClick={() => setModalOpen(false)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {formError && (
              <div className="p-3 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{formError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Nome do Artista / Cliente *
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: Santta, Theaga, Drik Barbosa, Paula..."
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  className="w-full bg-[#181a24] border border-[#2a2f42] rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    WhatsApp (com DDD)
                  </label>
                  <input
                    type="text"
                    placeholder="Ex: 11 99999-9999"
                    value={formWhatsapp}
                    onChange={(e) => setFormWhatsapp(e.target.value)}
                    className="w-full bg-[#181a24] border border-[#2a2f42] rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-300 mb-1">
                    Dono no WhatsApp
                  </label>
                  <select
                    value={formLeadId}
                    onChange={(e) => setFormLeadId(e.target.value)}
                    className="w-full bg-[#181a24] border border-[#2a2f42] rounded-xl px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="none">A definir</option>
                    {members.map((m) => (
                      <option key={m.id} value={m.id}>
                        {m.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Link da Pasta no Google Drive (opcional)
                </label>
                <input
                  type="url"
                  placeholder="https://drive.google.com/drive/folders/..."
                  value={formDrive}
                  onChange={(e) => setFormDrive(e.target.value)}
                  className="w-full bg-[#181a24] border border-[#2a2f42] rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-300 mb-1">
                  Observações & Preferências do Artista
                </label>
                <textarea
                  rows={3}
                  placeholder="Ex: estilo musical, preferências de comunicação, horários..."
                  value={formNotes}
                  onChange={(e) => setFormNotes(e.target.value)}
                  className="w-full bg-[#181a24] border border-[#2a2f42] rounded-xl px-3.5 py-2 text-sm text-white placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#232738]">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs sm:text-sm font-medium text-slate-400 hover:text-white hover:bg-[#202434] rounded-xl transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="inline-flex items-center gap-1.5 px-4 py-2 text-xs sm:text-sm font-semibold text-white bg-indigo-600 hover:bg-indigo-700 rounded-xl shadow-md shadow-indigo-600/30 transition disabled:opacity-50"
                >
                  <Check className="w-4 h-4" />
                  <span>{isSubmitting ? "Salvando..." : "Salvar Cliente"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
