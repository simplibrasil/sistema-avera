"use client";

import { useState } from "react";
import {
  FolderPlus,
  UserPlus,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  RotateCw,
  AlertCircle,
  Users,
} from "lucide-react";
import { CreateProjectModal } from "./create-project-modal";
import { CreateClientModal } from "./create-client-modal";
import { formatDateBR, formatCurrencyBRL } from "@/lib/date-utils";
import { triggerNextCycleAction, updateProjectStatusAction } from "@/app/actions/project-actions";
import { useRouter } from "next/navigation";

type Project = {
  id: string;
  name: string;
  financial?: { value: any } | null;
  status: string;
  recurrence: string;
  currentCycle: number;
  startDate: Date;
  recordingDate: Date | null;
  releaseDate: Date | null;
  client: {
    id: string;
    name: string;
    whatsapp: string | null;
    whatsappLead: { name: string } | null;
  };
  service: {
    id: string;
    name: string;
    area: { name: string; color: string };
  };
  tasks: {
    id: string;
    title: string;
    status: string;
    order: number;
    dueDate: Date | null;
    assignee: { name: string } | null;
    isThirdParty: boolean;
  }[];
};

type ProjectsClientViewProps = {
  projects: Project[];
  clients: { id: string; name: string }[];
  services: any[];
  members: { id: string; name: string }[];
  isAdmin: boolean;
};

export function ProjectsClientView({
  projects,
  clients,
  services,
  members,
  isAdmin,
}: ProjectsClientViewProps) {
  const router = useRouter();
  const [projectModalOpen, setProjectModalOpen] = useState(false);
  const [clientModalOpen, setClientModalOpen] = useState(false);
  const [selectedClientId, setSelectedClientId] = useState<string>("all");
  const [advancingProjectId, setAdvancingProjectId] = useState<string | null>(null);

  const filteredProjects =
    selectedClientId === "all"
      ? projects
      : projects.filter((p) => p.client.id === selectedClientId);

  const handleAdvanceCycle = async (projectId: string) => {
    if (!confirm("Deseja gerar as tarefas do ciclo do próximo mês para este projeto?")) return;
    setAdvancingProjectId(projectId);
    await triggerNextCycleAction(projectId);
    setAdvancingProjectId(null);
    router.refresh();
  };

  const handleUpdateStatus = async (projectId: string, newStatus: string) => {
    await updateProjectStatusAction(projectId, newStatus);
    router.refresh();
  };

  return (
    <div className="space-y-6">
      {/* Header com Ações */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-slate-200 dark:border-slate-800">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-slate-900 dark:text-white flex items-center gap-2">
            <Users className="w-6 h-6 text-indigo-600" />
            Clientes e Projetos Contratados
          </h1>
          <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400 mt-1">
            Cada projeto contratado gera as tarefas automáticas com responsáveis, prazos e a próxima etapa.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setClientModalOpen(true)}
            className="px-3.5 py-2 text-xs font-semibold rounded-lg border border-slate-300 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-700 dark:text-slate-200 transition flex items-center gap-1.5 shadow-sm"
          >
            <UserPlus className="w-3.5 h-3.5 text-indigo-500" />
            Novo Artista/Cliente
          </button>
          <button
            onClick={() => setProjectModalOpen(true)}
            className="px-3.5 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition flex items-center gap-1.5 shadow-sm"
          >
            <FolderPlus className="w-3.5 h-3.5" />
            Novo Projeto
          </button>
        </div>
      </div>

      {/* Filtro Rápido por Cliente */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        <span className="text-xs font-semibold text-slate-500 shrink-0">Filtrar por artista:</span>
        <button
          onClick={() => setSelectedClientId("all")}
          className={`px-3 py-1 rounded-full text-xs font-medium transition shrink-0 ${
            selectedClientId === "all"
              ? "bg-indigo-600 text-white font-bold"
              : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200"
          }`}
        >
          Todos ({projects.length})
        </button>
        {clients.map((c) => (
          <button
            key={c.id}
            onClick={() => setSelectedClientId(c.id)}
            className={`px-3 py-1 rounded-full text-xs font-medium transition shrink-0 ${
              selectedClientId === c.id
                ? "bg-indigo-600 text-white font-bold"
                : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200"
            }`}
          >
            {c.name}
          </button>
        ))}
      </div>

      {/* Grade de Projetos */}
      {filteredProjects.length === 0 ? (
        <div className="p-12 text-center rounded-2xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900/50">
          <FolderPlus className="w-10 h-10 text-slate-400 mx-auto mb-3 opacity-60" />
          <h3 className="text-sm font-bold text-slate-800 dark:text-slate-200">
            Nenhum projeto encontrado
          </h3>
          <p className="text-xs text-slate-500 max-w-sm mx-auto mt-1 mb-4">
            Crie o primeiro projeto para disparar a geração automática das tarefas operacionais.
          </p>
          <button
            onClick={() => setProjectModalOpen(true)}
            className="px-4 py-2 text-xs font-semibold rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition inline-flex items-center gap-1.5"
          >
            <FolderPlus className="w-4 h-4" />
            Criar Primeiro Projeto
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {filteredProjects.map((project) => {
            const completedCount = project.tasks.filter((t) => t.status === "DONE").length;
            const totalCount = project.tasks.length;
            const progress = totalCount > 0 ? Math.round((completedCount / totalCount) * 100) : 0;

            // Próxima tarefa pendente
            const nextTask = project.tasks
              .filter((t) => t.status !== "DONE")
              .sort((a, b) => a.order - b.order)[0];

            return (
              <div
                key={project.id}
                className="p-5 rounded-2xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 shadow-sm flex flex-col justify-between hover:shadow-md transition"
              >
                <div>
                  {/* Topo do Card */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: project.service.area.color }}
                        />
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                          {project.service.area.name}
                        </span>
                        {project.recurrence === "MONTHLY" && (
                          <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300">
                            Mensal • Ciclo {project.currentCycle}
                          </span>
                        )}
                      </div>
                      <h3 className="text-base font-bold text-slate-900 dark:text-white">
                        {project.client.name}
                      </h3>
                      <p className="text-xs text-slate-500 font-medium">
                        {project.service.name}
                      </p>
                    </div>

                    <div className="text-right">
                      {isAdmin && (
                        <p className="text-xs font-bold text-slate-900 dark:text-slate-100">
                          {formatCurrencyBRL(project.financial?.value)}
                        </p>
                      )}
                      <span
                        className={`inline-block mt-1 px-2 py-0.5 rounded-full text-[10px] font-bold ${
                          project.status === "IN_PROGRESS"
                            ? "bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400"
                            : project.status === "PAUSED"
                            ? "bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-400"
                            : "bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400"
                        }`}
                      >
                        {project.status === "IN_PROGRESS"
                          ? "Em Andamento"
                          : project.status === "PAUSED"
                          ? "Pausado"
                          : "Concluído"}
                      </span>
                    </div>
                  </div>

                  {/* Informações de Contato / Dono do WhatsApp */}
                  <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500 mb-4 bg-slate-50 dark:bg-slate-800/40 p-2.5 rounded-xl border border-slate-100 dark:border-slate-800">
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">
                        WhatsApp Lead
                      </span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {project.client.whatsappLead?.name || "Não atribuído"}
                      </span>
                    </div>
                    {project.recordingDate && (
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          Gravação
                        </span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {formatDateBR(project.recordingDate)}
                        </span>
                      </div>
                    )}
                    {project.releaseDate && (
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-400 block">
                          Lançamento
                        </span>
                        <span className="font-semibold text-slate-800 dark:text-slate-200">
                          {formatDateBR(project.releaseDate)}
                        </span>
                      </div>
                    )}
                    <div>
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">
                        Início
                      </span>
                      <span className="font-semibold text-slate-800 dark:text-slate-200">
                        {formatDateBR(project.startDate)}
                      </span>
                    </div>
                  </div>

                  {/* PRÓXIMA TAREFA DESTACADA (Regra Central) */}
                  <div className="mb-4 p-3.5 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/50">
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-[10px] uppercase font-extrabold text-indigo-700 dark:text-indigo-400 tracking-wider flex items-center gap-1">
                        <ArrowRight className="w-3 h-3" />
                        Próxima Tarefa
                      </span>
                      {nextTask && (
                        <span
                          className={`text-[10px] font-bold px-1.5 py-0.5 rounded ${
                            nextTask.status === "WAITING_CLIENT"
                              ? "bg-amber-100 text-amber-800 dark:bg-amber-950/80 dark:text-amber-300"
                              : "bg-indigo-100 text-indigo-800 dark:bg-indigo-900/60 dark:text-indigo-200"
                          }`}
                        >
                          {nextTask.status === "WAITING_CLIENT" ? "Aguardando Cliente" : "A Fazer"}
                        </span>
                      )}
                    </div>

                    {nextTask ? (
                      <div>
                        <p className="text-xs font-bold text-slate-900 dark:text-white line-clamp-1">
                          #{nextTask.order} {nextTask.title}
                        </p>
                        <div className="flex items-center justify-between text-[11px] text-slate-500 mt-1.5">
                          <span className="flex items-center gap-1 font-medium text-slate-700 dark:text-slate-300">
                            {nextTask.isThirdParty ? (
                              <span className="italic text-slate-400">Fornecedor Externo</span>
                            ) : nextTask.assignee ? (
                              `Responsável: ${nextTask.assignee.name}`
                            ) : (
                              <span className="text-rose-500 font-bold flex items-center gap-0.5">
                                <AlertCircle className="w-3 h-3" /> Sem responsável
                              </span>
                            )}
                          </span>
                          <span className="flex items-center gap-1 font-semibold text-slate-700 dark:text-slate-300">
                            <Calendar className="w-3 h-3 text-slate-400" />
                            {formatDateBR(nextTask.dueDate)}
                          </span>
                        </div>
                      </div>
                    ) : (
                      <p className="text-xs text-emerald-600 dark:text-emerald-400 font-semibold flex items-center gap-1">
                        <CheckCircle2 className="w-4 h-4" /> Todas as etapas foram concluídas!
                      </p>
                    )}
                  </div>

                  {/* Barra de Progresso das Tarefas */}
                  <div>
                    <div className="flex items-center justify-between text-[11px] font-medium text-slate-500 mb-1">
                      <span>Progresso do Processo</span>
                      <span>
                        {completedCount} de {totalCount} tarefas ({progress}%)
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-100 dark:bg-slate-800 overflow-hidden">
                      <div
                        className="h-full bg-indigo-600 transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>
                </div>

                {/* Rodapé do Card com Ações */}
                <div className="mt-5 pt-3 border-t border-slate-100 dark:border-slate-800 flex items-center justify-between">
                  {project.recurrence === "MONTHLY" ? (
                    <button
                      onClick={() => handleAdvanceCycle(project.id)}
                      disabled={advancingProjectId === project.id}
                      className="text-xs font-semibold text-indigo-600 dark:text-indigo-400 hover:underline flex items-center gap-1"
                    >
                      <RotateCw className={`w-3.5 h-3.5 ${advancingProjectId === project.id ? "animate-spin" : ""}`} />
                      {advancingProjectId === project.id ? "Gerando ciclo..." : "Gerar Próximo Ciclo Mensal"}
                    </button>
                  ) : (
                    <span className="text-[11px] text-slate-400">Serviço pontual</span>
                  )}

                  {isAdmin && (
                    <div className="flex items-center gap-1.5">
                      {project.status === "IN_PROGRESS" && (
                        <button
                          onClick={() => handleUpdateStatus(project.id, "PAUSED")}
                          className="text-[11px] font-medium text-slate-500 hover:text-amber-600"
                        >
                          Pausar
                        </button>
                      )}
                      {project.status === "PAUSED" && (
                        <button
                          onClick={() => handleUpdateStatus(project.id, "IN_PROGRESS")}
                          className="text-[11px] font-medium text-indigo-600"
                        >
                          Retomar
                        </button>
                      )}
                      {project.status !== "COMPLETED" && (
                        <button
                          onClick={() => handleUpdateStatus(project.id, "COMPLETED")}
                          className="text-[11px] font-medium text-emerald-600 hover:underline"
                        >
                          Concluir
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modais */}
      <CreateProjectModal
        isOpen={projectModalOpen}
        onClose={() => setProjectModalOpen(false)}
        clients={clients}
        services={services}
        isAdmin={isAdmin}
      />

      <CreateClientModal
        isOpen={clientModalOpen}
        onClose={() => setClientModalOpen(false)}
        members={members}
      />
    </div>
  );
}
