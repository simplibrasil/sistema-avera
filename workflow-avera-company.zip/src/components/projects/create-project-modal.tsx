"use client";

import { useState } from "react";
import { createProjectAction } from "@/app/actions/project-actions";
import { FolderPlus, X, Calendar, DollarSign, AlertCircle, CheckCircle2 } from "lucide-react";
import { useRouter } from "next/navigation";

type Client = { id: string; name: string };
type Service = {
  id: string;
  name: string;
  price: any;
  priceType: string;
  area: { name: string; color: string };
};

type CreateProjectModalProps = {
  isOpen: boolean;
  onClose: () => void;
  clients: Client[];
  services: Service[];
  isAdmin: boolean;
  initialClientId?: string;
};

export function CreateProjectModal({
  isOpen,
  onClose,
  clients,
  services,
  isAdmin,
  initialClientId,
}: CreateProjectModalProps) {
  const router = useRouter();
  const [clientId, setClientId] = useState<string>(initialClientId || clients[0]?.id || "");
  const [serviceId, setServiceId] = useState<string>(services[0]?.id || "");
  const [value, setValue] = useState<string>("");
  const [startDate, setStartDate] = useState<string>(new Date().toISOString().split("T")[0]);

  // Datas-âncora
  const [recordingDate, setRecordingDate] = useState<string>("");
  const [releaseDate, setReleaseDate] = useState<string>("");
  const [cycleStartDate, setCycleStartDate] = useState<string>(new Date().toISOString().split("T")[0]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [success, setSuccess] = useState<boolean>(false);

  if (!isOpen) return null;

  const selectedService = services.find((s) => s.id === serviceId);
  const isMonthly = selectedService?.priceType === "MONTHLY";
  const isRecordingService =
    selectedService?.name.toLowerCase().includes("conteúdo") ||
    selectedService?.name.toLowerCase().includes("videoclipe");
  const isReleaseService =
    selectedService?.name.toLowerCase().includes("lançamento") ||
    selectedService?.name.toLowerCase().includes("registro");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError("");

    const res = await createProjectAction({
      clientId,
      serviceId,
      startDate,
      value: isAdmin && value ? parseFloat(value) : undefined,
      recordingDate: isRecordingService && recordingDate ? recordingDate : undefined,
      releaseDate: isReleaseService && releaseDate ? releaseDate : undefined,
      cycleStartDate: isMonthly && cycleStartDate ? cycleStartDate : undefined,
    });

    if (res?.error) {
      setError(res.error);
      setLoading(false);
    } else {
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        onClose();
        router.refresh();
      }, 1200);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl p-6 relative max-h-[90vh] overflow-y-auto">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-indigo-50 dark:bg-indigo-950/60 text-indigo-600 dark:text-indigo-400 flex items-center justify-center">
            <FolderPlus className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-slate-900 dark:text-white">Novo Projeto / Contrato</h2>
            <p className="text-xs text-slate-500">
              O sistema gerará automaticamente todas as tarefas do modelo de processo.
            </p>
          </div>
        </div>

        {error && (
          <div className="p-3 mb-4 text-xs rounded-lg bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 text-rose-700 dark:text-rose-300 flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            {error}
          </div>
        )}

        {success ? (
          <div className="py-8 text-center flex flex-col items-center gap-2">
            <CheckCircle2 className="w-10 h-10 text-emerald-500" />
            <h3 className="text-base font-bold text-slate-900 dark:text-white">
              Projeto criado com sucesso!
            </h3>
            <p className="text-xs text-slate-500">
              Todas as tarefas foram geradas com responsáveis e prazos calculados.
            </p>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                  Cliente / Artista
                </label>
                <select
                  required
                  value={clientId}
                  onChange={(e) => setClientId(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                >
                  {clients.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                  Serviço Contratado
                </label>
                <select
                  required
                  value={serviceId}
                  onChange={(e) => setServiceId(e.target.value)}
                  className="w-full text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 p-2.5 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                >
                  {services.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.name} ({s.priceType === "MONTHLY" ? "Mensal" : "Pontual"})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                  Data de Início
                </label>
                <div className="relative">
                  <Calendar className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                  <input
                    type="date"
                    required
                    value={startDate}
                    onChange={(e) => setStartDate(e.target.value)}
                    className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                  />
                </div>
              </div>

              {isAdmin && (
                <div>
                  <label className="block text-xs font-semibold uppercase tracking-wider text-slate-600 dark:text-slate-400 mb-1">
                    Valor Acordado (R$)
                  </label>
                  <div className="relative">
                    <DollarSign className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                    <input
                      type="number"
                      step="0.01"
                      placeholder={selectedService?.price ? String(selectedService.price) : "Padrão do catálogo"}
                      value={value}
                      onChange={(e) => setValue(e.target.value)}
                      className="w-full pl-9 pr-3 py-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white focus:ring-2 focus:ring-indigo-500"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Campos de Datas-Âncora contextuais */}
            {(isRecordingService || isReleaseService || isMonthly) && (
              <div className="p-3.5 rounded-xl bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 space-y-3">
                <p className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wider">
                  Datas-Âncora para Cálculo de Prazos
                </p>

                {isRecordingService && (
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Data da Sessão de Gravação (calcula preparação e entregas)
                    </label>
                    <input
                      type="date"
                      value={recordingDate}
                      onChange={(e) => setRecordingDate(e.target.value)}
                      className="w-full p-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                )}

                {isReleaseService && (
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Data do Lançamento da Música/Álbum (cronograma reverso)
                    </label>
                    <input
                      type="date"
                      value={releaseDate}
                      onChange={(e) => setReleaseDate(e.target.value)}
                      className="w-full p-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                )}

                {isMonthly && (
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-600 dark:text-slate-400 mb-1">
                      Início do Ciclo Mensal
                    </label>
                    <input
                      type="date"
                      value={cycleStartDate}
                      onChange={(e) => setCycleStartDate(e.target.value)}
                      className="w-full p-2 text-xs rounded-lg border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  </div>
                )}
              </div>
            )}

            <div className="pt-4 border-t border-slate-100 dark:border-slate-800 flex justify-end gap-2">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-xs font-medium rounded-lg text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800 transition"
              >
                Cancelar
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-4 py-2 text-xs font-medium rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white transition disabled:opacity-50 flex items-center gap-1.5 shadow-sm"
              >
                {loading ? "Gerando Tarefas..." : "Criar Projeto e Gerar Tarefas"}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
