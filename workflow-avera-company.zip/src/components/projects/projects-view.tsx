"use client";

import { useState } from "react";
import {
  FolderPlus,
  Calendar,
  CheckCircle2,
  Clock,
  ArrowRight,
  TrendingUp,
  RotateCw,
  AlertCircle,
  Briefcase,
  Layers,
  Search,
  Filter,
  Check,
  Sparkles,
} from "lucide-react";
import { CreateProjectModal } from "./create-project-modal";
import { formatDateBR, formatCurrencyBRL } from "@/lib/date-utils";
import { triggerNextCycleAction, updateProjectStatusAction } from "@/app/actions/project-actions";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";

type Project = {
  id: string;
  name: string;
  financial?: { value: any } | null;
  status: string;
  recurrence: string;
  currentCycle: number;
  startDate: Date | string;
  recordingDate: Date | string | null;
  releaseDate: Date | string | null;
  client: {
    id: string;
    name: string;
    whatsapp: string | null;
    whatsappLead: { name: string } | null;
  };
  service: {
    id: string;
    name: string;
    area: { name: string; color: string };
  };
  tasks: {
    id: string;
    title: string;
    status: string;
    order: number;
    dueDate: Date | string | null;
    assignee: { name: string } | null;
    isThirdParty: boolean;
  }[];
};

type ProjectsViewProps = {
  projects: Project[];
  clients: { id: string; name: string }[];
  services: any[];
  members: { id: string; name: string }[];
  isAdmin: boolean;
};

export function ProjectsView({
  projects,
  clients,
  services,
  members,
  isAdmin,
}: ProjectsViewProps) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const [projectModalOpen, setProjectModalOpen] = useState(
    searchParams.get("novo") === "true"
  );
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [search, setSearch] = useState("");
  const [loadingCycleId, setLoadingCycleId] = useState<string | null>(null);

  const filteredProjects = projects.filter((p) => {
    if (statusFilter !== "ALL" && p.status !== statusFilter) return false;
    if (search.trim()) {
      const q = search.toLowerCase();
      const matchClient = p.client.name.toLowerCase().includes(q);
      const matchService = p.service.name.toLowerCase().includes(q);
      return matchClient || matchService;
    }
    return true;
  });

  const handleNextCycle = async (projectId: string) => {
    setLoadingCycleId(projectId);
    await triggerNextCycleAction(projectId);
    setLoadingCycleId(null);
    router.refresh();
  };

  const handleStatusChange = async (projectId: string, newStatus: string) => {
    await updateProjectStatusAction(projectId, newStatus);
    router.refresh();
  };

  const activeCount = projects.filter((p) => p.status === "IN_PROGRESS").length;
  const recurringCount = projects.filter((p) => p.recurrence === "MONTHLY").length;
  const doneCount = projects.filter((p) => p.status === "COMPLETED").length;

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Header Principal */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2 border-b border-[#1f2334]">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
            <Briefcase className="w-6 h-6 text-indigo-400" />
            <span>Esteira de Projetos & Execução</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Acompanhamento de serviços contratados, cronogramas automáticos e tarefas ativas da equipe.
          </p>
        </div>

        <button
          onClick={() => setProjectModalOpen(true)}
          className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs sm:text-sm font-semibold shadow-lg shadow-indigo-600/30 transition-all self-start sm:self-auto"
        >
          <FolderPlus className="w-4 h-4" />
          <span>+ Iniciar Novo Projeto</span>
        </button>
      </div>

      {/* Cards de Métricas no Topo */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-2xl bg-[#161822] border border-[#232738] shadow-lg space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
            Projetos Ativos
          </span>
          <p className="text-2xl font-black text-white">{activeCount}</p>
          <span className="text-[10px] text-indigo-400 font-medium">Em andamento</span>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-[#162726] to-[#12141d] border border-[#213a38] shadow-lg space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-teal-400">
            Recorrentes (Mensais)
          </span>
          <p className="text-2xl font-black text-teal-300">{recurringCount}</p>
          <span className="text-[10px] text-teal-400/80 font-medium">Tráfego & Redes</span>
        </div>

        <div className="p-4 rounded-2xl bg-gradient-to-br from-[#231e34] to-[#12141d] border border-[#342a4a] shadow-lg space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-purple-400">
            Lançamentos / Gravações
          </span>
          <p className="text-2xl font-black text-purple-300">
            {projects.filter((p) => p.releaseDate || p.recordingDate).length}
          </p>
          <span className="text-[10px] text-purple-400/80 font-medium">Com data-âncora</span>
        </div>

        <div className="p-4 rounded-2xl bg-[#161822] border border-[#232738] shadow-lg space-y-1">
          <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
            Concluídos
          </span>
          <p className="text-2xl font-black text-emerald-300">{doneCount}</p>
          <span className="text-[10px] text-slate-400">Entregues com sucesso</span>
        </div>
      </div>

      {/* Barra de Filtros */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-4 rounded-2xl bg-[#141620] border border-[#232738]">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            placeholder="Buscar por cliente ou serviço..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-[#181a24] border border-[#2a2f42] rounded-xl pl-10 pr-4 py-2 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => setStatusFilter("ALL")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              statusFilter === "ALL"
                ? "bg-indigo-600 text-white"
                : "bg-[#181a24] text-slate-400 hover:text-white border border-[#2a2f42]"
            }`}
          >
            Todos ({projects.length})
          </button>
          <button
            onClick={() => setStatusFilter("IN_PROGRESS")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              statusFilter === "IN_PROGRESS"
                ? "bg-blue-600 text-white"
                : "bg-blue-500/10 text-blue-400 hover:bg-blue-500/20 border border-blue-500/30"
            }`}
          >
            Em Andamento ({activeCount})
          </button>
          <button
            onClick={() => setStatusFilter("COMPLETED")}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              statusFilter === "COMPLETED"
                ? "bg-emerald-600 text-white"
                : "bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 border border-emerald-500/30"
            }`}
          >
            Concluídos ({doneCount})
          </button>
        </div>
      </div>

      {/* Grid de Projetos */}
      {filteredProjects.length === 0 ? (
        <div className="p-12 text-center rounded-2xl border border-dashed border-[#232738] bg-[#141620]">
          <Briefcase className="w-8 h-8 text-slate-600 mx-auto mb-2" />
          <h3 className="text-base font-bold text-white">Nenhum projeto cadastrado</h3>
          <p className="text-xs text-slate-400 mt-1 mb-4">
            Inicie um novo projeto para gerar automaticamente todas as tarefas com prazos e responsáveis.
          </p>
          <button
            onClick={() => setProjectModalOpen(true)}
            className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-indigo-600 text-white text-xs font-semibold hover:bg-indigo-700"
          >
            <FolderPlus className="w-4 h-4" />
            <span>+ Iniciar Primeiro Projeto</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {filteredProjects.map((project) => {
            const totalTasks = project.tasks.length;
            const doneTasks = project.tasks.filter((t) => t.status === "DONE").length;
            const progress = totalTasks > 0 ? Math.round((doneTasks / totalTasks) * 100) : 0;
            const nextTask = project.tasks.find((t) => t.status !== "DONE");
            const isMonthly = project.recurrence === "MONTHLY";

            return (
              <div
                key={project.id}
                className="p-5 rounded-2xl bg-[#161822] border border-[#232738] hover:border-[#38415d] transition-all flex flex-col justify-between shadow-xl space-y-4"
              >
                <div className="space-y-3">
                  {/* Linha Superior: Serviço e Status */}
                  <div className="flex items-start justify-between gap-3">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2 flex-wrap">
                        <span
                          className="w-2.5 h-2.5 rounded-full"
                          style={{ backgroundColor: project.service.area.color }}
                        />
                        <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                          {project.service.area.name}
                        </span>

                        {isMonthly && (
                          <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-teal-500/10 text-teal-400 border border-teal-500/20">
                            Ciclo {project.currentCycle}
                          </span>
                        )}
                      </div>

                      <h3 className="text-lg font-bold text-white leading-tight">
                        {project.service.name}
                      </h3>
                      <p className="text-xs font-semibold text-indigo-400 flex items-center gap-1">
                        Cliente: <strong className="text-white">{project.client.name}</strong>
                      </p>
                    </div>

                    {/* Status Pill */}
                    <select
                      value={project.status}
                      onChange={(e) => handleStatusChange(project.id, e.target.value)}
                      className={`text-[10px] font-bold rounded-lg px-2.5 py-1 border transition-colors ${
                        project.status === "IN_PROGRESS"
                          ? "bg-blue-500/15 text-blue-300 border-blue-500/30"
                          : project.status === "COMPLETED"
                          ? "bg-emerald-500/15 text-emerald-300 border-emerald-500/30"
                          : "bg-slate-800 text-slate-300 border-slate-700"
                      }`}
                    >
                      <option value="IN_PROGRESS">Em Andamento</option>
                      <option value="WAITING_CLIENT">Aguardando Cliente</option>
                      <option value="PAUSED">Pausado</option>
                      <option value="COMPLETED">Concluído</option>
                    </select>
                  </div>

                  {/* Datas-Âncora e Início */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 p-3 rounded-xl bg-[#1a1d29] border border-white/5 text-xs">
                    <div>
                      <span className="text-slate-500 block text-[10px]">Início</span>
                      <span className="font-mono text-slate-300">{formatDateBR(project.startDate)}</span>
                    </div>

                    {project.recordingDate && (
                      <div>
                        <span className="text-slate-500 block text-[10px]">Gravação</span>
                        <span className="font-mono text-amber-400">{formatDateBR(project.recordingDate)}</span>
                      </div>
                    )}

                    {project.releaseDate && (
                      <div>
                        <span className="text-slate-500 block text-[10px]">Lançamento</span>
                        <span className="font-mono text-purple-400">{formatDateBR(project.releaseDate)}</span>
                      </div>
                    )}

                    {isAdmin && project.financial && (
                      <div>
                        <span className="text-slate-500 block text-[10px]">Valor</span>
                        <span className="font-mono text-emerald-400 font-bold">
                          {formatCurrencyBRL(project.financial.value)}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Barra de Progresso de Tarefas */}
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-xs text-slate-400">
                      <span>Progresso do Projeto</span>
                      <span className="font-semibold text-slate-200">
                        {doneTasks} de {totalTasks} tarefas ({progress}%)
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-[#0e1017] overflow-hidden p-[1px]">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-indigo-500 to-teal-400 transition-all duration-500"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>

                  {/* Próximo Passo a Entregar */}
                  {nextTask && (
                    <div className="p-2.5 rounded-xl bg-[#141620] border border-white/5 flex items-start gap-2">
                      <Clock className="w-4 h-4 text-amber-400 shrink-0 mt-0.5" />
                      <div className="text-xs min-w-0">
                        <span className="text-slate-500 font-semibold block text-[10px] uppercase">
                          Próxima Tarefa:
                        </span>
                        <p className="font-semibold text-slate-200 truncate">
                          #{nextTask.order} {nextTask.title}
                        </p>
                        <p className="text-[11px] text-slate-400 mt-0.5">
                          Responsável: <strong className="text-slate-300">{nextTask.assignee?.name || "Sem responsável"}</strong> • Prazo: {formatDateBR(nextTask.dueDate)}
                        </p>
                      </div>
                    </div>
                  )}
                </div>

                {/* Rodapé do Card com Ações */}
                <div className="pt-3 border-t border-white/5 flex items-center justify-between gap-2">
                  <Link
                    href={`/kanban`}
                    className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-semibold"
                  >
                    <span>Ver no Quadro Kanban</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>

                  {isMonthly && (
                    <button
                      onClick={() => handleNextCycle(project.id)}
                      disabled={loadingCycleId === project.id}
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-teal-500/10 hover:bg-teal-500/20 text-teal-300 text-xs font-semibold border border-teal-500/30 transition disabled:opacity-50"
                      title="Gera automaticamente as tarefas do ciclo do mês seguinte"
                    >
                      <RotateCw className={`w-3 h-3 ${loadingCycleId === project.id ? "animate-spin" : ""}`} />
                      <span>{loadingCycleId === project.id ? "Gerando..." : "Gerar Ciclo Seguinte"}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal de Criação de Projeto */}
      <CreateProjectModal
        isOpen={projectModalOpen}
        onClose={() => setProjectModalOpen(false)}
        clients={clients}
        services={services}
        isAdmin={isAdmin}
      />
    </div>
  );
}
