"use client";

import { useState } from "react";
import {
  CalendarDays,
  CheckCircle2,
  Clock,
  Download,
  HelpCircle,
  MessageSquare,
  Repeat,
  Sparkles,
  User,
  Users,
  Check,
  Edit2,
  X,
  FileSpreadsheet,
} from "lucide-react";
import { updateOpenDecisionAction } from "@/app/actions/ritual-actions";
import { useRouter } from "next/navigation";

type RitualItem = {
  id: string;
  title: string;
  frequency: string;
  dayOfWeek: string | null;
  assigneeDescription: string;
  defaultMemberName: string | null;
  objective: string;
};

type DecisionItem = {
  id: string;
  title: string;
  description: string | null;
  assignee: string | null;
  status: "OPEN" | "IN_DISCUSSION" | "RESOLVED";
  resolutionNotes: string | null;
  updatedAt: Date | string;
};

type RitualsDecisionsViewProps = {
  rituals: RitualItem[];
  decisions: DecisionItem[];
  isAdmin: boolean;
};

export function RitualsDecisionsView({
  rituals,
  decisions,
  isAdmin,
}: RitualsDecisionsViewProps) {
  const router = useRouter();
  const [activeTab, setActiveTab] = useState<"rituals" | "decisions">("rituals");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");

  // Edição de Decisão
  const [editingDecision, setEditingDecision] = useState<DecisionItem | null>(null);
  const [editStatus, setEditStatus] = useState<"OPEN" | "IN_DISCUSSION" | "RESOLVED">("OPEN");
  const [editNotes, setEditNotes] = useState("");
  const [editAssignee, setEditAssignee] = useState("");
  const [isSaving, setIsSaving] = useState(false);

  const filteredDecisions = decisions.filter((d) => {
    if (statusFilter === "ALL") return true;
    return d.status === statusFilter;
  });

  const openCount = decisions.filter((d) => d.status === "OPEN").length;
  const discussionCount = decisions.filter((d) => d.status === "IN_DISCUSSION").length;
  const resolvedCount = decisions.filter((d) => d.status === "RESOLVED").length;

  const handleOpenEdit = (d: DecisionItem) => {
    setEditingDecision(d);
    setEditStatus(d.status);
    setEditNotes(d.resolutionNotes || "");
    setEditAssignee(d.assignee || "");
  };

  const handleSaveDecision = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDecision) return;
    setIsSaving(true);

    await updateOpenDecisionAction({
      id: editingDecision.id,
      status: editStatus,
      resolutionNotes: editNotes,
      assignee: editAssignee,
    });

    setIsSaving(false);
    setEditingDecision(null);
    router.refresh();
  };

  return (
    <div className="space-y-6">
      {/* Top Header & Export Button */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-[#232738]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md">
              <CalendarDays className="w-4 h-4" />
            </div>
            Rituais de Agenda & Decisões Operacionais
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Rotinas fixas semanais para evitar gargalos e registro formal das definições da empresa.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <a
            href="/api/export"
            download="backup-avera-company.xlsx"
            className="inline-flex items-center gap-2 px-3.5 py-2 text-xs sm:text-sm font-semibold rounded-xl bg-emerald-500/15 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/25 shadow-sm transition-all focus:outline-none"
            title="Exportar planilha Excel completa com Clientes, Projetos e Tarefas"
          >
            <FileSpreadsheet className="w-4 h-4" />
            <span>Exportar Backup (.xlsx)</span>
          </a>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex border-b border-[#232738] gap-6">
        <button
          onClick={() => setActiveTab("rituals")}
          className={`pb-3 text-sm font-semibold flex items-center gap-2 relative transition-colors ${
            activeTab === "rituals"
              ? "text-teal-400 border-b-2 border-teal-400"
              : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <Repeat className="w-4 h-4" />
          <span>Rituais Recorrentes</span>
          <span className="ml-1 px-2 py-0.5 text-xs rounded-full bg-[#151722] border border-[#232738] text-slate-300 font-mono">
            {rituals.length}
          </span>
        </button>

        <button
          onClick={() => setActiveTab("decisions")}
          className={`pb-3 text-sm font-semibold flex items-center gap-2 relative transition-colors ${
            activeTab === "decisions"
              ? "text-teal-400 border-b-2 border-teal-400"
              : "text-slate-400 hover:text-slate-200"
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          <span>Decisões em Aberto</span>
          <span className="ml-1 px-2 py-0.5 text-xs rounded-full bg-amber-500/20 text-amber-400 border border-amber-500/30 font-mono font-medium">
            {openCount} pendente{openCount !== 1 ? "s" : ""}
          </span>
        </button>
      </div>

      {/* TAB 1: RITUAIS RECORRENTES */}
      {activeTab === "rituals" && (
        <div className="space-y-4">
          <div className="p-4 rounded-2xl bg-[#151722] border border-indigo-500/30 flex items-start gap-3 shadow-md">
            <Sparkles className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <div className="text-xs sm:text-sm text-indigo-200 leading-relaxed">
              <span className="font-semibold text-white">Regra de ouro da Avera:</span> Os processos se apoiam nessas poucas
              rotinas fixas na agenda de Anelise e Matheus. Sem elas, o acompanhamento operacional volta a depender
              de memória individual.
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {rituals.map((ritual, idx) => {
              const isTrafegoReport = ritual.title.toLowerCase().includes("relatório de tráfego");
              return (
                <div
                  key={ritual.id || idx}
                  className="rounded-2xl border border-[#232738] bg-[#151722] p-5 shadow-sm hover:border-[#38415d] hover:bg-[#191c2a] transition-all flex flex-col justify-between group"
                >
                  <div className="space-y-3">
                    <div className="flex items-start justify-between gap-2">
                      <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-medium bg-[#111218] border border-[#232738] text-slate-300">
                        <Clock className="w-3 h-3 text-indigo-400" />
                        {ritual.frequency}
                      </span>

                      <span
                        className={`text-xs px-2.5 py-1 rounded-full font-semibold border ${
                          ritual.assigneeDescription.includes("M") && !ritual.assigneeDescription.includes("A")
                            ? "bg-blue-500/20 text-blue-300 border-blue-500/30"
                            : ritual.assigneeDescription.includes("A") && !ritual.assigneeDescription.includes("M")
                            ? "bg-pink-500/20 text-pink-300 border-pink-500/30"
                            : "bg-purple-500/20 text-purple-300 border-purple-500/30"
                        }`}
                      >
                        {ritual.assigneeDescription}
                      </span>
                    </div>

                    <div>
                      <h3 className="text-base font-bold text-white leading-tight group-hover:text-indigo-300 transition-colors">
                        {ritual.title}
                      </h3>
                      <p className="text-xs text-slate-400 mt-1">
                        Responsável:{" "}
                        <span className="font-semibold text-slate-200">
                          {ritual.defaultMemberName || ritual.assigneeDescription}
                        </span>
                      </p>
                    </div>

                    {isTrafegoReport && (
                      <div className="text-xs px-2.5 py-2 rounded-xl bg-amber-500/10 border border-amber-500/25 text-amber-300">
                        <strong>Divisão oficial:</strong> Matheus exporta os números brutos às sextas e Anelise monta a análise.
                      </div>
                    )}

                    <div className="pt-2 border-t border-[#1f2333]">
                      <span className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                        Objetivo
                      </span>
                      <p className="text-xs text-slate-300 leading-relaxed">
                        {ritual.objective}
                      </p>
                    </div>
                  </div>

                  {ritual.dayOfWeek && (
                    <div className="mt-4 pt-3 border-t border-[#1f2333] flex items-center justify-between text-xs text-slate-400">
                      <span>Momento sugerido</span>
                      <span className="font-semibold text-teal-400">
                        {ritual.dayOfWeek}
                      </span>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TAB 2: DECISÕES EM ABERTO */}
      {activeTab === "decisions" && (
        <div className="space-y-4">
          {/* Status filters */}
          <div className="flex flex-wrap items-center gap-2">
            <button
              onClick={() => setStatusFilter("ALL")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                statusFilter === "ALL"
                  ? "bg-indigo-600 text-white font-bold shadow-md shadow-indigo-950/40"
                  : "bg-[#151722] border border-[#232738] text-slate-400 hover:text-white"
              }`}
            >
              Todas ({decisions.length})
            </button>
            <button
              onClick={() => setStatusFilter("OPEN")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                statusFilter === "OPEN"
                  ? "bg-amber-600 text-white font-bold shadow-md shadow-amber-950/40"
                  : "bg-amber-500/10 border border-amber-500/30 text-amber-400 hover:bg-amber-500/20"
              }`}
            >
              Abertas ({openCount})
            </button>
            <button
              onClick={() => setStatusFilter("IN_DISCUSSION")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                statusFilter === "IN_DISCUSSION"
                  ? "bg-blue-600 text-white font-bold shadow-md shadow-blue-950/40"
                  : "bg-blue-500/10 border border-blue-500/30 text-blue-400 hover:bg-blue-500/20"
              }`}
            >
              Em Discussão ({discussionCount})
            </button>
            <button
              onClick={() => setStatusFilter("RESOLVED")}
              className={`px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-colors ${
                statusFilter === "RESOLVED"
                  ? "bg-emerald-600 text-white font-bold shadow-md shadow-emerald-950/40"
                  : "bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 hover:bg-emerald-500/20"
              }`}
            >
              Resolvidas ({resolvedCount})
            </button>
          </div>

          <div className="space-y-3">
            {filteredDecisions.length === 0 ? (
              <div className="p-8 text-center rounded-2xl border border-dashed border-[#232738] bg-[#151722]/50 text-slate-500 text-xs">
                Nenhuma decisão encontrada neste filtro.
              </div>
            ) : (
              filteredDecisions.map((decision, idx) => {
                const isResolved = decision.status === "RESOLVED";
                const isDiscussion = decision.status === "IN_DISCUSSION";

                return (
                  <div
                    key={decision.id || idx}
                    className={`rounded-2xl border p-4 sm:p-5 transition-all ${
                      isResolved
                        ? "bg-[#151722]/60 border-[#232738] opacity-75"
                        : "bg-[#151722] border-[#232738] hover:border-[#38415d] hover:bg-[#191c2a] shadow-sm"
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between gap-3">
                      <div className="space-y-1.5 max-w-3xl">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span
                            className={`px-2.5 py-0.5 rounded-full text-xs font-semibold border ${
                              isResolved
                                ? "bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
                                : isDiscussion
                                ? "bg-blue-500/20 text-blue-300 border-blue-500/30"
                                : "bg-amber-500/20 text-amber-300 border-amber-500/30"
                            }`}
                          >
                            {isResolved ? "Resolvida" : isDiscussion ? "Em Discussão" : "Pendente"}
                          </span>

                          {decision.assignee && (
                            <span className="text-xs px-2 py-0.5 rounded-md bg-[#111218] border border-[#232738] text-slate-300 font-medium">
                              Líder: {decision.assignee}
                            </span>
                          )}
                        </div>

                        <h3
                          className={`text-base font-semibold ${
                            isResolved
                              ? "text-slate-400 line-through"
                              : "text-white"
                          }`}
                        >
                          {decision.title}
                        </h3>

                        {decision.description && (
                          <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">
                            {decision.description}
                          </p>
                        )}

                        {decision.resolutionNotes && (
                          <div className="mt-3 p-3 rounded-xl bg-emerald-950/20 border border-emerald-900/50 text-xs sm:text-sm text-emerald-300">
                            <span className="font-semibold block mb-0.5 text-emerald-200">Definição formal registrada:</span>
                            {decision.resolutionNotes}
                          </div>
                        )}
                      </div>

                      <div className="sm:self-center shrink-0">
                        <button
                          onClick={() => handleOpenEdit(decision)}
                          className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border border-[#232738] bg-[#111218] hover:bg-[#191c2a] hover:border-indigo-500 text-slate-200 transition-colors"
                        >
                          <Edit2 className="w-3.5 h-3.5 text-indigo-400" />
                          <span>Atualizar Status</span>
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* Modal de Atualização de Decisão */}
      {editingDecision && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-lg rounded-2xl bg-[#151722] border border-[#232738] shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#232738]">
              <h2 className="text-lg font-bold text-white flex items-center gap-2">
                <HelpCircle className="w-5 h-5 text-indigo-400" />
                Atualizar Ponto de Decisão
              </h2>
              <button
                onClick={() => setEditingDecision(null)}
                className="text-slate-400 hover:text-white p-1 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveDecision} className="space-y-4">
              <div>
                <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider block mb-1">
                  Decisão
                </span>
                <p className="text-sm font-semibold text-white">
                  {editingDecision.title}
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Status Atual
                  </label>
                  <select
                    value={editStatus}
                    onChange={(e) => setEditStatus(e.target.value as any)}
                    className="w-full rounded-xl border border-[#232738] bg-[#111218] px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  >
                    <option value="OPEN">Pendente (Aberta)</option>
                    <option value="IN_DISCUSSION">Em Discussão</option>
                    <option value="RESOLVED">Resolvida & Validada</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-medium text-slate-400 mb-1">
                    Responsável / Líder
                  </label>
                  <input
                    type="text"
                    value={editAssignee}
                    onChange={(e) => setEditAssignee(e.target.value)}
                    placeholder="Ex: Matheus, Anelise, A+M"
                    className="w-full rounded-xl border border-[#232738] bg-[#111218] px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-400 mb-1">
                  Resolução / Notas da Decisão (se alinhado)
                </label>
                <textarea
                  rows={4}
                  value={editNotes}
                  onChange={(e) => setEditNotes(e.target.value)}
                  placeholder="Escreva a decisão tomada em reunião (ex: acordado 2 reuniões mensais quinzenais nos contratos a partir de Nov/2026)..."
                  className="w-full rounded-xl border border-[#232738] bg-[#111218] px-3 py-2 text-sm text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#232738]">
                <button
                  type="button"
                  onClick={() => setEditingDecision(null)}
                  className="px-4 py-2 text-sm font-medium text-slate-400 hover:text-white rounded-xl transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isSaving}
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 rounded-xl shadow-md disabled:opacity-50 transition-colors"
                >
                  <Check className="w-4 h-4" />
                  <span>{isSaving ? "Salvando..." : "Salvar Decisão"}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
