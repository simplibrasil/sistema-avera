"use client";

import { useState } from "react";
import {
  Kanban,
  Filter,
  Calendar,
  User,
  AlertTriangle,
  CheckCircle2,
  Clock,
  ArrowRight,
  MoreVertical,
} from "lucide-react";
import { formatDateBR } from "@/lib/date-utils";
import { toggleTaskStatus } from "@/app/actions/task-actions";
import { useRouter } from "next/navigation";

type Task = {
  id: string;
  title: string;
  order: number;
  status: "TODO" | "IN_PROGRESS" | "WAITING_CLIENT" | "IN_REVIEW" | "DONE";
  priority: string;
  dueDate: Date | null;
  deliverable: string | null;
  isClientStep: boolean;
  isThirdParty: boolean;
  assignee: { id: string; name: string } | null;
  project: {
    id: string;
    name: string;
    client: { id: string; name: string };
    service: {
      id: string;
      name: string;
      area: { id: string; name: string; color: string };
    };
  };
};

type FilterOption = { id: string; name: string };

type KanbanBoardProps = {
  tasks: Task[];
  members: FilterOption[];
  areas: (FilterOption & { color: string })[];
  clients: FilterOption[];
  services: FilterOption[];
};

const COLUMNS: {
  id: "TODO" | "IN_PROGRESS" | "WAITING_CLIENT" | "IN_REVIEW" | "DONE";
  label: string;
  badgeClass: string;
  columnClass: string;
}[] = [
  {
    id: "TODO",
    label: "A Fazer",
    badgeClass: "bg-[#232738] text-slate-300 border border-[#2e344a]",
    columnClass: "border-[#232738] bg-[#151722]/70",
  },
  {
    id: "IN_PROGRESS",
    label: "Em Andamento",
    badgeClass: "bg-blue-500/20 text-blue-400 border border-blue-500/30",
    columnClass: "border-blue-900/40 bg-[#10192e]/60",
  },
  {
    id: "WAITING_CLIENT",
    label: "Aguardando Cliente",
    badgeClass: "bg-amber-500/20 text-amber-400 border border-amber-500/30",
    columnClass: "border-amber-900/40 bg-[#221a10]/60",
  },
  {
    id: "IN_REVIEW",
    label: "Em Revisão",
    badgeClass: "bg-purple-500/20 text-purple-400 border border-purple-500/30",
    columnClass: "border-purple-900/40 bg-[#1d122e]/60",
  },
  {
    id: "DONE",
    label: "Concluído",
    badgeClass: "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30",
    columnClass: "border-emerald-900/40 bg-[#0f2119]/60",
  },
];

export function KanbanBoard({
  tasks,
  members,
  areas,
  clients,
  services,
}: KanbanBoardProps) {
  const router = useRouter();

  // Filtros
  const [selectedMember, setSelectedMember] = useState<string>("all");
  const [selectedArea, setSelectedArea] = useState<string>("all");
  const [selectedClient, setSelectedClient] = useState<string>("all");
  const [selectedService, setSelectedService] = useState<string>("all");
  const [updatingTaskId, setUpdatingTaskId] = useState<string | null>(null);

  // Aplicação dos filtros
  const filteredTasks = tasks.filter((t) => {
    if (selectedMember !== "all" && t.assignee?.id !== selectedMember) return false;
    if (selectedArea !== "all" && t.project.service.area.id !== selectedArea) return false;
    if (selectedClient !== "all" && t.project.client.id !== selectedClient) return false;
    if (selectedService !== "all" && t.project.service.id !== selectedService) return false;
    return true;
  });

  const handleStatusChange = async (taskId: string, newStatus: any) => {
    setUpdatingTaskId(taskId);
    await toggleTaskStatus(taskId, newStatus);
    setUpdatingTaskId(null);
    router.refresh();
  };

  const now = new Date();
  const todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());

  return (
    <div className="space-y-6">
      {/* Header com Filtros */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#232738]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md">
              <Kanban className="w-4 h-4" />
            </div>
            Quadro Operacional (Kanban)
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Arraste ou troque o status das tarefas por pessoa, área, cliente e serviço.
          </p>
        </div>

        {/* Barra de Filtros */}
        <div className="flex flex-wrap items-center gap-2">
          {/* Filtro Membro */}
          <select
            value={selectedMember}
            onChange={(e) => setSelectedMember(e.target.value)}
            className="text-xs rounded-xl border border-[#232738] bg-[#111218] p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 transition"
          >
            <option value="all">Todos os Responsáveis</option>
            {members.map((m) => (
              <option key={m.id} value={m.id}>
                {m.name}
              </option>
            ))}
          </select>

          {/* Filtro Área */}
          <select
            value={selectedArea}
            onChange={(e) => setSelectedArea(e.target.value)}
            className="text-xs rounded-xl border border-[#232738] bg-[#111218] p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 transition"
          >
            <option value="all">Todas as Áreas</option>
            {areas.map((a) => (
              <option key={a.id} value={a.id}>
                {a.name}
              </option>
            ))}
          </select>

          {/* Filtro Cliente */}
          <select
            value={selectedClient}
            onChange={(e) => setSelectedClient(e.target.value)}
            className="text-xs rounded-xl border border-[#232738] bg-[#111218] p-2.5 text-slate-200 focus:outline-none focus:border-indigo-500 transition"
          >
            <option value="all">Todos os Artistas</option>
            {clients.map((c) => (
              <option key={c.id} value={c.id}>
                {c.name}
              </option>
            ))}
          </select>

          {/* Limpar Filtros */}
          {(selectedMember !== "all" ||
            selectedArea !== "all" ||
            selectedClient !== "all" ||
            selectedService !== "all") && (
            <button
              onClick={() => {
                setSelectedMember("all");
                setSelectedArea("all");
                setSelectedClient("all");
                setSelectedService("all");
              }}
              className="text-xs text-indigo-400 font-semibold hover:underline px-2"
            >
              Limpar
            </button>
          )}
        </div>
      </div>

      {/* Grade de Colunas Kanban */}
      <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 items-start overflow-x-auto pb-4">
        {COLUMNS.map((col) => {
          const colTasks = filteredTasks.filter((t) => t.status === col.id);

          return (
            <div
              key={col.id}
              className={`rounded-2xl border p-3.5 flex flex-col max-h-[82vh] backdrop-blur-sm ${col.columnClass}`}
            >
              {/* Header da Coluna */}
              <div className="flex items-center justify-between mb-3 px-1">
                <span className="text-xs font-bold uppercase tracking-wider text-slate-200">
                  {col.label}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-full text-[11px] font-bold shadow-sm ${col.badgeClass}`}
                >
                  {colTasks.length}
                </span>
              </div>

              {/* Lista de Cartões da Coluna */}
              <div className="flex-1 overflow-y-auto space-y-2.5 pr-0.5 custom-scrollbar">
                {colTasks.length === 0 ? (
                  <div className="p-6 text-center rounded-xl border border-dashed border-[#232738] text-xs text-slate-500">
                    Sem tarefas nesta etapa
                  </div>
                ) : (
                  colTasks.map((task) => {
                    const isOverdue =
                      task.status !== "DONE" &&
                      task.dueDate &&
                      new Date(task.dueDate) < todayMidnight;

                    return (
                      <div
                        key={task.id}
                        className="p-3.5 rounded-xl bg-[#151722] border border-[#232738] hover:border-[#38415d] hover:bg-[#191c2a] shadow-sm hover:shadow-md transition-all space-y-2.5 group"
                      >
                        {/* Topo do Cartão: Área e Cliente */}
                        <div className="flex items-center justify-between text-[11px]">
                          <span
                            className="px-2 py-0.5 rounded-md text-[10px] font-bold text-white shrink-0 shadow-sm"
                            style={{ backgroundColor: task.project.service.area.color }}
                          >
                            {task.project.service.area.name}
                          </span>
                          <span className="font-semibold text-slate-300 truncate max-w-[110px]">
                            {task.project.client.name}
                          </span>
                        </div>

                        {/* Título da Tarefa */}
                        <p className="text-xs font-semibold text-white line-clamp-2 leading-snug group-hover:text-indigo-300 transition-colors">
                          <span className="text-slate-500 font-mono mr-1">#{task.order}</span>
                          {task.title}
                        </p>

                        {/* Entregável Verificável */}
                        {task.deliverable && (
                          <div className="p-1.5 rounded-lg bg-[#111218] border border-[#1f2333] text-[10px] text-slate-400 line-clamp-2">
                            <strong className="text-teal-400">Entrega:</strong> {task.deliverable}
                          </div>
                        )}

                        {/* Rodapé do Cartão */}
                        <div className="pt-2 border-t border-[#1f2333] flex items-center justify-between text-[11px]">
                          {/* Responsável */}
                          <span className="flex items-center gap-1.5 text-slate-400 font-medium truncate max-w-[120px]">
                            <User className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            <span className="truncate">
                              {task.assignee?.name || (task.isThirdParty ? "Terceiro" : "Sem resp.")}
                            </span>
                          </span>

                          {/* Prazo */}
                          <span
                            className={`flex items-center gap-1 font-semibold text-[10px] ${
                              isOverdue
                                ? "text-rose-400 bg-rose-500/10 px-1.5 py-0.5 rounded border border-rose-500/20"
                                : "text-slate-400"
                            }`}
                          >
                            <Calendar className="w-3 h-3 text-slate-500" />
                            {formatDateBR(task.dueDate)}
                          </span>
                        </div>

                        {/* Menu de Troca Rápida de Coluna */}
                        <div className="pt-1 flex items-center justify-end">
                          <select
                            value={task.status}
                            onChange={(e) => handleStatusChange(task.id, e.target.value)}
                            disabled={updatingTaskId === task.id}
                            className="text-[10px] font-semibold rounded-lg border border-[#232738] bg-[#111218] px-2 py-1 text-slate-300 hover:border-indigo-500 focus:outline-none transition cursor-pointer"
                          >
                            <option value="TODO">Mover: A Fazer</option>
                            <option value="IN_PROGRESS">Mover: Em Andamento</option>
                            <option value="WAITING_CLIENT">Mover: Aguardando Cliente</option>
                            <option value="IN_REVIEW">Mover: Em Revisão</option>
                            <option value="DONE">Mover: Concluído</option>
                          </select>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
