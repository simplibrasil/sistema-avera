"use client";

import { useState } from "react";
import {
  CheckCircle2,
  Circle,
  Clock,
  AlertTriangle,
  Calendar,
  User,
  CheckSquare,
  Sparkles,
  ChevronRight,
  Briefcase,
  Layers,
  Music,
  TrendingUp,
  Share2,
  Video,
  Palette,
  Folder,
  MessageCircle,
  MoreVertical,
  ArrowUpRight,
} from "lucide-react";
import { formatDateBR } from "@/lib/date-utils";
import { toggleTaskStatus } from "@/app/actions/task-actions";
import { useRouter } from "next/navigation";
import Link from "next/link";

type TaskItem = {
  id: string;
  title: string;
  description: string | null;
  status: "TODO" | "IN_PROGRESS" | "WAITING_CLIENT" | "IN_REVIEW" | "DONE";
  priority: string;
  order: number;
  dueDate: Date | null;
  deliverable: string | null;
  isClientStep: boolean;
  isThirdParty: boolean;
  assignee: { id: string; name: string } | null;
  project: {
    id: string;
    name: string;
    client: { id: string; name: string };
    service: {
      id: string;
      name: string;
      area: { id: string; name: string; color: string };
    };
  };
};

type MyTasksViewProps = {
  tasks: TaskItem[];
  currentUserId: string;
  currentUserName: string;
  isAdmin: boolean;
};

export function MyTasksView({
  tasks,
  currentUserId,
  currentUserName,
  isAdmin,
}: MyTasksViewProps) {
  const router = useRouter();
  const [filterMode, setFilterMode] = useState<"mine" | "all">("mine");
  const [selectedAreaFilter, setSelectedAreaFilter] = useState<string | null>(null);
  const [updatingTaskId, setUpdatingTaskId] = useState<string | null>(null);

  // Filtra por Minhas Tarefas vs Todas
  const userFiltered = tasks.filter((t) => {
    if (filterMode === "mine") {
      return t.assignee?.id === currentUserId;
    }
    return true;
  });

  // Filtra por Área se selecionada
  const filteredTasks = selectedAreaFilter
    ? userFiltered.filter((t) => t.project.service.area.name.toLowerCase().includes(selectedAreaFilter.toLowerCase()))
    : userFiltered;

  const now = new Date();
  const todayMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const endOfWeek = new Date(todayMidnight);
  endOfWeek.setDate(todayMidnight.getDate() + (7 - todayMidnight.getDay()));

  const overdueTasks = filteredTasks.filter(
    (t) => t.status !== "DONE" && t.dueDate && new Date(t.dueDate) < todayMidnight
  );

  const todayTasks = filteredTasks.filter((t) => {
    if (t.status === "DONE" || !t.dueDate) return false;
    const d = new Date(t.dueDate);
    return (
      d.getFullYear() === todayMidnight.getFullYear() &&
      d.getMonth() === todayMidnight.getMonth() &&
      d.getDate() === todayMidnight.getDate()
    );
  });

  const thisWeekTasks = filteredTasks.filter((t) => {
    if (t.status === "DONE" || !t.dueDate) return false;
    const d = new Date(t.dueDate);
    return d > todayMidnight && d <= endOfWeek;
  });

  const upcomingTasks = filteredTasks.filter((t) => {
    if (t.status === "DONE") return false;
    if (!t.dueDate) return true;
    const d = new Date(t.dueDate);
    return d > endOfWeek;
  });

  const completedRecently = filteredTasks.filter((t) => t.status === "DONE").slice(0, 10);

  // Métricas para os cartões de progresso
  const totalTasks = filteredTasks.length || 1;
  const doneTasks = filteredTasks.filter((t) => t.status === "DONE").length;
  const onTimePercentage = Math.round(((totalTasks - overdueTasks.length) / totalTasks) * 100);

  const handleToggleDone = async (task: TaskItem) => {
    setUpdatingTaskId(task.id);
    const newStatus = task.status === "DONE" ? "TODO" : "DONE";
    await toggleTaskStatus(task.id, newStatus);
    setUpdatingTaskId(null);
    router.refresh();
  };

  const handleStatusChange = async (taskId: string, newStatus: any) => {
    setUpdatingTaskId(taskId);
    await toggleTaskStatus(taskId, newStatus);
    setUpdatingTaskId(null);
    router.refresh();
  };

  // Áreas principais com ícones (estilo Document Type da foto)
  const areaCards = [
    { name: "Música", label: "Música & Catálogo", icon: Music, color: "from-purple-600 to-indigo-600", badge: "UBC" },
    { name: "Tráfego", label: "Tráfego Pago", icon: TrendingUp, color: "from-blue-600 to-cyan-500", badge: "Meta" },
    { name: "Redes", label: "Redes & Conteúdo", icon: Share2, color: "from-pink-600 to-rose-500", badge: "Insta" },
    { name: "Audiovisual", label: "Audiovisual", icon: Video, color: "from-amber-600 to-orange-500", badge: "Reels" },
    { name: "Branding", label: "Branding", icon: Palette, color: "from-indigo-600 to-violet-600", badge: "Marca" },
  ];

  // Lista dos clientes do WhatsApp da Avera (estilo Recent Folders da foto)
  const clientFolders = [
    { name: "Santta", owner: "Anelise", service: "Tráfego + Redes" },
    { name: "Theaga", owner: "Matheus", service: "Lançamento Single" },
    { name: "Teuz", owner: "Anelise", service: "Conteúdo Mensal" },
    { name: "NLE Kira", owner: "Matheus", service: "Tráfego Pago" },
    { name: "Drik Barbosa", owner: "Anelise", service: "Distribuição" },
  ];

  return (
    <div className="space-y-8 animate-in fade-in duration-300">
      {/* Top Header & Modo Minhas vs Todas */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-2">
        <div>
          <h1 className="text-2xl font-black tracking-tight text-white flex items-center gap-2.5">
            <span>Visão Operacional • {currentUserName}</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Painel diário da equipe com prazos automáticos, status e prioridades.
          </p>
        </div>

        {isAdmin && (
          <div className="flex items-center p-1 rounded-xl bg-[#161822] border border-[#232738] self-start sm:self-auto">
            <button
              onClick={() => setFilterMode("mine")}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                filterMode === "mine"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Minhas ({tasks.filter((t) => t.assignee?.id === currentUserId && t.status !== "DONE").length})
            </button>
            <button
              onClick={() => setFilterMode("all")}
              className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                filterMode === "all"
                  ? "bg-indigo-600 text-white shadow-md shadow-indigo-600/30"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Toda a Equipe ({tasks.filter((t) => t.status !== "DONE").length})
            </button>
          </div>
        )}
      </div>

      {/* Grid Principal: Coluna da Esquerda (Dashboard estilo foto) + Coluna da Direita (Painel Lateral) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* COLUNA ESQUERDA (8 colunas) */}
        <div className="lg:col-span-8 space-y-7">
          {/* SEÇÃO 1: Áreas Operacionais (estilo "Document Type" da foto com ícones em caixas arredondadas) */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
                <Layers className="w-3.5 h-3.5" />
                Áreas Operacionais
              </span>
              {selectedAreaFilter && (
                <button
                  onClick={() => setSelectedAreaFilter(null)}
                  className="text-[11px] text-slate-400 hover:text-white underline"
                >
                  Limpar filtro
                </button>
              )}
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
              {areaCards.map((area) => {
                const Icon = area.icon;
                const isSelected = selectedAreaFilter === area.name;

                return (
                  <button
                    key={area.name}
                    onClick={() =>
                      setSelectedAreaFilter(isSelected ? null : area.name)
                    }
                    className={`p-3.5 rounded-2xl border transition-all flex flex-col items-center justify-center text-center gap-2 group ${
                      isSelected
                        ? "bg-[#1c2235] border-indigo-500 ring-2 ring-indigo-500/30 shadow-lg"
                        : "bg-[#151722] border-[#232738] hover:border-[#38415d] hover:bg-[#191c2a]"
                    }`}
                  >
                    <div
                      className={`w-10 h-10 rounded-xl bg-gradient-to-tr ${area.color} flex items-center justify-center text-white shadow-md group-hover:scale-105 transition-transform`}
                    >
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <span className="text-xs font-semibold text-slate-200 line-clamp-1">
                      {area.label}
                    </span>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {area.badge}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* SEÇÃO 2: Projetos & Andamento (estilo "External Storage" da foto com cartões de gradiente escuro e barras de progresso neon) */}
          <div className="space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Processos em Execução
            </span>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Card 1: Tráfego Pago */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#1b2234] via-[#161a26] to-[#12141d] border border-[#262e44] shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-blue-500/20 border border-blue-500/30 flex items-center justify-center text-blue-400">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Gestão de Tráfego</h4>
                      <p className="text-[11px] text-slate-400">Meta Ads & Google Ads</p>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 font-bold">
                    Mensal
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="w-full h-2 rounded-full bg-[#0e1017] overflow-hidden p-[1px]">
                    <div className="h-full rounded-full bg-gradient-to-r from-blue-500 to-cyan-400 w-[75%]" />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>9 de 12 tarefas</span>
                    <span className="font-semibold text-slate-300">75% Concluído</span>
                  </div>
                </div>
              </div>

              {/* Card 2: Lançamento Single */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#231e34] via-[#191726] to-[#12141d] border border-[#342a4a] shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                      <Music className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Planejamento de Lançamento</h4>
                      <p className="text-[11px] text-slate-400">Cronograma Reverso</p>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20 font-bold">
                    13 passos
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="w-full h-2 rounded-full bg-[#0e1017] overflow-hidden p-[1px]">
                    <div className="h-full rounded-full bg-gradient-to-r from-purple-500 to-pink-500 w-[60%]" />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>8 de 13 tarefas</span>
                    <span className="font-semibold text-slate-300">60% Concluído</span>
                  </div>
                </div>
              </div>

              {/* Card 3: Produção de Conteúdo */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#2a221a] via-[#1c1817] to-[#12141d] border border-[#443322] shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-amber-500/20 border border-amber-500/30 flex items-center justify-center text-amber-400">
                      <Video className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Produção de Conteúdo</h4>
                      <p className="text-[11px] text-slate-400">Gravação de 6 Reels</p>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20 font-bold">
                    Audiovisual
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="w-full h-2 rounded-full bg-[#0e1017] overflow-hidden p-[1px]">
                    <div className="h-full rounded-full bg-gradient-to-r from-amber-500 to-orange-400 w-[85%]" />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>Gravação alinhada</span>
                    <span className="font-semibold text-slate-300">85% Concluído</span>
                  </div>
                </div>
              </div>

              {/* Card 4: Playlists & Curadoria */}
              <div className="p-5 rounded-2xl bg-gradient-to-br from-[#162726] via-[#141d1e] to-[#12141d] border border-[#213a38] shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 rounded-lg bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                      <Share2 className="w-4 h-4" />
                    </div>
                    <div>
                      <h4 className="text-sm font-bold text-white">Curadoria de Playlists</h4>
                      <p className="text-[11px] text-slate-400">Spotify 30 dias corridos</p>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-bold">
                    Spotify
                  </span>
                </div>

                <div className="space-y-1.5">
                  <div className="w-full h-2 rounded-full bg-[#0e1017] overflow-hidden p-[1px]">
                    <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-teal-400 w-[50%]" />
                  </div>
                  <div className="flex justify-between text-[11px] text-slate-400">
                    <span>Músicas posicionadas</span>
                    <span className="font-semibold text-slate-300">50% Concluído</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* SEÇÃO 3: Lista de Tarefas da Equipe (Estilo Clean Minimalista) */}
          <div className="space-y-4 pt-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
                <CheckSquare className="w-3.5 h-3.5" />
                Tarefas Operacionais Ativas
              </span>
              <span className="text-xs text-slate-400">
                Total: <strong className="text-white">{filteredTasks.length}</strong>
              </span>
            </div>

            {/* Atrasadas */}
            {overdueTasks.length > 0 && (
              <TaskGroupModern
                title="Atrasadas (Atenção Imediata)"
                colorTag="border-rose-500/40 bg-rose-500/5"
                badgeStyle="bg-rose-500/20 text-rose-300 border-rose-500/30"
                tasks={overdueTasks}
                updatingTaskId={updatingTaskId}
                onToggleDone={handleToggleDone}
                onStatusChange={handleStatusChange}
                isOverdue
              />
            )}

            {/* Para Hoje */}
            {todayTasks.length > 0 && (
              <TaskGroupModern
                title="Para Hoje"
                colorTag="border-amber-500/40 bg-amber-500/5"
                badgeStyle="bg-amber-500/20 text-amber-300 border-amber-500/30"
                tasks={todayTasks}
                updatingTaskId={updatingTaskId}
                onToggleDone={handleToggleDone}
                onStatusChange={handleStatusChange}
              />
            )}

            {/* Esta Semana */}
            {thisWeekTasks.length > 0 && (
              <TaskGroupModern
                title="Esta Semana"
                colorTag="border-indigo-500/40 bg-indigo-500/5"
                badgeStyle="bg-indigo-500/20 text-indigo-300 border-indigo-500/30"
                tasks={thisWeekTasks}
                updatingTaskId={updatingTaskId}
                onToggleDone={handleToggleDone}
                onStatusChange={handleStatusChange}
              />
            )}

            {/* Próximas */}
            <TaskGroupModern
              title="Próximas & Rotinas de Acompanhamento"
              colorTag="border-slate-800 bg-[#151722]"
              badgeStyle="bg-slate-800 text-slate-300 border-slate-700"
              tasks={upcomingTasks}
              updatingTaskId={updatingTaskId}
              onToggleDone={handleToggleDone}
              onStatusChange={handleStatusChange}
            />

            {/* Concluídas Recentemente */}
            {completedRecently.length > 0 && (
              <TaskGroupModern
                title="Concluídas Recentemente"
                colorTag="border-emerald-500/30 bg-emerald-500/5"
                badgeStyle="bg-emerald-500/20 text-emerald-300 border-emerald-500/30"
                tasks={completedRecently}
                updatingTaskId={updatingTaskId}
                onToggleDone={handleToggleDone}
                onStatusChange={handleStatusChange}
              />
            )}
          </div>
        </div>

        {/* COLUNA DIREITA (4 colunas — estilo painel lateral da foto de referência) */}
        <div className="lg:col-span-4 space-y-6">
          {/* WIDGET 1: Card de Capacidade (estilo "Internal Storage" com donut chart alaranjado da foto!) */}
          <div className="p-5 rounded-2xl bg-gradient-to-br from-[#2b1f13] via-[#1f1915] to-[#141217] border border-[#44301e] shadow-xl space-y-4">
            <span className="text-xs font-bold uppercase tracking-wider text-amber-400 block">
              Performance de Entregas
            </span>

            <div className="flex items-center gap-4">
              {/* Donut Ring Progress SVG (igual ao 80% do widget da foto) */}
              <div className="relative w-16 h-16 shrink-0 flex items-center justify-center">
                <svg className="w-16 h-16 -rotate-90">
                  <circle
                    cx="32"
                    cy="32"
                    r="26"
                    className="stroke-[#191515]"
                    strokeWidth="6"
                    fill="none"
                  />
                  <circle
                    cx="32"
                    cy="32"
                    r="26"
                    className="stroke-amber-500"
                    strokeWidth="6"
                    strokeDasharray={163.3}
                    strokeDashoffset={163.3 - (163.3 * onTimePercentage) / 100}
                    strokeLinecap="round"
                    fill="none"
                  />
                </svg>
                <span className="absolute text-xs font-black text-amber-400">
                  {onTimePercentage}%
                </span>
              </div>

              <div className="space-y-0.5">
                <h4 className="text-sm font-bold text-white">Tarefas no Prazo</h4>
                <p className="text-xs text-slate-400">
                  {doneTasks} concluídas • {overdueTasks.length} atrasadas
                </p>
                <span className="text-[10px] text-amber-400 font-medium">
                  {onTimePercentage >= 80 ? "Ritmo excelente" : "Atenção a prazos"}
                </span>
              </div>
            </div>
          </div>

          {/* WIDGET 2: Clientes no WhatsApp (estilo "Recent Folders" da foto com pastas amarelas) */}
          <div className="p-5 rounded-2xl bg-[#151722] border border-[#232738] shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
                <Folder className="w-3.5 h-3.5 text-amber-400" />
                Clientes no WhatsApp
              </span>
              <Link href="/clientes" className="text-[11px] text-slate-400 hover:text-white flex items-center gap-0.5">
                Ver todos <ArrowUpRight className="w-3 h-3" />
              </Link>
            </div>

            <div className="space-y-2">
              {clientFolders.map((c) => (
                <div
                  key={c.name}
                  className="flex items-center justify-between p-2.5 rounded-xl bg-[#1a1d29] hover:bg-[#202434] transition-colors border border-white/5"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-amber-500/15 flex items-center justify-center text-amber-400">
                      <Folder className="w-4 h-4 fill-amber-400/20" />
                    </div>
                    <div>
                      <h5 className="text-xs font-bold text-white">{c.name}</h5>
                      <span className="text-[10px] text-slate-400">{c.service}</span>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded font-semibold bg-slate-800 text-slate-300">
                    {c.owner}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* WIDGET 3: Próximas Entregas (estilo "Recent Files" da foto com lista e badges coloridos) */}
          <div className="p-5 rounded-2xl bg-[#151722] border border-[#232738] shadow-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider text-teal-400 flex items-center gap-1.5">
                <Calendar className="w-3.5 h-3.5 text-indigo-400" />
                Próximas Entregas
              </span>
              <span className="text-[11px] text-slate-500">Agenda</span>
            </div>

            <div className="space-y-2 divide-y divide-[#1f2334]/80">
              {filteredTasks.slice(0, 5).map((t) => (
                <div key={t.id} className="pt-2.5 first:pt-0 flex items-center justify-between gap-2">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div
                      className="w-2.5 h-2.5 rounded-full shrink-0"
                      style={{ backgroundColor: t.project.service.area.color }}
                    />
                    <div className="truncate">
                      <p className="text-xs font-medium text-slate-200 truncate">
                        {t.title}
                      </p>
                      <p className="text-[10px] text-slate-500 truncate">
                        {t.project.client.name}
                      </p>
                    </div>
                  </div>
                  <span className="text-[11px] font-mono text-slate-400 shrink-0">
                    {formatDateBR(t.dueDate)}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Componente para grupo de tarefas no visual dark minimalista
function TaskGroupModern({
  title,
  colorTag,
  badgeStyle,
  tasks,
  updatingTaskId,
  onToggleDone,
  onStatusChange,
  isOverdue = false,
}: {
  title: string;
  colorTag: string;
  badgeStyle: string;
  tasks: TaskItem[];
  updatingTaskId: string | null;
  onToggleDone: (task: TaskItem) => void;
  onStatusChange: (id: string, s: any) => void;
  isOverdue?: boolean;
}) {
  if (tasks.length === 0) return null;

  return (
    <div className="space-y-2.5">
      <div className="flex items-center gap-2 px-1">
        <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300">
          {title}
        </h3>
        <span className={`px-2 py-0.5 rounded-full text-[10px] font-mono font-bold border ${badgeStyle}`}>
          {tasks.length}
        </span>
      </div>

      <div className={`rounded-2xl border ${colorTag} overflow-hidden divide-y divide-white/5 shadow-lg`}>
        {tasks.map((task) => {
          const isDone = task.status === "DONE";
          const isClient = task.isClientStep;

          return (
            <div
              key={task.id}
              className={`p-3.5 sm:px-4 flex items-start gap-3.5 transition-all hover:bg-white/[0.03] ${
                isDone ? "opacity-50" : ""
              }`}
            >
              <button
                type="button"
                onClick={() => onToggleDone(task)}
                disabled={updatingTaskId === task.id}
                className="mt-0.5 text-slate-500 hover:text-indigo-400 transition shrink-0"
              >
                {isDone ? (
                  <CheckCircle2 className="w-5 h-5 text-emerald-400 fill-emerald-500/20" />
                ) : (
                  <Circle className="w-5 h-5" />
                )}
              </button>

              <div className="flex-1 min-w-0">
                <div className="flex flex-wrap items-center gap-2 mb-1">
                  <span
                    className="w-2 h-2 rounded-full shrink-0"
                    style={{ backgroundColor: task.project.service.area.color }}
                  />
                  <span className="font-bold text-xs text-white">
                    {task.project.client.name}
                  </span>
                  <span className="text-[11px] text-slate-400 truncate">
                    • {task.project.service.name}
                  </span>

                  {isClient && (
                    <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/10 text-amber-300 border border-amber-500/30">
                      Com Cliente
                    </span>
                  )}
                </div>

                <p
                  className={`text-xs sm:text-sm font-semibold ${
                    isDone ? "line-through text-slate-500" : "text-slate-100"
                  }`}
                >
                  #{task.order} {task.title}
                </p>

                {task.deliverable && (
                  <p className="text-[11px] text-slate-400 mt-1">
                    <span className="text-slate-500 font-medium">Entrega:</span>{" "}
                    {task.deliverable}
                  </p>
                )}
              </div>

              <div className="flex flex-col items-end gap-1.5 shrink-0 text-right">
                <span
                  className={`text-xs font-semibold flex items-center gap-1 font-mono ${
                    isOverdue && !isDone
                      ? "text-rose-400 font-bold"
                      : "text-slate-400"
                  }`}
                >
                  <Calendar className="w-3 h-3 text-slate-500" />
                  {formatDateBR(task.dueDate)}
                </span>

                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-slate-400 flex items-center gap-1">
                    <User className="w-3 h-3 text-slate-500" />
                    {task.assignee?.name || (task.isThirdParty ? "Terceirizado" : "Sem dono")}
                  </span>

                  <select
                    value={task.status}
                    onChange={(e) => onStatusChange(task.id, e.target.value)}
                    className="text-[10px] font-bold rounded-lg border border-[#272d40] bg-[#1a1d29] px-2 py-0.5 text-slate-200 focus:outline-none focus:ring-1 focus:ring-indigo-500"
                  >
                    <option value="TODO">A Fazer</option>
                    <option value="IN_PROGRESS">Em Andamento</option>
                    <option value="WAITING_CLIENT">Aguardando Cliente</option>
                    <option value="IN_REVIEW">Em Revisão</option>
                    <option value="DONE">Concluído</option>
                  </select>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
