"use client";

import { useState } from "react";
import {
  BarChart3,
  AlertTriangle,
  CheckCircle2,
  Calendar,
  Layers,
  ArrowRight,
  TrendingUp,
  Flame,
  ShieldCheck,
  User,
} from "lucide-react";
import { formatDateBR } from "@/lib/date-utils";

type MemberWorkload = {
  member: {
    id: string;
    name: string;
    email: string;
    systemRole: string;
    roles: string[];
  };
  totalOpenTasks: number;
  overdueTasks: number;
  todayTasks: number;
  thisWeekTasks: number;
  nextWeeksTasks: number;
  isOverloaded: boolean;
  overloadReason?: string;
  tasksByArea: {
    areaId: string;
    areaName: string;
    areaColor: string;
    count: number;
  }[];
  recentTasks: {
    id: string;
    title: string;
    clientName: string;
    serviceName: string;
    dueDate: Date | null;
    status: string;
    isOverdue: boolean;
  }[];
};

type WorkloadViewProps = {
  workloads: MemberWorkload[];
  areas: { id: string; name: string; color: string }[];
};

export function WorkloadView({ workloads, areas }: WorkloadViewProps) {
  const [selectedAreaFilter, setSelectedAreaFilter] = useState<string>("all");
  const [selectedMemberDetail, setSelectedMemberDetail] = useState<string | null>(null);

  // Identifica membros sobrecarregados
  const overloadedMembers = workloads.filter((w) => w.isOverloaded);

  return (
    <div className="space-y-6">
      {/* Header com Diagnóstico de Sobrecarga */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-[#232738]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md">
              <BarChart3 className="w-4 h-4" />
            </div>
            Carga de Trabalho da Equipe
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Enxergue sobrecarga e equilibre a distribuição de tarefas por pessoa, área e semana.
          </p>
        </div>

        {/* Indicador de Alerta Geral */}
        <div className="flex items-center gap-2">
          {overloadedMembers.length > 0 ? (
            <span className="px-3 py-1.5 rounded-xl bg-rose-500/10 border border-rose-500/30 text-rose-400 text-xs font-bold flex items-center gap-1.5 shadow-sm">
              <Flame className="w-4 h-4 text-rose-400 animate-pulse" />
              {overloadedMembers.length} {overloadedMembers.length === 1 ? "membro sobrecarregado" : "membros sobrecarregados"}
            </span>
          ) : (
            <span className="px-3 py-1.5 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-400 text-xs font-bold flex items-center gap-1.5 shadow-sm">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              Carga equilibrada na equipe
            </span>
          )}
        </div>
      </div>

      {/* 1. Alertas de Sobrecarga Ativos */}
      {overloadedMembers.length > 0 && (
        <div className="p-4 rounded-2xl bg-rose-950/20 border border-rose-900/50 space-y-2">
          <div className="flex items-center gap-2 text-rose-400 font-bold text-xs uppercase tracking-wider">
            <AlertTriangle className="w-4 h-4 text-rose-400" />
            Atenção Necessária: Pessoas com Sobrecarga ou Atrasos
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
            {overloadedMembers.map((w) => (
              <div
                key={w.member.id}
                className="p-3 rounded-xl bg-[#151722] border border-rose-900/50 flex items-center justify-between shadow-sm"
              >
                <div>
                  <p className="font-bold text-xs text-white">
                    {w.member.name}
                  </p>
                  <p className="text-[11px] text-rose-400 font-medium">
                    {w.overloadReason || "Volume excessivo de tarefas"}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-xs font-black text-rose-400">
                    {w.overdueTasks > 0 ? `${w.overdueTasks} atrasadas` : `${w.totalOpenTasks} tarefas`}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. Grade de Carga por Colaborador */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
        {workloads.map((w) => {
          return (
            <div
              key={w.member.id}
              className={`p-5 rounded-2xl bg-[#151722] border transition flex flex-col justify-between ${
                w.isOverloaded
                  ? "border-rose-500/40 shadow-lg shadow-rose-950/20"
                  : "border-[#232738] hover:border-[#38415d] hover:bg-[#191c2a]"
              }`}
            >
              <div>
                {/* Topo: Nome, Papéis e Tag de Risco */}
                <div className="flex items-start justify-between mb-4">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-indigo-500 to-violet-600 text-white font-bold text-base flex items-center justify-center shadow-md">
                      {w.member.name.charAt(0)}
                    </div>
                    <div>
                      <h3 className="font-bold text-sm text-white">
                        {w.member.name}
                      </h3>
                      <p className="text-[11px] text-slate-400">
                        {w.member.roles.length > 0 ? w.member.roles.slice(0, 2).join(", ") : "Sem papéis"}
                      </p>
                    </div>
                  </div>

                  {w.isOverloaded ? (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-500/20 text-rose-400 border border-rose-500/30 flex items-center gap-1">
                      <Flame className="w-3 h-3 text-rose-400" />
                      Sobrecarga
                    </span>
                  ) : (
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-semibold bg-[#232738] text-slate-300">
                      Normal
                    </span>
                  )}
                </div>

                {/* Métricas Semanais */}
                <div className="grid grid-cols-4 gap-2 mb-4 p-2.5 rounded-xl bg-[#111218] border border-[#232738] text-center">
                  <div>
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">Total</span>
                    <span className="text-sm font-black text-white">
                      {w.totalOpenTasks}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-rose-400 block">Atraso</span>
                    <span
                      className={`text-sm font-black ${
                        w.overdueTasks > 0 ? "text-rose-400 font-extrabold" : "text-slate-500"
                      }`}
                    >
                      {w.overdueTasks}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-amber-400 block">Hoje</span>
                    <span className="text-sm font-black text-slate-200">
                      {w.todayTasks}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-indigo-400 block">Semana</span>
                    <span className="text-sm font-black text-slate-200">
                      {w.thisWeekTasks}
                    </span>
                  </div>
                </div>

                {/* Distribuição por Área da Empresa */}
                <div className="space-y-2 mb-4">
                  <p className="text-[10px] uppercase font-bold text-slate-400 tracking-wider">
                    Volume por Área da Avera
                  </p>
                  {w.tasksByArea.length === 0 ? (
                    <p className="text-xs text-slate-500 italic">Nenhuma tarefa aberta atribuída</p>
                  ) : (
                    <div className="space-y-2">
                      {w.tasksByArea.map((area) => {
                        const pct = w.totalOpenTasks > 0 ? Math.round((area.count / w.totalOpenTasks) * 100) : 0;
                        return (
                          <div key={area.areaId} className="space-y-1">
                            <div className="flex items-center justify-between text-[11px]">
                              <span className="flex items-center gap-1.5 text-slate-300 font-medium">
                                <span
                                  className="w-2 h-2 rounded-full"
                                  style={{ backgroundColor: area.areaColor }}
                                />
                                {area.areaName}
                              </span>
                              <span className="text-slate-400 font-semibold">{area.count}</span>
                            </div>
                            <div className="w-full h-1.5 rounded-full bg-[#111218] border border-[#1f2333] overflow-hidden">
                              <div
                                className="h-full rounded-full transition-all duration-300"
                                style={{ width: `${pct}%`, backgroundColor: area.areaColor }}
                              />
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              </div>

              {/* Botão para Ver Tarefas do Colaborador */}
              <div className="pt-3 border-t border-[#232738]">
                <button
                  onClick={() =>
                    setSelectedMemberDetail(selectedMemberDetail === w.member.id ? null : w.member.id)
                  }
                  className="w-full py-2 text-xs font-semibold rounded-xl bg-[#111218] border border-[#232738] hover:border-indigo-500 hover:bg-[#191c2a] text-indigo-400 transition flex items-center justify-center gap-1.5"
                >
                  <span>{selectedMemberDetail === w.member.id ? "Ocultar Tarefas" : "Ver Próximas Tarefas"}</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* 3. Gaveta com Lista de Tarefas do Colaborador Selecionado */}
      {selectedMemberDetail && (
        <div className="p-5 rounded-2xl bg-[#151722] border border-[#232738] shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-[#232738] pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <User className="w-4 h-4 text-indigo-400" />
              Tarefas Ativas de: {workloads.find((w) => w.member.id === selectedMemberDetail)?.member.name}
            </h3>
            <button
              onClick={() => setSelectedMemberDetail(null)}
              className="text-xs text-slate-400 hover:text-white font-semibold transition"
            >
              Fechar
            </button>
          </div>

          <div className="divide-y divide-[#1f2333] max-h-72 overflow-y-auto pr-1">
            {workloads
              .find((w) => w.member.id === selectedMemberDetail)
              ?.recentTasks.map((t) => (
                <div key={t.id} className="py-2.5 flex items-center justify-between text-xs hover:bg-[#191c2a] px-2 rounded-lg transition">
                  <div>
                    <p className="font-semibold text-white">{t.title}</p>
                    <p className="text-[11px] text-slate-400">
                      {t.clientName} • {t.serviceName}
                    </p>
                  </div>
                  <div className="text-right">
                    <span
                      className={`text-xs font-bold ${
                        t.isOverdue ? "text-rose-400" : "text-slate-400"
                      }`}
                    >
                      {formatDateBR(t.dueDate)}
                    </span>
                    <p className="text-[10px] uppercase font-bold text-slate-500">{t.status}</p>
                  </div>
                </div>
              ))}
          </div>
        </div>
      )}
    </div>
  );
}
