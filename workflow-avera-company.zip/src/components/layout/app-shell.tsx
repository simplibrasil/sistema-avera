"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import {
  CheckSquare,
  Kanban,
  BarChart3,
  Users,
  FolderGit2,
  BookOpen,
  CalendarDays,
  Menu,
  X,
  LogOut,
  Layers,
  Search,
  Settings,
  ChevronDown,
  Bell,
  Sparkles,
  Briefcase,
} from "lucide-react";import { ThemeToggle } from "@/components/theme-toggle";
import { switchDevUser, logoutUser } from "@/app/actions/auth-actions";

type AppShellProps = {
  children: React.ReactNode;
  currentUser: {
    id: string;
    name: string;
    email: string;
    systemRole: "ADMIN" | "MEMBER";
    roles: { id: string; name: string }[];
  } | null;
  allMembers?: { id: string; name: string; systemRole: string }[];
  isDev?: boolean;
};

export function AppShell({
  children,
  currentUser,
  allMembers = [],
  isDev = false,
}: AppShellProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const navLinks = [
    { href: "/", label: "Minhas Tarefas", icon: CheckSquare },
    { href: "/kanban", label: "Quadro Kanban", icon: Kanban },
    { href: "/carga", label: "Painel de Carga", icon: BarChart3 },
    { href: "/areas", label: "Áreas de Atuação", icon: Layers },
    { href: "/clientes", label: "Clientes", icon: Users },
    { href: "/projetos", label: "Projetos", icon: Briefcase },
    { href: "/processos", label: "Processos", icon: BookOpen },
    { href: "/rituais", label: "Rituais & Decisões", icon: CalendarDays },
    { href: "/equipe", label: "Equipe & Papéis", icon: FolderGit2 },
  ];

  const handleSwitchUser = async (memberId: string) => {
    if (!isDev) return;
    await switchDevUser(memberId);
    setUserDropdownOpen(false);
    router.refresh();
  };

  const getInitials = (name: string) => {
    const parts = name.trim().split(" ");
    if (parts.length === 1) return parts[0].substring(0, 2).toUpperCase();
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase();
  };

  return (
    <div className="min-h-screen bg-[#0d0e14] text-slate-100 flex flex-col lg:flex-row antialiased">
      {/* SIDEBAR DESKTOP */}
      <aside className="hidden lg:flex w-64 flex-col bg-[#111218] border-r border-[#1f2333] shrink-0 sticky top-0 h-screen select-none z-30">
        {/* Brand / Logo (estilo IDMIS da foto com badge azul arredondado) */}
        <div className="h-20 flex items-center px-5 gap-3 border-b border-[#1f2333]/60">
          <div className="w-10 h-10 rounded-xl bg-white flex items-center justify-center shadow-lg shadow-black/30 shrink-0 overflow-hidden">
            <Image
              src="/avera-logo.png"
              alt="Avera Logo"
              width={32}
              height={32}
              className="object-contain"
            />
          </div>
          <div className="flex flex-col min-w-0">
            <span className="font-extrabold text-sm leading-tight tracking-wide text-white truncate">
              Workflow
            </span>
            <span className="font-extrabold text-sm leading-tight tracking-wide text-red-500 truncate">
              Avera Company
            </span>
          </div>
        </div>

        {/* Navigation Items (com indicador ativo vertical na borda esquerda igual à foto) */}
        <nav className="flex-1 py-6 px-3 space-y-1.5 overflow-y-auto">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive =
              link.href === "/"
                ? pathname === "/"
                : pathname.startsWith(link.href);

            return (
              <Link
                key={link.href}
                href={link.href}
                className={`relative flex items-center gap-3.5 px-4 py-3 rounded-xl text-sm font-medium transition-all ${
                  isActive
                    ? "text-indigo-400 bg-indigo-500/10 font-semibold"
                    : "text-slate-400 hover:text-slate-200 hover:bg-[#181a24]"
                }`}
              >
                {/* Indicador visual vertical ativo (como na foto de referência) */}
                {isActive && (
                  <span className="absolute left-0 top-2 bottom-2 w-1.5 bg-indigo-500 rounded-r-full shadow-[0_0_8px_rgba(99,102,241,0.8)]" />
                )}
                <Icon
                  className={`w-5 h-5 shrink-0 transition-colors ${
                    isActive ? "text-indigo-400" : "text-slate-400"
                  }`}
                />
                <span className="truncate">{link.label}</span>
              </Link>
            );
          })}
        </nav>

        {/* Footer do Sidebar: Configurações & Sair (estilo Settings / Log Out da foto) */}
        <div className="p-4 border-t border-[#1f2333]/80 space-y-1.5 bg-[#0f1016]">
          {isDev && (
            <div className="px-3 py-2 text-[11px] font-mono text-amber-400/90 bg-amber-500/10 rounded-lg border border-amber-500/20 mb-2 flex items-center justify-between">
              <span>MODO DEV ATIVO</span>
              <span className="w-2 h-2 rounded-full bg-amber-400 animate-pulse" />
            </div>
          )}

          <Link
            href="/equipe"
            className="flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium text-slate-400 hover:text-slate-200 hover:bg-[#181a24] transition-colors"
          >
            <Settings className="w-4 h-4 text-slate-400" />
            <span>Configurações & Equipe</span>
          </Link>

          <form action={logoutUser} className="w-full">
            <button
              type="submit"
              className="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-xs font-medium text-rose-400 hover:text-rose-300 hover:bg-rose-500/10 transition-colors"
            >
              <LogOut className="w-4 h-4 text-rose-400" />
              <span>Sair da Conta</span>
            </button>
          </form>
        </div>
      </aside>

      {/* TOPBAR MOBILE (apenas telas pequenas) */}
      <div className="lg:hidden flex items-center justify-between h-16 px-4 bg-[#111218] border-b border-[#1f2333] sticky top-0 z-40">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-white flex items-center justify-center shadow-md shrink-0 overflow-hidden">
            <Image
              src="/avera-logo.png"
              alt="Avera"
              width={24}
              height={24}
              className="object-contain"
            />
          </div>
          <span className="font-bold text-white text-base tracking-wide">
            Workflow <span className="text-red-500">Avera</span>
          </span>
        </div>

        <div className="flex items-center gap-2">
          <ThemeToggle />
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="p-2 rounded-lg bg-[#181a24] text-slate-300 hover:text-white"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* DRAWER MENU MOBILE */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex">
          <div className="w-72 bg-[#111218] h-full flex flex-col p-4 border-r border-[#1f2333] animate-in slide-in-from-left duration-200">
            <div className="flex items-center justify-between pb-4 border-b border-[#1f2333]">
              <span className="font-bold text-white text-base">Menu Avera</span>
              <button
                onClick={() => setMobileOpen(false)}
                className="p-1 rounded text-slate-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <nav className="flex-1 py-4 space-y-1 overflow-y-auto">
              {navLinks.map((link) => {
                const Icon = link.icon;
                const isActive =
                  link.href === "/"
                    ? pathname === "/"
                    : pathname.startsWith(link.href);

                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    onClick={() => setMobileOpen(false)}
                    className={`flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-medium ${
                      isActive
                        ? "text-indigo-400 bg-indigo-500/10 font-semibold"
                        : "text-slate-400 hover:text-white hover:bg-[#181a24]"
                    }`}
                  >
                    <Icon className="w-4 h-4" />
                    <span>{link.label}</span>
                  </Link>
                );
              })}
            </nav>

            <div className="pt-4 border-t border-[#1f2333]">
              <form action={logoutUser}>
                <button
                  type="submit"
                  className="w-full flex items-center gap-2 px-3 py-2 text-xs font-semibold text-rose-400 hover:bg-rose-500/10 rounded-lg"
                >
                  <LogOut className="w-4 h-4" />
                  <span>Sair</span>
                </button>
              </form>
            </div>
          </div>
          <div className="flex-1" onClick={() => setMobileOpen(false)} />
        </div>
      )}

      {/* ÁREA PRINCIPAL COM HEADER SUPERIOR */}
      <div className="flex-1 flex flex-col min-w-0 overflow-y-auto">
        {/* Top Header Bar (estilo da foto com barra de busca à esquerda e John Doe + avatar à direita) */}
        <header className="h-20 bg-[#111218]/90 backdrop-blur-md border-b border-[#1f2333] px-6 flex items-center justify-between gap-4 sticky top-0 z-20">
          {/* Barra de Pesquisa Estilizada (como "Search Files" na foto) */}
          <div className="flex-1 max-w-md hidden sm:block">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Buscar tarefas, clientes, projetos..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-[#181a24] border border-[#262b3d] rounded-xl pl-10 pr-4 py-2 text-xs sm:text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all"
              />
            </div>
          </div>

          {/* User Profile & Actions (estilo "John Doe" + foto circular da imagem de referência) */}
          <div className="flex items-center gap-4 ml-auto">
            <ThemeToggle />

            {/* Perfil do Usuário com avatar circular */}
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-3 p-1.5 rounded-xl hover:bg-[#181a24] transition-colors focus:outline-none"
              >
                <div className="text-right hidden sm:block">
                  <div className="text-sm font-semibold text-white tracking-tight">
                    {currentUser?.name || "Colaborador Avera"}
                  </div>
                  <div className="text-[11px] text-slate-400 font-medium">
                    {currentUser?.systemRole === "ADMIN" ? "Sócio / Admin" : "Equipe"}
                  </div>
                </div>

                {/* Avatar circular idêntico ao estilo da foto */}
                <div className="w-9 h-9 rounded-full bg-gradient-to-tr from-indigo-500 via-purple-500 to-pink-500 p-[2px] shadow-md shadow-indigo-500/20">
                  <div className="w-full h-full rounded-full bg-[#161822] flex items-center justify-center text-xs font-bold text-white tracking-wider">
                    {currentUser?.name ? getInitials(currentUser.name) : "AV"}
                  </div>
                </div>

                {isDev && <ChevronDown className="w-4 h-4 text-slate-400" />}
              </button>

              {/* Menu de Troca Rápida de Usuário (Modo Desenvolvimento) */}
              {userDropdownOpen && (
                <div className="absolute right-0 mt-2 w-64 rounded-2xl bg-[#161822] border border-[#262b3d] shadow-2xl py-2 z-50 animate-in fade-in zoom-in-95 duration-150">
                  <div className="px-4 py-2 border-b border-[#222638]">
                    <p className="text-xs font-semibold text-white">{currentUser?.name}</p>
                    <p className="text-[11px] text-slate-400 truncate">{currentUser?.email}</p>
                    <span className="inline-block mt-1 text-[10px] px-2 py-0.5 rounded bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 font-medium">
                      {currentUser?.systemRole === "ADMIN" ? "Administrador" : "Membro da Equipe"}
                    </span>
                  </div>

                  {isDev && allMembers.length > 0 && (
                    <div className="py-2 border-b border-[#222638]">
                      <span className="px-4 text-[10px] uppercase font-bold tracking-wider text-slate-500 block mb-1">
                        Alternar Usuário (Dev)
                      </span>
                      {allMembers.map((m) => (
                        <button
                          key={m.id}
                          onClick={() => handleSwitchUser(m.id)}
                          className={`w-full text-left px-4 py-1.5 text-xs flex items-center justify-between hover:bg-[#1e2233] transition-colors ${
                            m.id === currentUser?.id
                              ? "text-indigo-400 font-semibold"
                              : "text-slate-300"
                          }`}
                        >
                          <span>{m.name}</span>
                          <span className="text-[10px] text-slate-500">{m.systemRole}</span>
                        </button>
                      ))}
                    </div>
                  )}

                  <div className="pt-1">
                    <form action={logoutUser}>
                      <button
                        type="submit"
                        className="w-full text-left px-4 py-2 text-xs text-rose-400 hover:bg-rose-500/10 flex items-center gap-2"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        <span>Sair do Sistema</span>
                      </button>
                    </form>
                  </div>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Canvas de Conteúdo da Página */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-7xl w-full mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
