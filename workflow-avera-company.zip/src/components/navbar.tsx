"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState } from "react";
import { ThemeToggle } from "./theme-toggle";
import {
  CheckSquare,
  Kanban,
  BarChart3,
  Users,
  FolderGit2,
  BookOpen,
  CalendarDays,
  Menu,
  X,
  LogOut,
  ShieldCheck,
  UserCheck,
  ChevronDown,
  Layers,
  Briefcase,
} from "lucide-react";
import { switchDevUser, logoutUser } from "@/app/actions/auth-actions";

type NavbarProps = {
  currentUser: {
    id: string;
    name: string;
    email: string;
    systemRole: "ADMIN" | "MEMBER";
    roles: { id: string; name: string }[];
  } | null;
  allMembers?: { id: string; name: string; systemRole: string }[];
  isDev?: boolean;
};

export function Navbar({ currentUser, allMembers = [], isDev = false }: NavbarProps) {
  const pathname = usePathname();
  const router = useRouter();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navLinks = [
    { href: "/", label: "Minhas Tarefas", icon: CheckSquare },
    { href: "/kanban", label: "Quadro", icon: Kanban },
    { href: "/carga", label: "Carga", icon: BarChart3 },
    { href: "/areas", label: "Áreas", icon: Layers },
    { href: "/clientes", label: "Clientes", icon: Users },
    { href: "/projetos", label: "Projetos", icon: Briefcase },
    { href: "/processos", label: "Processos", icon: BookOpen },
    { href: "/rituais", label: "Rituais & Decisões", icon: CalendarDays },
    { href: "/equipe", label: "Equipe & Papéis", icon: FolderGit2 },
  ];

  const handleSwitchUser = async (memberId: string) => {
    if (!isDev) return;
    await switchDevUser(memberId);
    setUserDropdownOpen(false);
    router.refresh();
  };

  return (
    <nav className="sticky top-0 z-40 w-full border-b border-slate-200 dark:border-slate-800 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-14">
          {/* Logo & Main Nav */}
          <div className="flex items-center gap-6">
            <Link href="/" className="flex items-center gap-2 font-bold text-lg tracking-tight">
              <span className="w-7 h-7 rounded-md bg-gradient-to-tr from-violet-600 to-indigo-600 text-white flex items-center justify-center text-sm font-black shadow-sm">
                A
              </span>
              <span className="text-slate-900 dark:text-white font-semibold">Avera</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-slate-100 dark:bg-slate-800 text-slate-500">
                Ops
              </span>
            </Link>

            {/* Desktop Nav Links */}
            <div className="hidden md:flex items-center space-x-1">
              {navLinks.map((link) => {
                const Icon = link.icon;
                const isActive = pathname === link.href;
                return (
                  <Link
                    key={link.href}
                    href={link.href}
                    className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium transition ${
                      isActive
                        ? "bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                        : "text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white hover:bg-slate-50 dark:hover:bg-slate-900"
                    }`}
                  >
                    <Icon className="w-3.5 h-3.5" />
                    {link.label}
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Right Area: Theme, User Info & Switch */}
          <div className="flex items-center gap-2">
            <ThemeToggle />

            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 px-2.5 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 hover:bg-slate-100 dark:hover:bg-slate-800 transition text-left"
                >
                  <div className="w-6 h-6 rounded-full bg-indigo-100 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 font-bold text-xs flex items-center justify-center">
                    {currentUser.name.charAt(0)}
                  </div>
                  <div className="hidden sm:block text-left">
                    <p className="text-xs font-semibold leading-tight text-slate-800 dark:text-slate-200">
                      {currentUser.name}
                    </p>
                    <p className="text-[10px] text-slate-500 flex items-center gap-1">
                      {currentUser.systemRole === "ADMIN" ? (
                        <ShieldCheck className="w-3 h-3 text-emerald-500" />
                      ) : (
                        <UserCheck className="w-3 h-3 text-blue-500" />
                      )}
                      {currentUser.systemRole === "ADMIN" ? "Admin" : "Membro"}
                    </p>
                  </div>
                  <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
                </button>

                {/* Dropdown Menu */}
                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-xl py-2 z-50">
                    <div className="px-3 py-2 border-b border-slate-100 dark:border-slate-800">
                      <p className="text-xs font-semibold text-slate-900 dark:text-white">
                        {currentUser.name}
                      </p>
                      <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                    </div>

                    {/* Alternância rápida APENAS em NODE_ENV === "development" */}
                    {isDev && allMembers.length > 0 && (
                      <div className="py-1">
                        <p className="px-3 py-1 text-[10px] uppercase font-bold text-amber-500 tracking-wider">
                          Dev: Alternar Usuário
                        </p>
                        {allMembers.map((m) => (
                          <button
                            key={m.id}
                            onClick={() => handleSwitchUser(m.id)}
                            className={`w-full text-left px-3 py-1.5 text-xs flex items-center justify-between hover:bg-slate-100 dark:hover:bg-slate-800 transition ${
                              m.id === currentUser.id
                                ? "font-bold text-indigo-600 dark:text-indigo-400"
                                : "text-slate-700 dark:text-slate-300"
                            }`}
                          >
                            <span>{m.name}</span>
                            <span className="text-[10px] text-slate-400">
                              {m.systemRole === "ADMIN" ? "Admin" : "Membro"}
                            </span>
                          </button>
                        ))}
                      </div>
                    )}

                    <div className="pt-1 border-t border-slate-100 dark:border-slate-800">
                      <form action={logoutUser}>
                        <button
                          type="submit"
                          className="w-full text-left px-3 py-1.5 text-xs text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/30 flex items-center gap-2 transition"
                        >
                          <LogOut className="w-3.5 h-3.5" />
                          Sair do sistema
                        </button>
                      </form>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <Link
                href="/login"
                className="text-xs font-medium px-3 py-1.5 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 transition"
              >
                Entrar
              </Link>
            )}

            {/* Mobile menu button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 rounded-lg text-slate-500 hover:text-slate-900 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-slate-800"
            >
              {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav Links Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden border-t border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-950 px-4 pt-2 pb-4 space-y-1">
          {navLinks.map((link) => {
            const Icon = link.icon;
            const isActive = pathname === link.href;
            return (
              <Link
                key={link.href}
                href={link.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium ${
                  isActive
                    ? "bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white font-semibold"
                    : "text-slate-600 dark:text-slate-400 hover:bg-slate-50 dark:hover:bg-slate-900"
                }`}
              >
                <Icon className="w-4 h-4" />
                {link.label}
              </Link>
            );
          })}
        </div>
      )}
    </nav>
  );
}
