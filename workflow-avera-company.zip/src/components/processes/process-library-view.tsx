"use client";

import { useState } from "react";
import {
  BookOpen,
  CheckCircle,
  AlertCircle,
  Edit3,
  Layers,
  Clock,
  User,
  Shield,
  X,
  Check,
} from "lucide-react";
import { formatCurrencyBRL } from "@/lib/date-utils";
import { updateProcessStepAction, updateProcessTemplateDetailsAction } from "@/app/actions/process-actions";
import { useRouter } from "next/navigation";

type ProcessStep = {
  id: string;
  order: number;
  title: string;
  description: string | null;
  defaultAssigneeTag: string | null;
  defaultRoleId: string | null;
  defaultRole: { id: string; name: string } | null;
  deadlineDays: number | null;
  anchorOffsetDays: number | null;
  deadlineOrigin: string;
  deliverable: string;
  isClientStep: boolean;
  isCalendarDays: boolean;
  isProvisionalAnchor: boolean;
};

type ProcessTemplate = {
  id: string;
  name: string;
  version: number;
  checklist: string | null;
  attentionPoints: string | null;
  steps: ProcessStep[];
};

type ServiceItem = {
  id: string;
  name: string;
  scope: string;
  outOfScope: string;
  notes: string | null;
  priceType: string;
  financial?: { price: any } | null;
  area: { id: string; name: string; color: string };
  templates: ProcessTemplate[];
};

type ProcessLibraryViewProps = {
  services: ServiceItem[];
  commonProcess: ProcessTemplate | null;
  operationalRoles: { id: string; name: string }[];
  isAdmin: boolean;
};

export function ProcessLibraryView({
  services,
  commonProcess,
  operationalRoles,
  isAdmin,
}: ProcessLibraryViewProps) {
  const router = useRouter();
  const [selectedServiceId, setSelectedServiceId] = useState<string>(
    commonProcess ? "common" : services[0]?.id || ""
  );

  // Estado para modal de edição de passo
  const [editingStep, setEditingStep] = useState<ProcessStep | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editDeliverable, setEditDeliverable] = useState("");
  const [editDays, setEditDays] = useState<string>("");
  const [editClientStep, setEditClientStep] = useState(false);
  const [savingStep, setSavingStep] = useState(false);

  // Estado para edição de checklist e pontos de atenção
  const [editingTemplate, setEditingTemplate] = useState<ProcessTemplate | null>(null);
  const [editChecklist, setEditChecklist] = useState("");
  const [editAttention, setEditAttention] = useState("");
  const [savingTemplate, setSavingTemplate] = useState(false);

  const isCommon = selectedServiceId === "common";
  const activeService = services.find((s) => s.id === selectedServiceId);
  const activeTemplate = isCommon ? commonProcess : activeService?.templates[0];

  const handleOpenEditStep = (step: ProcessStep) => {
    setEditingStep(step);
    setEditTitle(step.title);
    setEditDeliverable(step.deliverable);
    setEditDays(step.deadlineDays !== null ? String(step.deadlineDays) : "");
    setEditClientStep(step.isClientStep);
  };

  const handleSaveStep = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingStep) return;
    setSavingStep(true);

    await updateProcessStepAction({
      stepId: editingStep.id,
      title: editTitle,
      deliverable: editDeliverable,
      deadlineDays: editDays ? parseInt(editDays, 10) : null,
      isClientStep: editClientStep,
    });

    setSavingStep(false);
    setEditingStep(null);
    router.refresh();
  };

  const handleOpenEditTemplate = (tmpl: ProcessTemplate) => {
    setEditingTemplate(tmpl);
    setEditChecklist(tmpl.checklist || "");
    setEditAttention(tmpl.attentionPoints || "");
  };

  const handleSaveTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingTemplate) return;
    setSavingTemplate(true);

    await updateProcessTemplateDetailsAction({
      templateId: editingTemplate.id,
      checklist: editChecklist,
      attentionPoints: editAttention,
    });

    setSavingTemplate(false);
    setEditingTemplate(null);
    router.refresh();
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 pb-4 border-b border-[#232738]">
        <div>
          <h1 className="text-xl sm:text-2xl font-bold tracking-tight text-white flex items-center gap-2">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white shadow-md">
              <BookOpen className="w-4 h-4" />
            </div>
            Biblioteca Oficial de Processos da Avera
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            O padrão oficial de execução do catálogo. Alterações feitas aqui passam a valer automaticamente para os próximos projetos.
          </p>
        </div>
      </div>

      {/* Navegação Rápida entre os Serviços */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2">
        {commonProcess && (
          <button
            onClick={() => setSelectedServiceId("common")}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition shrink-0 flex items-center gap-1.5 ${
              selectedServiceId === "common"
                ? "bg-gradient-to-r from-indigo-500 to-violet-600 text-white font-bold shadow-md shadow-indigo-950/40"
                : "bg-[#151722] border border-[#232738] text-slate-400 hover:text-white hover:border-[#38415d]"
            }`}
          >
            ★ Processo Comum (Kickoff)
          </button>
        )}

        {services.map((s) => {
          const isSelected = selectedServiceId === s.id;
          return (
            <button
              key={s.id}
              onClick={() => setSelectedServiceId(s.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-semibold transition shrink-0 flex items-center gap-1.5 ${
                isSelected
                  ? "bg-gradient-to-r from-indigo-500 to-violet-600 text-white font-bold shadow-md shadow-indigo-950/40"
                  : "bg-[#151722] border border-[#232738] text-slate-400 hover:text-white hover:border-[#38415d]"
              }`}
            >
              <span
                className="w-2 h-2 rounded-full shadow-sm"
                style={{ backgroundColor: s.area.color }}
              />
              {s.name}
            </button>
          );
        })}
      </div>

      {/* Conteúdo do Processo Selecionado */}
      {activeTemplate && (
        <div className="space-y-6">
          {/* Card com Metadados do Serviço */}
          {!isCommon && activeService && (
            <div className="p-5 rounded-2xl bg-[#151722] border border-[#232738] shadow-sm space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span
                      className="w-2.5 h-2.5 rounded-full shadow-sm"
                      style={{ backgroundColor: activeService.area.color }}
                    />
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                      {activeService.area.name}
                    </span>
                    <span className="px-2 py-0.5 rounded-md text-[10px] font-bold bg-[#111218] border border-[#232738] text-slate-300">
                      {activeService.priceType === "MONTHLY" ? "Serviço Mensal" : "Serviço Pontual"}
                    </span>
                  </div>
                  <h2 className="text-xl font-bold text-white">
                    {activeService.name}
                  </h2>
                </div>

                {isAdmin && (
                  <div className="text-right">
                    <span className="text-[10px] uppercase font-bold text-slate-500 block">
                      Valor do Catálogo
                    </span>
                    <span className="text-lg font-black text-teal-400">
                      {formatCurrencyBRL(activeService.financial?.price)}
                    </span>
                  </div>
                )}
              </div>

              {/* Escopo e Fora do Escopo */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs pt-2">
                <div className="p-4 rounded-xl bg-[#111218] border border-[#232738]">
                  <p className="font-bold text-teal-400 uppercase tracking-wider text-[10px] mb-1.5">
                    O que inclui (Escopo do Catálogo)
                  </p>
                  <p className="text-slate-300 leading-relaxed">
                    {activeService.scope}
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-[#111218] border border-[#232738]">
                  <p className="font-bold text-rose-400 uppercase tracking-wider text-[10px] mb-1.5">
                    O que NÃO inclui (Fora do Escopo)
                  </p>
                  <p className="text-slate-300 leading-relaxed">
                    {activeService.outOfScope}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* Passos Numerados do Processo */}
          <div className="bg-[#151722] border border-[#232738] rounded-2xl overflow-hidden shadow-sm">
            <div className="p-4 border-b border-[#232738] bg-[#111218] flex items-center justify-between">
              <div>
                <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                  Passos de Execução ({activeTemplate.steps.length} etapas)
                </h3>
                <p className="text-[11px] text-slate-400">
                  Cada passo termina com uma entrega verificável antes de passar para a próxima fase.
                </p>
              </div>
            </div>

            <div className="divide-y divide-[#1f2333] text-xs">
              {activeTemplate.steps.map((step) => (
                <div
                  key={step.id}
                  className="p-4 flex flex-col sm:flex-row sm:items-start justify-between gap-3 hover:bg-[#191c2a] transition"
                >
                  <div className="space-y-1.5 max-w-[70%]">
                    <div className="flex items-center gap-2">
                      <span className="w-5 h-5 rounded-full bg-[#111218] border border-[#232738] font-bold text-[11px] flex items-center justify-center text-teal-400 shrink-0">
                        {step.order}
                      </span>
                      <p className="font-semibold text-white">{step.title}</p>
                    </div>

                    <p className="text-[11px] text-slate-400 pl-7">
                      <strong className="text-slate-200">Entrega do passo:</strong>{" "}
                      {step.deliverable}
                    </p>

                    {step.isClientStep && (
                      <span className="inline-block ml-7 mt-1 px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        Envolve Reunião / Aprovação do Cliente
                      </span>
                    )}
                  </div>

                  <div className="flex items-center sm:flex-col sm:items-end justify-between gap-2 shrink-0 text-right pl-7 sm:pl-0">
                    <span className="font-semibold text-slate-200">
                      Quem: {step.defaultRole?.name || step.defaultAssigneeTag || "Equipe"}
                    </span>
                    <span className="text-[11px] text-slate-400">
                      Prazo:{" "}
                      {step.deadlineDays !== null
                        ? `${step.deadlineDays} ${step.isCalendarDays ? "dias corridos" : "dias úteis"}`
                        : "Rotina contínua"}
                    </span>

                    {isAdmin && (
                      <button
                        onClick={() => handleOpenEditStep(step)}
                        className="text-[11px] font-semibold text-indigo-400 hover:text-indigo-300 hover:underline flex items-center gap-1 mt-1"
                      >
                        <Edit3 className="w-3 h-3" />
                        Editar Passo
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Checklist e Pontos de Atenção */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Checklist */}
            <div className="p-4 rounded-2xl bg-[#151722] border border-[#232738] shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle className="w-4 h-4" />
                  Checklist Final de Entrega
                </span>
                {isAdmin && (
                  <button
                    onClick={() => handleOpenEditTemplate(activeTemplate)}
                    className="text-[10px] font-semibold text-indigo-400 hover:underline"
                  >
                    Editar
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                {activeTemplate.checklist || "Nenhum checklist registrado."}
              </p>
            </div>

            {/* Pontos de Atenção */}
            <div className="p-4 rounded-2xl bg-[#151722] border border-[#232738] shadow-sm space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5">
                  <AlertCircle className="w-4 h-4" />
                  Pontos de Atenção & Riscos
                </span>
                {isAdmin && (
                  <button
                    onClick={() => handleOpenEditTemplate(activeTemplate)}
                    className="text-[10px] font-semibold text-indigo-400 hover:underline"
                  >
                    Editar
                  </button>
                )}
              </div>
              <p className="text-xs text-slate-300 leading-relaxed whitespace-pre-line">
                {activeTemplate.attentionPoints || "Nenhum ponto de atenção registrado."}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* MODAL DE EDIÇÃO DE PASSO (Admin) */}
      {editingStep && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-[#151722] rounded-2xl border border-[#232738] shadow-2xl p-6 relative">
            <button
              onClick={() => setEditingStep(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-white mb-4">
              Editar Passo #{editingStep.order}
            </h3>

            <form onSubmit={handleSaveStep} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
                  Título do Passo
                </label>
                <input
                  type="text"
                  required
                  value={editTitle}
                  onChange={(e) => setEditTitle(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-xl border border-[#232738] bg-[#111218] text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
                  Entrega do Passo (Verificável)
                </label>
                <input
                  type="text"
                  required
                  value={editDeliverable}
                  onChange={(e) => setEditDeliverable(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-xl border border-[#232738] bg-[#111218] text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
                  Prazo Sugerido (dias)
                </label>
                <input
                  type="number"
                  placeholder="Deixe vazio se for rotina contínua"
                  value={editDays}
                  onChange={(e) => setEditDays(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-xl border border-[#232738] bg-[#111218] text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="flex items-center gap-2 pt-1">
                <input
                  type="checkbox"
                  id="clientStep"
                  checked={editClientStep}
                  onChange={(e) => setEditClientStep(e.target.checked)}
                  className="rounded text-indigo-600 focus:ring-indigo-500 bg-[#111218] border-[#232738]"
                />
                <label htmlFor="clientStep" className="text-xs font-medium text-slate-300">
                  Passo com o cliente (reunião, aprovação, feedback)
                </label>
              </div>

              <div className="pt-4 border-t border-[#232738] flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingStep(null)}
                  className="px-4 py-2 text-xs font-medium rounded-xl text-slate-400 hover:text-white transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={savingStep}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white transition disabled:opacity-50"
                >
                  {savingStep ? "Salvando..." : "Salvar Alterações"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL DE EDIÇÃO DE CHECKLIST E PONTOS DE ATENÇÃO (Admin) */}
      {editingTemplate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
          <div className="w-full max-w-lg bg-[#151722] rounded-2xl border border-[#232738] shadow-2xl p-6 relative">
            <button
              onClick={() => setEditingTemplate(null)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white"
            >
              <X className="w-5 h-5" />
            </button>

            <h3 className="text-base font-bold text-white mb-4">
              Editar Checklist e Pontos de Atenção
            </h3>

            <form onSubmit={handleSaveTemplate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
                  Checklist Final de Entrega
                </label>
                <textarea
                  rows={3}
                  value={editChecklist}
                  onChange={(e) => setEditChecklist(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-xl border border-[#232738] bg-[#111218] text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1">
                  Pontos de Atenção & Riscos
                </label>
                <textarea
                  rows={4}
                  value={editAttention}
                  onChange={(e) => setEditAttention(e.target.value)}
                  className="w-full p-2.5 text-xs rounded-xl border border-[#232738] bg-[#111218] text-white focus:outline-none focus:border-indigo-500"
                />
              </div>

              <div className="pt-4 border-t border-[#232738] flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setEditingTemplate(null)}
                  className="px-4 py-2 text-xs font-medium rounded-xl text-slate-400 hover:text-white transition"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={savingTemplate}
                  className="px-4 py-2 text-xs font-semibold rounded-xl bg-gradient-to-r from-indigo-500 to-violet-600 hover:from-indigo-600 hover:to-violet-700 text-white transition disabled:opacity-50"
                >
                  {savingTemplate ? "Salvando..." : "Salvar"}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
