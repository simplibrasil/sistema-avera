/**
 * Utilitários para manipulação de datas e cálculo de prazos
 * no fuso horário America/Sao_Paulo.
 * Considera fins de semana (Sábado e Domingo) e lista dinâmica de feriados nacionais.
 */

const SAO_PAULO_TIMEZONE = "America/Sao_Paulo";

export const DEFAULT_BRAZILIAN_HOLIDAYS = [
  "2026-01-01", // Confraternização Universal
  "2026-02-17", // Carnaval
  "2026-04-03", // Sexta-feira Santa
  "2026-04-21", // Tiradentes
  "2026-05-01", // Dia do Trabalho
  "2026-06-04", // Corpus Christi
  "2026-09-07", // Independência do Brasil
  "2026-10-12", // Nossa Senhora Aparecida
  "2026-11-02", // Finados
  "2026-11-15", // Proclamação da República
  "2026-11-20", // Dia da Consciência Negra
  "2026-12-25", // Natal
  // 2027
  "2027-01-01",
  "2027-02-09",
  "2027-03-26",
  "2027-04-21",
  "2027-05-01",
  "2027-05-27",
  "2027-09-07",
  "2027-10-12",
  "2027-11-02",
  "2027-11-15",
  "2027-11-20",
  "2027-12-25",
];

function toDateKey(d: Date): string {
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, "0");
  const day = String(d.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export function isWeekend(date: Date): boolean {
  const day = date.getDay();
  return day === 0 || day === 6;
}

export function isNonWorkingDay(date: Date, holidayList: string[] = DEFAULT_BRAZILIAN_HOLIDAYS): boolean {
  if (isWeekend(date)) return true;
  const key = toDateKey(date);
  return holidayList.includes(key);
}

export function addBusinessDays(
  startDate: Date,
  days: number,
  holidays: string[] = DEFAULT_BRAZILIAN_HOLIDAYS
): Date {
  const result = new Date(startDate);
  let count = 0;

  if (days === 0) {
    while (isNonWorkingDay(result, holidays)) {
      result.setDate(result.getDate() + 1);
    }
    return result;
  }

  while (count < days) {
    result.setDate(result.getDate() + 1);
    if (!isNonWorkingDay(result, holidays)) {
      count++;
    }
  }

  return result;
}

export function subtractBusinessDays(
  anchorDate: Date,
  days: number,
  holidays: string[] = DEFAULT_BRAZILIAN_HOLIDAYS
): Date {
  const result = new Date(anchorDate);
  let count = 0;

  if (days === 0) {
    while (isNonWorkingDay(result, holidays)) {
      result.setDate(result.getDate() - 1);
    }
    return result;
  }

  while (count < days) {
    result.setDate(result.getDate() - 1);
    if (!isNonWorkingDay(result, holidays)) {
      count++;
    }
  }

  return result;
}

export function addCalendarDays(startDate: Date, days: number): Date {
  const result = new Date(startDate);
  result.setDate(result.getDate() + days);
  return result;
}

export function subtractCalendarDays(startDate: Date, days: number): Date {
  const result = new Date(startDate);
  result.setDate(result.getDate() - days);
  return result;
}

/**
 * Calcula o 5º dia útil do mês seguinte ao ciclo
 * (usado estritamente para relatórios mensais de tráfego e redes sociais)
 */
export function getFifthBusinessDayOfNextMonth(
  cycleStartDate: Date,
  holidays: string[] = DEFAULT_BRAZILIAN_HOLIDAYS
): Date {
  const base = new Date(cycleStartDate);
  // Primeiro dia do mês seguinte
  const nextMonthFirstDay = new Date(base.getFullYear(), base.getMonth() + 1, 1);
  
  let current = new Date(nextMonthFirstDay);
  let businessDaysCount = 0;

  while (businessDaysCount < 5) {
    if (!isNonWorkingDay(current, holidays)) {
      businessDaysCount++;
      if (businessDaysCount === 5) {
        return current;
      }
    }
    current.setDate(current.getDate() + 1);
  }

  return current;
}

/**
 * Calcula a data de entrega de um passo
 */
export function calculateStepDueDate(options: {
  projectStartDate: Date;
  previousStepDueDate?: Date | null;
  anchorDate?: Date | null;
  deadlineDays?: number | null;
  deadlineOrigin: "PROJECT_START" | "PREVIOUS_STEP" | "ANCHOR_DATE" | "PARALLEL_MAX" | "FIFTH_BUSINESS_DAY_NEXT_MONTH";
  anchorOffsetDays?: number | null;
  isCalendarDays?: boolean;
  holidays?: string[];
}): Date | null {
  const {
    projectStartDate,
    previousStepDueDate,
    anchorDate,
    deadlineDays,
    deadlineOrigin,
    anchorOffsetDays,
    isCalendarDays = false,
    holidays = DEFAULT_BRAZILIAN_HOLIDAYS,
  } = options;

  if (deadlineOrigin === "FIFTH_BUSINESS_DAY_NEXT_MONTH") {
    const baseCycle = anchorDate || projectStartDate;
    return getFifthBusinessDayOfNextMonth(baseCycle, holidays);
  }

  if (deadlineOrigin === "ANCHOR_DATE") {
    if (!anchorDate) return null;
    const offset =
      anchorOffsetDays !== undefined && anchorOffsetDays !== null
        ? anchorOffsetDays
        : deadlineDays
        ? -deadlineDays
        : 0;

    if (isCalendarDays) {
      return offset < 0
        ? subtractCalendarDays(anchorDate, Math.abs(offset))
        : addCalendarDays(anchorDate, offset);
    } else {
      return offset < 0
        ? subtractBusinessDays(anchorDate, Math.abs(offset), holidays)
        : addBusinessDays(anchorDate, offset, holidays);
    }
  }

  if (deadlineOrigin === "PREVIOUS_STEP") {
    const baseDate = previousStepDueDate || projectStartDate;
    if (deadlineDays === null || deadlineDays === undefined) return null;
    return isCalendarDays
      ? addCalendarDays(baseDate, deadlineDays)
      : addBusinessDays(baseDate, deadlineDays, holidays);
  }

  // Padrão: PROJECT_START
  if (deadlineDays === null || deadlineDays === undefined) return null;
  return isCalendarDays
    ? addCalendarDays(projectStartDate, deadlineDays)
    : addBusinessDays(projectStartDate, deadlineDays, holidays);
}

export function formatDateBR(date: Date | string | null | undefined): string {
  if (!date) return "-";
  const d = typeof date === "string" ? new Date(date) : date;
  return d.toLocaleDateString("pt-BR", {
    timeZone: SAO_PAULO_TIMEZONE,
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  });
}

export function formatCurrencyBRL(value: number | string | null | undefined): string {
  if (value === null || value === undefined || value === "") return "A definir";
  const num = typeof value === "string" ? parseFloat(value) : value;
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(num);
}
