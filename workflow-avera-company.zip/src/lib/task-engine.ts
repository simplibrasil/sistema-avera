import prisma from "./prisma";
import {
  calculateStepDueDate,
  addBusinessDays,
  getFifthBusinessDayOfNextMonth,
  formatDateBR,
  DEFAULT_BRAZILIAN_HOLIDAYS,
} from "./date-utils";

type CreateProjectInput = {
  clientId: string;
  serviceId: string;
  name?: string;
  value?: number | null;
  startDate?: Date | string;
  recordingDate?: Date | string | null;
  releaseDate?: Date | string | null;
  cycleStartDate?: Date | string | null;
  customOffsets?: Record<number, number>; // Permite editar os offsets provisórios (ex.: passo 8 e 9)
};

export async function createProjectAndGenerateTasks(input: CreateProjectInput) {
  // 1. Prevenção de duplicidade por engano
  const existingActive = await prisma.project.findFirst({
    where: {
      clientId: input.clientId,
      serviceId: input.serviceId,
      status: "IN_PROGRESS",
    },
    include: {
      service: true,
      client: true,
    },
  });

  if (existingActive) {
    throw new Error(
      `Já existe um projeto em andamento de "${existingActive.service.name}" para o cliente "${existingActive.client.name}". Conclua ou pause o anterior antes de criar outro.`
    );
  }

  // 2. Busca o serviço e seu modelo de processo
  const service = await prisma.service.findUnique({
    where: { id: input.serviceId },
    include: {
      financial: true,
      templates: {
        where: { isDefault: true },
        include: {
          steps: {
            orderBy: { order: "asc" },
            include: {
              defaultRole: {
                include: {
                  memberRoles: {
                    include: {
                      member: true,
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
  });

  if (!service) {
    throw new Error("Serviço não encontrado.");
  }

  const template = service.templates[0];
  if (!template || template.steps.length === 0) {
    throw new Error(`O serviço "${service.name}" ainda não possui modelo de processo cadastrado.`);
  }

  // 3. Feriados nacionais
  let holidayKeys: string[] = DEFAULT_BRAZILIAN_HOLIDAYS;
  try {
    const dbHolidays = await prisma.holiday.findMany({
      where: { active: true },
      select: { date: true },
    });
    if (dbHolidays.length > 0) {
      holidayKeys = dbHolidays.map((h) => {
        const d = new Date(h.date);
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
      });
    }
  } catch {}

  const parsedStartDate = input.startDate ? new Date(input.startDate) : new Date();
  const parsedRecordingDate = input.recordingDate ? new Date(input.recordingDate) : null;
  const parsedReleaseDate = input.releaseDate ? new Date(input.releaseDate) : null;
  const parsedCycleStartDate = input.cycleStartDate
    ? new Date(input.cycleStartDate)
    : service.priceType === "MONTHLY"
    ? parsedStartDate
    : null;

  // 4. Verificação de Viabilidade de Prazo de Lançamento (Ponto 2a)
  let releaseDateWarning: string | null = null;
  if (parsedReleaseDate && service.name.toLowerCase().includes("lançamento")) {
    // Soma os dias mínimos encadeados necessários para preparar o lançamento (30 dias úteis)
    const minBusinessDaysNeeded = 30;
    const recommendedMinDate = addBusinessDays(parsedStartDate, minBusinessDaysNeeded, holidayKeys);

    if (parsedReleaseDate < recommendedMinDate) {
      releaseDateWarning = `Atenção: A data de lançamento informada (${formatDateBR(
        parsedReleaseDate
      )}) é anterior ao prazo recomendado de preparação (${formatDateBR(
        recommendedMinDate
      )} - mínimo de ${minBusinessDaysNeeded} dias úteis). Os prazos foram ajustados para respeitar a sequência lógica.`;
    }
  }

  // 5. Criação do Projeto e isolamento financeiro na tabela ProjectFinancial (Ponto 1)
  const client = await prisma.client.findUnique({ where: { id: input.clientId } });
  const projectName = input.name || `${service.name} - ${client?.name || "Novo Projeto"}`;

  const project = await prisma.project.create({
    data: {
      clientId: input.clientId,
      serviceId: input.serviceId,
      name: projectName,
      startDate: parsedStartDate,
      status: "IN_PROGRESS",
      recurrence: service.priceType === "MONTHLY" ? "MONTHLY" : "ONE_OFF",
      recordingDate: parsedRecordingDate,
      releaseDate: parsedReleaseDate,
      cycleStartDate: parsedCycleStartDate,
      currentCycle: 1,
    },
  });

  // Salva o valor financeiro isolado na tabela ProjectFinancial (restrita a ADMIN via RLS)
  if (input.value !== undefined && input.value !== null) {
    await prisma.projectFinancial.create({
      data: {
        projectId: project.id,
        value: input.value,
      },
    });
  } else if (service.financial?.price) {
    await prisma.projectFinancial.create({
      data: {
        projectId: project.id,
        value: Number(service.financial.price),
      },
    });
  }

  // 6. Geração das Tarefas com Prazos Corrigidos e Encadeamento Lógico
  let previousStepDueDate: Date | null = null;
  const stepDueDatesMap: Record<number, Date> = {};
  const createdTasks: any[] = [];

  for (const step of template.steps) {
    // A) Resolução de Responsável
    let assigneeId: string | null = null;
    let isThirdParty = step.responsibleType === "THIRD_PARTY" || step.defaultAssigneeTag === "terceiro";

    if (!isThirdParty && step.defaultRole) {
      const activeMembers = step.defaultRole.memberRoles
        .map((mr) => mr.member)
        .filter((m) => m.active);

      if (activeMembers.length > 0) {
        if (step.defaultAssigneeTag === "M") {
          const m = activeMembers.find((mb) => mb.name.toLowerCase().includes("matheus"));
          assigneeId = m ? m.id : activeMembers[0].id;
        } else if (step.defaultAssigneeTag === "A") {
          const a = activeMembers.find((mb) => mb.name.toLowerCase().includes("anelise"));
          assigneeId = a ? a.id : activeMembers[0].id;
        } else {
          // A+M
          assigneeId = activeMembers[0].id;
        }
      }
    }

    // B) Determina a data-âncora relevante
    let anchorDate: Date | null = null;
    if (step.anchorField === "RECORDING_DATE") {
      anchorDate = parsedRecordingDate;
    } else if (step.anchorField === "RELEASE_DATE") {
      anchorDate = parsedReleaseDate;
    } else if (step.anchorField === "CYCLE_START_DATE") {
      anchorDate = parsedCycleStartDate;
    }

    // C) Trata offset provisório editável (Ponto 6)
    let effectiveOffset = step.anchorOffsetDays;
    if (input.customOffsets && input.customOffsets[step.order] !== undefined) {
      effectiveOffset = input.customOffsets[step.order];
    }

    // D) Cálculo Especial de Prazos:
    let calculatedDueDate: Date | null = null;

    // Regra Tráfego (Ponto 3): "Criar campanha" vence 2 dias úteis após o mais longo dos paralelos (passo 5)
    if (service.name.toLowerCase().includes("tráfego") && step.order === 6) {
      const lastParallelDueDate = stepDueDatesMap[5] || previousStepDueDate || parsedStartDate;
      calculatedDueDate = addBusinessDays(lastParallelDueDate, 2, holidayKeys);
    }
    // Regra Tráfego / Relatório (Ponto 4): "Enviar relatório mensal" vence no 5º dia útil do mês seguinte
    else if (step.order === 12 && service.name.toLowerCase().includes("tráfego") && parsedCycleStartDate) {
      calculatedDueDate = getFifthBusinessDayOfNextMonth(parsedCycleStartDate, holidayKeys);
    }
    // Regra Tráfego / Reunião (Ponto 4): Reunião mensal vence 2 dias úteis após o relatório
    else if (step.order === 13 && service.name.toLowerCase().includes("tráfego") && stepDueDatesMap[12]) {
      calculatedDueDate = addBusinessDays(stepDueDatesMap[12], 2, holidayKeys);
    }
    // Cálculo Padrão
    else {
      calculatedDueDate = calculateStepDueDate({
        projectStartDate: parsedStartDate,
        previousStepDueDate,
        anchorDate,
        deadlineDays: step.deadlineDays,
        deadlineOrigin: step.deadlineOrigin as any,
        anchorOffsetDays: effectiveOffset,
        isCalendarDays: step.isCalendarDays,
        holidays: holidayKeys,
      });
    }

    // E) Regra de Dependência Lógica e Clamping (Ponto 2b):
    // Nenhum passo dependente pode vencer antes do seu pré-requisito, nem após o lançamento
    let isDateClamped = false;
    let clampedTitle = step.title;

    if (calculatedDueDate) {
      // Se tiver data de lançamento e for um passo pré-lançamento, não pode ultrapassar o dia do lançamento
      if (parsedReleaseDate && step.order < 12 && calculatedDueDate > parsedReleaseDate) {
        calculatedDueDate = new Date(parsedReleaseDate);
        isDateClamped = true;
      }

      // Se for posterior ao passo anterior na esteira sequencial (passos 1 a 7 do lançamento)
      if (service.name.toLowerCase().includes("lançamento") && step.order > 1 && step.order <= 7) {
        const prevStepDate = stepDueDatesMap[step.order - 1];
        if (prevStepDate && calculatedDueDate < prevStepDate) {
          calculatedDueDate = new Date(prevStepDate);
          isDateClamped = true;
        }
      }

      // Registro (passo 8) e Pitch (passo 9) dependem do catálogo (passo 6) e presskit (passo 7)
      if (service.name.toLowerCase().includes("lançamento") && (step.order === 8 || step.order === 9)) {
        const prerequisiteDate = stepDueDatesMap[6] || stepDueDatesMap[7];
        if (prerequisiteDate && calculatedDueDate < prerequisiteDate) {
          calculatedDueDate = addBusinessDays(prerequisiteDate, 1, holidayKeys);
          isDateClamped = true;
        }
      }

      // Plano de conteúdo (passo 10) depende do conceito (passo 3)
      if (service.name.toLowerCase().includes("lançamento") && step.order === 10) {
        const conceptDate = stepDueDatesMap[3];
        if (conceptDate && calculatedDueDate < conceptDate) {
          calculatedDueDate = addBusinessDays(conceptDate, 1, holidayKeys);
          isDateClamped = true;
        }
      }

      stepDueDatesMap[step.order] = calculatedDueDate;
      previousStepDueDate = calculatedDueDate;
    }

    // F) Status Inicial: Passos com o cliente entram como AGUARDANDO_CLIENTE
    const initialStatus = step.isClientStep ? "WAITING_CLIENT" : "TODO";

    const task = await prisma.task.create({
      data: {
        projectId: project.id,
        stepId: step.id,
        roleId: step.defaultRoleId,
        assigneeId,
        title: isDateClamped ? `${clampedTitle} [Prazo ajustado por dependência]` : clampedTitle,
        description: step.description,
        order: step.order,
        status: initialStatus,
        priority: "MEDIUM",
        isThirdParty,
        thirdPartyName: isThirdParty ? "Fornecedor Terceirizado" : null,
        dueDate: calculatedDueDate,
        deliverable: step.deliverable,
        isClientStep: step.isClientStep,
        isCalendarDays: step.isCalendarDays,
        isDateClamped,
        cycleNumber: service.priceType === "MONTHLY" ? 1 : null,
      },
    });

    createdTasks.push(task);
  }

  // G) Geração Automática do Próximo Ciclo Mensal (Ponto 5):
  // Se for mensal, insere automaticamente no fim da esteira o alerta do próximo ciclo para a equipe
  if (service.priceType === "MONTHLY" && parsedCycleStartDate) {
    const fifthDayNextMonth = getFifthBusinessDayOfNextMonth(parsedCycleStartDate, holidayKeys);
    await prisma.task.create({
      data: {
        projectId: project.id,
        order: 99,
        title: `[Ciclo Mensal] Iniciar Planejamento Automático do Ciclo 2`,
        description: "Gatilho automático de renovação mensal da Avera para o próximo mês.",
        status: "TODO",
        priority: "HIGH",
        dueDate: fifthDayNextMonth,
        deliverable: "Ciclo do próximo mês ativado no sistema",
        cycleNumber: 1,
      },
    });
  }

  return {
    project,
    tasksCount: createdTasks.length,
    tasks: createdTasks,
    releaseDateWarning,
  };
}

export async function generateNextMonthlyCycle(projectId: string) {
  const project = await prisma.project.findUnique({
    where: { id: projectId },
    include: {
      service: {
        include: {
          templates: {
            where: { isDefault: true },
            include: {
              steps: {
                orderBy: { order: "asc" },
                include: {
                  defaultRole: {
                    include: {
                      memberRoles: {
                        include: { member: true },
                      },
                    },
                  },
                },
              },
            },
          },
        },
      },
    },
  });

  if (!project || project.recurrence !== "MONTHLY") {
    throw new Error("Projeto não é um serviço mensal recorrente.");
  }

  const nextCycleNumber = project.currentCycle + 1;
  const newCycleStartDate = new Date(project.cycleStartDate || project.startDate);
  newCycleStartDate.setMonth(newCycleStartDate.getMonth() + 1);

  await prisma.project.update({
    where: { id: projectId },
    data: {
      currentCycle: nextCycleNumber,
      cycleStartDate: newCycleStartDate,
    },
  });

  const template = project.service.templates[0];
  const cycleSteps = template.steps.filter((s) => s.isMonthlyCycleStep || s.order > 2);

  const createdTasks: any[] = [];
  let previousStepDueDate: Date | null = null;

  for (const step of cycleSteps) {
    let assigneeId: string | null = null;
    const isThirdParty = step.responsibleType === "THIRD_PARTY";

    if (!isThirdParty && step.defaultRole) {
      const activeMembers = step.defaultRole.memberRoles
        .map((mr) => mr.member)
        .filter((m) => m.active);
      if (activeMembers.length > 0) {
        assigneeId = activeMembers[0].id;
      }
    }

    const calculatedDueDate = calculateStepDueDate({
      projectStartDate: newCycleStartDate,
      previousStepDueDate,
      anchorDate: newCycleStartDate,
      deadlineDays: step.deadlineDays,
      deadlineOrigin: step.deadlineOrigin as any,
      anchorOffsetDays: step.anchorOffsetDays,
      isCalendarDays: step.isCalendarDays,
    });

    if (calculatedDueDate) previousStepDueDate = calculatedDueDate;

    const task = await prisma.task.create({
      data: {
        projectId: project.id,
        stepId: step.id,
        roleId: step.defaultRoleId,
        assigneeId,
        title: `[Ciclo ${nextCycleNumber}] ${step.title}`,
        description: step.description,
        order: step.order,
        status: step.isClientStep ? "WAITING_CLIENT" : "TODO",
        dueDate: calculatedDueDate,
        deliverable: step.deliverable,
        isClientStep: step.isClientStep,
        isCalendarDays: step.isCalendarDays,
        cycleNumber: nextCycleNumber,
      },
    });

    createdTasks.push(task);
  }

  return { success: true, newCycleNumber: nextCycleNumber, tasksCount: createdTasks.length };
}
