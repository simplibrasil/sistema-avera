import { SessionUser } from "./auth";
import prisma from "./prisma";

/**
 * Sanitiza objetos de projeto removendo a relação financeira (ProjectFinancial)
 * e o valor monetário caso o usuário não tenha papel de ADMIN.
 */
export function sanitizeProjectFinancials<T extends { financial?: any; value?: any }>(
  project: T,
  user: SessionUser | null
): T {
  if (user?.systemRole === "ADMIN") {
    return project;
  }
  return {
    ...project,
    financial: null,
    value: null,
  };
}

export function sanitizeProjectsFinancials<T extends { financial?: any; value?: any }>(
  projects: T[],
  user: SessionUser | null
): T[] {
  if (user?.systemRole === "ADMIN") {
    return projects;
  }
  return projects.map((p) => ({
    ...p,
    financial: null,
    value: null,
  }));
}

export function sanitizeServicesFinancials<T extends { financial?: any }>(
  services: T[],
  user: SessionUser | null
): T[] {
  if (user?.systemRole === "ADMIN") {
    return services;
  }
  return services.map((s) => ({
    ...s,
    financial: null,
  }));
}

/**
 * Validação rigorosa no SERVIDOR para modificação de tarefas:
 * - Admin pode editar qualquer tarefa.
 * - Membro comum só pode atualizar tarefas que pertençam a ele (assigneeId === user.id).
 */
export async function authorizeTaskModification(
  taskId: string,
  user: SessionUser
): Promise<void> {
  if (user.systemRole === "ADMIN") {
    return;
  }

  const task = await prisma.task.findUnique({
    where: { id: taskId },
    select: { assigneeId: true },
  });

  if (!task) {
    throw new Error("Tarefa não encontrada.");
  }

  if (task.assigneeId !== user.id) {
    throw new Error("Acesso negado: Você só tem permissão para editar as suas próprias tarefas.");
  }
}
