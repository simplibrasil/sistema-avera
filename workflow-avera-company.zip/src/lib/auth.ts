import { createClient } from "./supabase/server";
import prisma from "./prisma";
import { cookies } from "next/headers";

export type SessionUser = {
  id: string;
  email: string;
  name: string;
  systemRole: "ADMIN" | "MEMBER";
  avatarUrl?: string | null;
  roles: { id: string; name: string; slug: string }[];
};

const IS_DEVELOPMENT = process.env.NODE_ENV === "development";

/**
 * Obtém o membro autenticado atual.
 * Em PRODUÇÃO (Netlify): Aceita EXCLUSIVAMENTE a sessão criptografada do Supabase Auth.
 * Em DESENVOLVIMENTO (local): Permite chave de teste para facilitar desenvolvimento inicial.
 */
export async function getCurrentUser(): Promise<SessionUser | null> {
  try {
    const supabase = await createClient();
    const {
      data: { user: authUser },
    } = await supabase.auth.getUser();

    if (authUser && authUser.email) {
      const member = await prisma.member.findUnique({
        where: { email: authUser.email },
        include: {
          memberRoles: {
            include: {
              operationalRole: true,
            },
          },
        },
      });

      if (member && member.active) {
        return {
          id: member.id,
          email: member.email,
          name: member.name,
          systemRole: member.systemRole,
          avatarUrl: member.avatarUrl,
          roles: member.memberRoles.map((mr) => ({
            id: mr.operationalRole.id,
            name: mr.operationalRole.name,
            slug: mr.operationalRole.slug,
          })),
        };
      }
    }
  } catch (error) {
    // Falha de rede ou sessão vazia no Supabase
  }

  // TRAVA DE SEGURANÇA: Se estiver em PRODUÇÃO, NUNCA permite fallbacks de desenvolvimento!
  if (!IS_DEVELOPMENT) {
    return null;
  }

  // FALLBACK EXCLUSIVO PARA DESENVOLVIMENTO LOCAL (NODE_ENV === "development")
  const cookieStore = await cookies();
  const devMemberId = cookieStore.get("avera_dev_member_id")?.value;

  if (devMemberId) {
    const member = await prisma.member.findUnique({
      where: { id: devMemberId },
      include: {
        memberRoles: {
          include: {
            operationalRole: true,
          },
        },
      },
    });

    if (member && member.active) {
      return {
        id: member.id,
        email: member.email,
        name: member.name,
        systemRole: member.systemRole,
        avatarUrl: member.avatarUrl,
        roles: member.memberRoles.map((mr) => ({
          id: mr.operationalRole.id,
          name: mr.operationalRole.name,
          slug: mr.operationalRole.slug,
        })),
      };
    }
  }

  // Padrão em dev local antes de login: primeiro admin
  try {
    const firstAdmin = await prisma.member.findFirst({
      where: { systemRole: "ADMIN", active: true },
      include: {
        memberRoles: {
          include: {
            operationalRole: true,
          },
        },
      },
    });

    if (firstAdmin) {
      return {
        id: firstAdmin.id,
        email: firstAdmin.email,
        name: firstAdmin.name,
        systemRole: firstAdmin.systemRole,
        avatarUrl: firstAdmin.avatarUrl,
        roles: firstAdmin.memberRoles.map((mr) => ({
          id: mr.operationalRole.id,
          name: mr.operationalRole.name,
          slug: mr.operationalRole.slug,
        })),
      };
    }
  } catch {
    // Banco não conectado
  }

  // Em desenvolvimento local pré-banco, provê Matheus como admin padrão para testes visuais imediatos:
  if (IS_DEVELOPMENT) {
    return {
      id: "dev-matheus",
      email: "matheus@avera.com",
      name: "Matheus",
      systemRole: "ADMIN",
      avatarUrl: null,
      roles: [{ id: "role-admin", name: "Administrador / Sócio", slug: "admin" }],
    };
  }

  return null;
}

export async function requireAuth(): Promise<SessionUser> {
  const user = await getCurrentUser();
  if (!user) {
    throw new Error("Não autorizado. Faça login para continuar.");
  }
  return user;
}

export async function requireAdmin(): Promise<SessionUser> {
  const user = await requireAuth();
  if (user.systemRole !== "ADMIN") {
    throw new Error("Acesso restrito para administradores.");
  }
  return user;
}
