/**
 * Supabase Admin Client (usando SERVICE_ROLE_KEY).
 * ATENÇÃO DE SEGURANÇA:
 * Este módulo roda EXCLUSIVAMENTE no servidor (Server Components, Route Handlers, Server Actions).
 * A service_role_key NUNCA é enviada nem exposta ao navegador.
 */

import { createClient } from "@supabase/supabase-js";

if (typeof window !== "undefined") {
  throw new Error("Segurança: supabaseAdmin não pode ser executado no navegador!");
}

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "https://placeholder-url.supabase.co";
const supabaseServiceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY || "placeholder-service-key";

export const supabaseAdmin = createClient(supabaseUrl, supabaseServiceRoleKey, {
  auth: {
    autoRefreshToken: false,
    persistSession: false,
  },
});
